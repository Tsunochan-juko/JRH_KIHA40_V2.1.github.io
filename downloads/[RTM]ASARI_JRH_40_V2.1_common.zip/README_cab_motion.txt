KiHa40 cab partition motion and headlight fade (2026-10-28)

All 132 vehicles / 53 renderers use asari_cab_motion.js and asari_farebox_pivot.js.
Farebox-equipped cars: Button5=one-man exposes, two-man stores.
Button6 is an informational, single-state label, preserving Button7/8 indices.
Series 300/330 retain their independent Button6 cab-door selection.
Each connected, traversable gangway automatically stores the partition and farebox
at that end only. A sealed gangway retains the manual setting.

Both mechanisms move at constant angular speed, full travel in 0.5 seconds.
Mid-travel reversal starts from the current angle. Motion uses a monotonic clock.
Partition: stored to exposed = +198 degrees around vertical Y.
This reverses the previous -162 degree arc while preserving both endpoints.
Front pivot (metres): X=0.25630169, Z=9.34423646; rear X/Z are negated.
Angle and duration can be edited in asari_cab_motion.js.

Original oneman1/2 were consolidated into oneman_pivot1_front/rear.
Original oneman3/4 were consolidated into oneman_pivot2_front/rear.
Stored geometry, materials and UV coordinates are retained exactly.
Partition cab-light emission also fades; base textures remain visible.

Headlights: rise 0.075 seconds, fall 0.15 seconds.
Farebox and partition light fades retain their prior 0.15/0.30 second timing.
Normal/alpha passes always render L_main_1sub / L_main_2sub.
Light passes overlay L_main_1 / L_main_2 using WHITE RGB and faded opacity.
Connected ends are immediately prevented from emitting light.
Both editable model UV sets are retained; no UV inference or replacement occurs.
The four headlight objects in the 300/330 actionparts models are synchronized
from kiha40_as_1.mqo / kiha40_as_3.mqo respectively.
After editing these base models again, synchronize the actionparts headlight
objects before packaging. Keep action/hit objects intact.

Backup: backups/before_cab_motion_all_20261028
Validation and staged archives: trials/cab_motion_all_20261028
Minecraft runtime appearance still requires in-game verification.

haisen is rendered on both normal and alpha passes (0/1) in all 53 renderers.
It is never submitted to emissive passes.
Latest backup: backups/before_oneman_followup_20261028
