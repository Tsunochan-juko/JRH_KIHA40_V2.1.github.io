importPackage(Packages.jp.ngt.ngtlib.util);
importPackage(Packages.jp.ngt.rtm.sound);
importPackage(Packages.jp.ngt.ngtlib.io);

function onUpdate(su) {
    updateSoundMaker(su);
}

/*
## RTM Sound Maker ##
Version 1.0

Copyright (c) 2021 hi03

This software is released under the MIT License.
http://opensource.org/licenses/mit-license.php
*/

//Input data
var Dmain = 'sound_default';
var SoundMap = {"823sound":"223.823sound","engine1":"223.engine1","engine3":"223.engine3","engine4":"223.engine4","engine5":"223.engine5","stop":"223.stop","brake1":"223.brake1","engine6":"223.engine6","brake2":"223.brake2"};
var SoundData = [{"soundName":"823sound","pitchData":[[{"speed":1,"value":0.5,"func":"0*x+1"},{"speed":11,"value":0.51,"func":"0.025*x+0.75"},{"speed":12,"value":0.52,"func":"0.0039*x+1"},null,null,null,null,null,null,null,null,null,null,null,null],[{"speed":1,"value":0.5,"func":"0*x+1"},{"speed":11,"value":0.51,"func":"0.025*x+0.75"},{"speed":12,"value":0.52,"func":"0.0039*x+1"},null,null,null,null,null,null,null,null,null,null,null,null],[{"speed":1,"value":0.5,"func":"0*x+1"},{"speed":20,"value":0.6,"func":"0*x+1.2"},{"speed":95,"value":0.65,"func":"0*x+1.3"},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]],"volumeData":[[{"speed":0,"value":0,"func":"0.02*x+0"},{"speed":3,"value":0.47,"func":"-0.01*x+0.5"},{"speed":95,"value":0.6,"func":"0*x+0.6"},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],[{"speed":0,"value":0,"func":"0.02*x+0"},{"speed":3,"value":0.47,"func":"-0.01*x+0.5"},{"speed":95,"value":0.6,"func":"0*x+0.6"},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null],[{"speed":0,"value":0,"func":"0.02*x+0"},{"speed":3,"value":0.47,"func":"-0.01*x+0.5"},{"speed":5,"value":0.96,"func":"-0.0061*x+1"},{"speed":12,"value":0.92,"func":"-0.0061*x+1"},{"speed":95,"value":0.2,"func":"0*x+0.2"},null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null]]},{"soundName":"823sound","pitchData":[[null],[{"speed":0,"value":0.5,"func":"0*x+1"},{"speed":100,"value":0.5,"func":"0*x+1"},null],[{"speed":0,"value":0.5,"func":"0*x+1"}]],"volumeData":[[null,null,null,null,null,null],[{"speed":0,"value":1,"func":"0*x+1"},{"speed":95,"value":0,"func":"0*x+0"},{"speed":100,"value":0,"func":"0*x+0"},null,null,null,null,null],[{"speed":0,"value":1,"func":"0*x+1"},{"speed":2,"value":0.98,"func":"-0.0061*x+1"},{"speed":3,"value":0,"func":"0*x+0"},{"speed":5,"value":0,"func":"-0.5*x+2.5"},{"speed":10,"value":0,"func":"-0.5*x+2.5"},null]]},{"soundName":"engine1","pitchData":[[],[],[{"speed":0,"value":0.525,"func":"0*x+1.05"},{"speed":12,"value":0.535,"func":"-0.0021*x+1.1"},{"speed":19,"value":0.57,"func":"0*x+1.15"},{"speed":40,"value":0.645,"func":"0.0111*x+0.8555"},null]],"volumeData":[[],[],[{"speed":0,"value":0,"func":"0*x+0"},{"speed":15,"value":1,"func":"0.5*x+-6.5"},{"speed":45,"value":0,"func":"0*x+0"},{"speed":95,"value":0,"func":"0*x+0"},null,null]]},{"soundName":"823sound","pitchData":[[],[],[{"speed":1,"value":0.5,"func":"0*x+1"},{"speed":10,"value":0.6,"func":"0*x+1.2"},{"speed":15,"value":0.6,"func":"0*x+1.2"},null,null,null]],"volumeData":[[],[],[{"speed":1,"value":0,"func":"0*x+0"},{"speed":2,"value":1,"func":"0*x+1"},{"speed":6,"value":0.95,"func":"0*x+0.95"},{"speed":12,"value":0,"func":"0*x+0"},{"speed":95,"value":0,"func":"0*x+0"},null,null]]},{"soundName":"engine3","pitchData":[[],[],[{"speed":0,"value":0.5,"func":"0*x+1"},{"speed":25,"value":0.5,"func":"0*x+1"},{"speed":95,"value":0.625,"func":"0*x+1.25"}]],"volumeData":[[],[],[{"speed":17,"value":0,"func":"0*x+0"},{"speed":50,"value":0.7,"func":"0*x+0.7"},{"speed":65,"value":0.9,"func":"0*x+0.9"},{"speed":95,"value":0.7,"func":"0*x+0.7"},null,null,null,null,null,null,null,null,null]]},{"soundName":"engine4","pitchData":[[null,null,null],[],[{"speed":0,"value":0.5,"func":"0*x+1"},{"speed":40,"value":0.5,"func":"0*x+1"},null,{"speed":95,"value":0.525,"func":"0*x+1.05"},null,null]],"volumeData":[[null,null,null],[],[{"speed":30,"value":0,"func":"0*x+0"},{"speed":35,"value":1,"func":"0*x+1"},{"speed":40,"value":1,"func":"0*x+1"},null,{"speed":95,"value":0,"func":"0*x+0"},null]]},{"soundName":"engine5","pitchData":[[null,null],[null,null],[{"speed":0,"value":0.5,"func":"0*x+1"},{"speed":95,"value":0.55,"func":"0*x+1.1"}]],"volumeData":[[null,null,null,null,null],[null,null,null,null,null],[{"speed":0,"value":0,"func":"0*x+0"},{"speed":20,"value":0,"func":"0*x+0"},{"speed":60,"value":1,"func":"0*x+1"},null,null]]},{"soundName":"stop","pitchData":[[{"speed":0,"value":0.5,"func":"0*x+1"},{"speed":10,"value":0.5,"func":"0*x+1"},null,null],[{"speed":0,"value":0.5,"func":"0*x+1"},{"speed":100,"value":0.5,"func":"0*x+1"}],[null,null,null]],"volumeData":[[{"speed":0,"value":0.6,"func":"0*x+0.6"},{"speed":20,"value":0.2,"func":"0*x+0.2"},{"speed":30,"value":0,"func":"0*x+0"},null,null],[{"speed":0,"value":0.5,"func":"0*x+0.5"},{"speed":100,"value":0.5,"func":"0*x+0.5"}],[]]},{"soundName":"brake1","pitchData":[[{"speed":0,"value":0.5,"func":"0*x+1"},{"speed":95,"value":0.5,"func":"0*x+1"}],[null,null],[]],"volumeData":[[{"speed":0,"value":0,"func":"0*x+0"},{"speed":20,"value":0.5,"func":"0*x+0.5"},{"speed":95,"value":0.5,"func":"0*x+0.5"}],[null,null,null],[]]},{"soundName":"engine6","pitchData":[[{"speed":0,"value":0.45,"func":"0*x+0.9"},{"speed":22,"value":0.475,"func":"0*x+0.95"},{"speed":50,"value":0.5,"func":"0*x+1"},{"speed":95,"value":0.53,"func":"0*x+1.06"},null],[{"speed":0,"value":0.5,"func":"0*x+1"},{"speed":50,"value":0.5,"func":"0*x+1"},{"speed":95,"value":0.53,"func":"0*x+1.06"},null,null,null],[{"speed":0,"value":0.45,"func":"0*x+0.9"},{"speed":22,"value":0.475,"func":"0*x+0.95"},{"speed":50,"value":0.5,"func":"0*x+1"},{"speed":95,"value":0.53,"func":"0*x+1.06"},null]],"volumeData":[[{"speed":0,"value":0,"func":"0*x+0"},null,{"speed":20,"value":0.9,"func":"0*x+0.9"},{"speed":50,"value":1,"func":"0*x+1"}],[{"speed":0,"value":0,"func":"0*x+0"},{"speed":17,"value":0,"func":"0*x+0"},{"speed":100,"value":0.5,"func":"0*x+0.5"},null,null,null],[{"speed":0,"value":0,"func":"0*x+0"},{"speed":17,"value":0,"func":"0*x+0"},{"speed":20,"value":0.9,"func":"0*x+0.9"},{"speed":50,"value":1,"func":"0*x+1"}]]},{"soundName":"brake2","pitchData":[[{"speed":0,"value":0.5,"func":"0*x+1"},{"speed":100,"value":0.5,"func":"0*x+1"},null,null,null,null],[],[]],"volumeData":[[{"speed":0,"value":0,"func":"0*x+0"},{"speed":1,"value":1,"func":"0*x+1"},{"speed":3,"value":1,"func":"0*x+1"},{"speed":4,"value":0,"func":"0*x+0"},null,null,null],[],[]]}];
//Input data <END>

function updateSoundMaker(su) {
    var entity = su.getEntity();
    var dataMap = entity.getResourceState().getDataMap();
    var speed = su.getSpeed();
    var notch = su.getNotch();
    var notchIndex = 0;
    if (notch === 0) notchIndex = 1;
    if (notch > 0) notchIndex = 2;
    var prevNotchIndex = dataMap.getInt("prevNotchIndex");
    dataMap.setInt("prevNotchIndex", notchIndex, 0);
    var pitData = [];
    var volData = [];
    var soundNameList = [];
    SoundData.forEach(function (layer) {
        soundNameList.push(layer.soundName);
        pitData.push(layer.pitchData);
        volData.push(layer.volumeData);
    });
    soundNameList.forEach(function (name, layerIndex) {
        if (notchIndex !== prevNotchIndex) su.stopSound(Dmain, SoundMap[name]);
        var pitch = getValue(pitData[layerIndex], speed, notchIndex) * 2;
        var volume = getValue(volData[layerIndex], speed, notchIndex);
        su.playSound(Dmain, SoundMap[name], volume, pitch, true);
    });
}

function getValue(data, speed, notchIndex) {//pitchData or volumeData
    var points = data[notchIndex];
    var currentPoint = null;
    var nextPoint = null;
    var value = 0;
    for(var i = 0; i < points.length; i++){
        currentPoint = points[i];
        if (!currentPoint) continue;
        if (i < points.length) nextPoint = points[i + 1];
        if (!nextPoint) {
            value = currentPoint.value;
            break;
        }
        if (currentPoint.speed <= speed && speed <= nextPoint.speed) {
            var x1 = currentPoint.speed;
            var y1 = currentPoint.value;
            var x2 = nextPoint.speed;
            var y2 = nextPoint.value;
            var a = ((y2 - y1) / (x2 - x1));
            var b = ((x2 * y1 - x1 * y2) / (x2 - x1));
            var r = a * speed + b;
            if (r > 1.0) r = 1.0;
            if (r < 0.0) r = 0.0;
            value = r;
            break;
        }
    }
    return value;
}
//RTM Sound Maker <END>
