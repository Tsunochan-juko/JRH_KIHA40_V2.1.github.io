// Included after the normal engine/horn updater and asari300_actionparts.js.
var as300SoundStates = new Packages.java.util.WeakHashMap();
var AS300_SOUND_DOMAIN = "sound_asarikiha40";
var AS300_NAOMI_INTERVAL = 15 * 20;
var AS300_INSIDE_INTERVAL = 64 * 20;

function as300PeriodicUpdate(su, state, now, enabled) {
    var p = state.periodic;
    if (!enabled) {
        // Stop immediately whenever the mode or door condition turns off.
        su.stopSound(AS300_SOUND_DOMAIN, "naomi");
        su.stopSound(AS300_SOUND_DOMAIN, "inside");
        state.periodic = {enabled: false};
        return;
    }
    if (!p || !p.enabled || now < p.lastTick) {
        // Start both announcements as soon as semi-auto permission opens.
        var initialNames = ["naomi", "inside"];
        for (var initialIndex = 0; initialIndex < initialNames.length; initialIndex++) {
            var initialName = initialNames[initialIndex];
            su.stopSound(AS300_SOUND_DOMAIN, initialName);
            su.playSound(AS300_SOUND_DOMAIN, initialName, 1.0, 1.0, false);
        }
        state.periodic = {enabled: true, lastTick: now,
            naomi: now + AS300_NAOMI_INTERVAL, inside: now + AS300_INSIDE_INTERVAL};
        return;
    }
    p.lastTick = now;
    var names = ["naomi", "inside"];
    var intervals = [AS300_NAOMI_INTERVAL, AS300_INSIDE_INTERVAL];
    for (var i = 0; i < names.length; i++) {
        var name = names[i], interval = intervals[i];
        if (now >= p[name]) {
            su.stopSound(AS300_SOUND_DOMAIN, name);
            su.playSound(AS300_SOUND_DOMAIN, name, 1.0, 1.0, false);
            // Preserve phase, skipping missed repeats instead of bursting after a delay.
            p[name] += (Math.floor((now - p[name]) / interval) + 1) * interval;
        }
    }
}

function as300PlayDoorSound(su, kind) {
    // A playing sound is normally only updated by playSound(). Explicitly remove it
    // before starting the requested one-shot, even when the last operation is unfinished.
    su.stopSound(AS300_SOUND_DOMAIN, "open");
    su.stopSound(AS300_SOUND_DOMAIN, "close");
    su.playSound(AS300_SOUND_DOMAIN, kind, 1.0, 1.0, false);
}

function as300DoorSideMoving(entity, side) {
    try {
        var raw = String(entity.getResourceState().getDataMap().getString("Asari300DoorMotionV1"));
        var motion = JSON.parse(raw);
        if (Array.isArray(motion) && motion.length === 4) return Number(motion[side]) > 0.002 || Number(motion[side + 2]) > 0.002;
    } catch (ignored) {}
    return false;
}

function as300SoundEvents(entity) {
    try {
        var events = JSON.parse(String(entity.getResourceState().getDataMap().getString("Asari300DoorSoundsV3")));
        return Array.isArray(events) ? events : [];
    } catch (ignored) { return []; }
}

function as300DoorSoundUpdate(su) {
    var entity = su.getEntity();
    if (entity == null) return;
    var state = as300SoundStates.get(su);
    if (state == null) { state = {periodic: {enabled: false}}; as300SoundStates.put(su, state); }
    var sealed = as300IsSealed(entity);
    var standard = Number(entity.getTrainStateData(TrainState.TrainStateType.State_Door.id));
    as300Gate(entity, 0);
    as300Gate(entity, 1);
    as300PeriodicUpdate(su, state, as300Tick(entity), !sealed && as300Semi(entity) && (standard & 3) !== 0);
    // Door operation sounds are consumed by asari_linear_door_audio.js from actual motion edges.
}
