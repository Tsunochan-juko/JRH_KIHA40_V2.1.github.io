// Shared KiHa40 cab partition motion and headlight fade. Seconds use a monotonic clock.
var ASARI_CAB_MOVE_SECONDS = 0.5;
var asariOnemanParts = null;
var asariOnemanMaterials={};
function asariCabStoredEnds(entity, data, controlButton, result) {
    if(result==null)result=[];
    // One-man partition follows Button5; farebox exposure uses its own Button9.
    var exposed = entity != null && (controlButton === 9 ?
        Number(entity.getResourceState().getDataMap().getInt("Button8")) === 1 : data.buttons[5] == 1);
    for (var end = 0; end < 2; end++) {
        var connected = end === 0 ? data.connected0 : data.connected1;
        var passage = entity != null && connected && !asariDoorwaySealedEnd(entity, end);
        result[end] = entity != null && (!exposed || passage);
    }
    return result;
}
function asariCabPose(entity,data,now,controlButton){
    var key=controlButton===9?'asariFareboxMotion':'asariOnemanMotion',state=data[key];
    if(state!=null&&state.frame===now)return state.pose;
    if(state==null){
        var stored=asariCabStoredEnds(entity,data,controlButton);
        var targets=[stored[0]?0:1,stored[1]?0:1];
        state=data[key]={time:now,frame:now,levels:targets.slice(0),targets:targets,stored:stored};
        state.pose={levels:state.levels,stored:state.stored};
        return state.pose;
    }
    asariCabStoredEnds(entity,data,controlButton,state.stored);
    var step=Math.max(0,now-state.time)/ASARI_CAB_MOVE_SECONDS;
    for(var i=0;i<2;i++){
        var delta=state.targets[i]-state.levels[i];
        if(delta!==0)state.levels[i]+=Math.max(-step,Math.min(step,delta));
        state.targets[i]=state.stored[i]?0:1;
    }
    state.time=now;state.frame=now;
    return state.pose;
}

function asariInitOneman(type) {
    asariOnemanMaterials={};
    asariOnemanParts = {
        front: renderer.registerParts(new Parts('oneman_pivot' + type + '_front')),
        rear: renderer.registerParts(new Parts('oneman_pivot' + type + '_rear'))
    };
}
function asariCabRotate(angle, x, z, draw) {
    var previousMode = GL11.glGetInteger(GL11.GL_MATRIX_MODE);
    GL11.glMatrixMode(GL11.GL_MODELVIEW);
    GL11.glPushMatrix();
    try { renderer.rotate(angle, 'Y', x, 0, z); draw(); }
    finally {
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glPopMatrix();
        GL11.glMatrixMode(previousMode);
    }
}
function asariRenderOneman(entity,pass,data){
    if(pass<0||pass>4||asariOnemanParts==null)return;
    var mat=Number(renderer.currentMatId),mask=asariOnemanMaterials[mat];
    if(mask===undefined){
        mask=(asariPartUsesMaterial(asariOnemanParts.front)?1:0)|(asariPartUsesMaterial(asariOnemanParts.rear)?2:0);
        asariOnemanMaterials[mat]=mask;
    }
    if(mask===0)return;
    var now=asariFareboxLightTime(entity),cached=data.asariOnemanFrame;
    if(cached==null)cached=data.asariOnemanFrame={time:null,targets:[false,false]};
    if(cached.time!==now){
        if(data.asariOnemanLight==null)data.asariOnemanLight={};
        cached.targets[0]=asariCabRoomLit(entity,data,0);cached.targets[1]=asariCabRoomLit(entity,data,1);
        cached.pose=asariCabPose(entity,data,now,5);
        cached.levels=asariUpdateFareboxLightLevels(data.asariOnemanLight,now,cached.targets);
        cached.time=now;
    }
    for(var end=0;end<2;end++){
        if(!(mask&(1<<end)))continue;
        if(pass>=2&&cached.levels[end]<=0)continue;
        asariRenderOnemanEnd(end===0?asariOnemanParts.front:asariOnemanParts.rear,end===0?1:-1,cached.pose.levels[end],pass,cached.levels[end]);
    }
}
function asariRenderOnemanEnd(part,sign,exposure,pass,level){
    if(exposure<=0){asariRenderFareboxSurface(part,pass,level);return;}
    var previousMode=GL11.glGetInteger(GL11.GL_MATRIX_MODE);
    GL11.glMatrixMode(GL11.GL_MODELVIEW);GL11.glPushMatrix();
    try{
        renderer.rotate(198*exposure,'Y',sign*0.25630169,0,sign*9.34423646);
        asariRenderFareboxSurface(part,pass,level);
    }finally{GL11.glMatrixMode(GL11.GL_MODELVIEW);GL11.glPopMatrix();GL11.glMatrixMode(previousMode);}
}

function asariHeadlightLevels(entity, data, now) {
    if(data.asariHeadlightLight==null)data.asariHeadlightLight={};
    var frame=data.asariHeadlightFrame;
    if(frame==null)frame=data.asariHeadlightFrame={time:null,targets:[false,false]};
    if(frame.time===now)return frame.levels;
    var targets=frame.targets;
    targets[0]=data.buttons[1]==1&&data.states[0]==0&&!data.connected0;
    targets[1]=data.buttons[1]==1&&data.states[0]==1&&!data.connected1;
    var levels = asariUpdateFareboxLightLevels(data.asariHeadlightLight, now, targets, 0.075, 0.15);
    // Connected faces must never illuminate the neighbouring vehicle.
    if (data.connected0) levels[0] = 0;
    if (data.connected1) levels[1] = 0;
    frame.time=now;frame.levels=levels;
    return levels;
}
function asariRenderHeadlights(entity, pass, data) {
    if (pass < 0 || pass > 4) return;
    var levels = entity == null ? [1, 1] : asariHeadlightLevels(entity, data, asariFareboxLightTime(entity));
    if (pass < 2) { L_main_1sub.render(renderer); L_main_2sub.render(renderer); return; }
    if (entity == null) { asariRenderFareboxSurface(L_main_1, pass, 1); asariRenderFareboxSurface(L_main_2, pass, 1); return; }
    asariRenderFareboxSurface(L_main_1, pass, levels[0]);
    asariRenderFareboxSurface(L_main_2, pass, levels[1]);
}
