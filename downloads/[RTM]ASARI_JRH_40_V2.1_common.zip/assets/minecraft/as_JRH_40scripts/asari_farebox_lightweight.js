// One stored mesh per vehicle end; exposed pose is a rotation of that mesh.
// MQO coordinates are centimetres. renderer.rotate() takes metres and degrees.
var asariFareboxParts = null;
var asariFareboxMaterials={};
var ASARI_FAREBOX_LIGHT_RISE_SECONDS = 0.15;
var ASARI_FAREBOX_LIGHT_FALL_SECONDS = 0.30;
var asariFareboxGeometry = {
    1: {x: 0.4417186202009722, z: 8.7235659486133, angle: 83.07264734173998},
    2: {x: 0.4476632641816423, z: 8.748129750260302, angle: 87.20615364811941}
};

function asariInitFarebox(type) {
    asariFareboxMaterials={};
    var prefix = "farebox" + type + "_";
    asariFareboxParts = {
        geometry: asariFareboxGeometry[type],
        front: {
            body: renderer.registerParts(new Parts(prefix + "front")),
            lamp: renderer.registerParts(new Parts(prefix + "front_lamp"))
        },
        rear: {
            body: renderer.registerParts(new Parts(prefix + "rear")),
            lamp: renderer.registerParts(new Parts(prefix + "rear_lamp"))
        }
    };
}

function asariFareboxLightTime(entity) { return asariRenderFrameTime(entity); }

function asariUpdateFareboxLightLevels(data,now,targets,riseSeconds,fallSeconds){
    if(riseSeconds==null)riseSeconds=ASARI_FAREBOX_LIGHT_RISE_SECONDS;
    if(fallSeconds==null)fallSeconds=ASARI_FAREBOX_LIGHT_FALL_SECONDS;
    var state=data.asariFareboxLights;
    if(state==null){
        state={time:now,levels:[],targets:[]};
        for(var initial=0;initial<targets.length;initial++){state.levels[initial]=targets[initial]?1:0;state.targets[initial]=targets[initial];}
        data.asariFareboxLights=state;
    }
    var elapsed=Math.max(0,now-state.time);
    if(elapsed>0)for(var i=0;i<state.levels.length;i++){
        var target=state.targets[i],goal=target?1:0;
        if(state.levels[i]===goal)continue;
        var step=elapsed/(target?riseSeconds:fallSeconds);
        state.levels[i]=target?Math.min(1,state.levels[i]+step):Math.max(0,state.levels[i]-step);
    }
    state.time=now;
    for(var j=0;j<targets.length;j++)state.targets[j]=targets[j];
    return state.levels;
}

function asariRenderFareboxSurface(part, pass, level) {
    if (!asariPartUsesMaterial(part)) return;
    // Opaque and alpha base textures remain fixed throughout the transition.
    if (pass < 2) { part.render(renderer); return; }
    if (level <= 0) return;
    GL11.glPushAttrib(GL11.GL_CURRENT_BIT | GL11.GL_COLOR_BUFFER_BIT |
        GL11.GL_ENABLE_BIT | GL11.GL_DEPTH_BUFFER_BIT);
    try {
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glDepthFunc(GL11.GL_LEQUAL);
        GL11.glDepthMask(false);
        var alpha = (pass === 3 || pass === 4) ? 0.8 : 1;
        // Blend the light texture over the base without darkening its RGB.
        GL11.glColor4f(1, 1, 1, alpha * level);
        part.render(renderer);
    } finally {
        GL11.glPopAttrib();
    }
}

function asariRenderFareboxEnd(parts, geometry, sign, exposure, pass, bodyLevel, lampLevel) {
    if (!asariPartUsesMaterial(parts.body) && !asariPartUsesMaterial(parts.lamp)) return;
    if (pass >= 2 && bodyLevel <= 0 && lampLevel <= 0) return;
    if (exposure <= 0) {
        asariRenderFareboxSurface(parts.body, pass, bodyLevel);
        asariRenderFareboxSurface(parts.lamp, pass, lampLevel);
        return;
    }
    var previousMode = GL11.glGetInteger(GL11.GL_MATRIX_MODE);
    GL11.glMatrixMode(GL11.GL_MODELVIEW);
    GL11.glPushMatrix();
    try {
        renderer.rotate(-geometry.angle * exposure, 'Y', sign * geometry.x, 0, sign * geometry.z);
        asariRenderFareboxSurface(parts.body, pass, bodyLevel);
        asariRenderFareboxSurface(parts.lamp, pass, lampLevel);
    } finally {
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glPopMatrix();
        GL11.glMatrixMode(previousMode);
    }
}

function asariRenderFareboxes(entity,pass,data){
    if(pass<0||pass>4||asariFareboxParts==null)return;
    var mat=Number(renderer.currentMatId),mask=asariFareboxMaterials[mat];
    if(mask===undefined){
        mask=0;
        if(asariPartUsesMaterial(asariFareboxParts.front.body)||asariPartUsesMaterial(asariFareboxParts.front.lamp))mask|=1;
        if(asariPartUsesMaterial(asariFareboxParts.rear.body)||asariPartUsesMaterial(asariFareboxParts.rear.lamp))mask|=2;
        asariFareboxMaterials[mat]=mask;
    }
    if(mask===0)return;
    var now=asariFareboxLightTime(entity),cached=data.asariFareboxFrame;
    if(cached==null)cached=data.asariFareboxFrame={time:null,targets:[false,false,false,false]};
    if(cached.time!==now){
        var pose=asariCabPose(entity,data,now,9),targets=cached.targets;
        for(var end=0;end<2;end++){
            var cabLit=asariCabRoomLit(entity,data,end);
            targets[end*2]=entity==null||(pose.stored[end]?cabLit:data.states[11]>0);
            targets[end*2+1]=entity==null||cabLit;
        }
        cached.time=now;cached.pose=pose;cached.levels=asariUpdateFareboxLightLevels(data,now,targets);
    }
    for(var renderEnd=0;renderEnd<2;renderEnd++)if(mask&(1<<renderEnd)){
        asariRenderFareboxEnd(renderEnd===0?asariFareboxParts.front:asariFareboxParts.rear,
            asariFareboxParts.geometry,renderEnd===0?1:-1,cached.pose.levels[renderEnd],pass,
            cached.levels[renderEnd*2],cached.levels[renderEnd*2+1]);
    }
}
