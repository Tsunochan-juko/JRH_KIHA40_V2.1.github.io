importPackage(Packages.jp.ngt.rtm.entity.train.util);
//include <as_JRH_40scripts/asari_hold_DMF13_40_horn_as.js>
//include <as_JRH_40scripts/asari300_actionparts.js>
//include <as_JRH_40scripts/asari300_door_sound.js>
var as300OriginalSoundUpdate = onUpdate;
onUpdate = function(su) {
    asariPrepareSoundButtons(su); try { as300OriginalSoundUpdate(su); } finally { as300DoorSoundUpdate(su); } };

//include <as_JRH_40scripts/asari_button_layout.js>
