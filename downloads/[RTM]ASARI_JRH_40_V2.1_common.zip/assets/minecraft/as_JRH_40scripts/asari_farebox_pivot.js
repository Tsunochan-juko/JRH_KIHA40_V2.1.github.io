// One stored mesh per vehicle end; exposed pose is a rotation of that mesh.
// MQO coordinates are centimetres. renderer.rotate() takes metres and degrees.
var asariFareboxParts = null;
var ASARI_FAREBOX_LIGHT_RISE_SECONDS = 0.15;
var ASARI_FAREBOX_LIGHT_FALL_SECONDS = 0.30;
var asariFareboxGeometry = {
    1: {x: 0.4417186202009722, z: 8.7235659486133, angle: 83.07264734173998},
    2: {x: 0.4476632641816423, z: 8.748129750260302, angle: 87.20615364811941}
};

function asariInitFarebox(type) {
    var prefix = "farebox" + type + "_";
    asariFareboxParts = {
        geometry: asariFareboxGeometry[type],
        front: {
            body: renderer.registerParts(new Parts(prefix + "front")),
            lamp: renderer.registerParts(new Parts(prefix + "front_lamp"))
        },
        rear: {
            body: renderer.registerParts(new Parts(prefix + "rear")),
            lamp: renderer.registerParts(new Parts(prefix + "rear_lamp"))
        }
    };
}

function asariFareboxLightTime(entity) { return asariRenderFrameTime(entity); }

function asariUpdateFareboxLightLevels(data, now, targets, riseSeconds, fallSeconds) {
    if (riseSeconds == null) riseSeconds = ASARI_FAREBOX_LIGHT_RISE_SECONDS;
    if (fallSeconds == null) fallSeconds = ASARI_FAREBOX_LIGHT_FALL_SECONDS;
    var state = data.asariFareboxLights;
    if (state == null) {
        state = {time: now, levels: [], targets: targets.slice(0)};
        for (var initial = 0; initial < targets.length; initial++)
            state.levels[initial] = targets[initial] ? 1 : 0;
        data.asariFareboxLights = state;
    }
    var elapsed = Math.max(0, now - state.time);
    for (var i = 0; i < state.levels.length; i++) {
        // Finish the preceding interval before observing a new target. This keeps
        // reversals continuous and avoids snapping after the car was off screen.
        var target = state.targets[i];
        var step = elapsed / (target ? riseSeconds : fallSeconds);
        state.levels[i] = target ? Math.min(1, state.levels[i] + step) :
            Math.max(0, state.levels[i] - step);
    }
    state.time = now;
    state.targets = targets.slice(0);
    return state.levels;
}

function asariRenderFareboxSurface(part, pass, level) {
    if (!asariPartUsesMaterial(part)) return;
    // Opaque and alpha base textures remain fixed throughout the transition.
    if (pass < 2) { part.render(renderer); return; }
    if (level <= 0) return;
    GL11.glPushAttrib(GL11.GL_CURRENT_BIT | GL11.GL_COLOR_BUFFER_BIT |
        GL11.GL_ENABLE_BIT | GL11.GL_DEPTH_BUFFER_BIT);
    try {
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glDepthFunc(GL11.GL_LEQUAL);
        GL11.glDepthMask(false);
        var alpha = (pass === 3 || pass === 4) ? 0.8 : 1;
        // Blend the light texture over the base without darkening its RGB.
        GL11.glColor4f(1, 1, 1, alpha * level);
        part.render(renderer);
    } finally {
        GL11.glPopAttrib();
    }
}

function asariRenderFareboxEnd(parts, geometry, sign, exposure, pass, bodyLevel, lampLevel) {
    if (!asariPartUsesMaterial(parts.body) && !asariPartUsesMaterial(parts.lamp)) return;
    if (pass >= 2 && bodyLevel <= 0 && lampLevel <= 0) return;
    if (exposure <= 0) {
        asariRenderFareboxSurface(parts.body, pass, bodyLevel);
        asariRenderFareboxSurface(parts.lamp, pass, lampLevel);
        return;
    }
    var previousMode = GL11.glGetInteger(GL11.GL_MATRIX_MODE);
    GL11.glMatrixMode(GL11.GL_MODELVIEW);
    GL11.glPushMatrix();
    try {
        renderer.rotate(-geometry.angle * exposure, 'Y', sign * geometry.x, 0, sign * geometry.z);
        asariRenderFareboxSurface(parts.body, pass, bodyLevel);
        asariRenderFareboxSurface(parts.lamp, pass, lampLevel);
    } finally {
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glPopMatrix();
        GL11.glMatrixMode(previousMode);
    }
}

function asariRenderFareboxes(entity, pass, data) {
    if (pass < 0 || pass > 4 || asariFareboxParts == null) return;

    var now = asariFareboxLightTime(entity);
    var cached = data.asariFareboxFrame;
    if (cached == null || cached.time !== now) {
    var pose = asariCabPose(entity, data, now, 9);
    var storedEnds = [], targets = [];
    for (var end = 0; end < 2; end++) {
        var stored = pose.stored[end];
        var cabLit = asariCabRoomLit(entity, data, end);
        storedEnds[end] = stored;
        targets.push(entity == null || (stored ? cabLit : data.states[11] > 0));
        targets.push(entity == null || cabLit);
    }
    var levels = asariUpdateFareboxLightLevels(data, now, targets);
    cached = data.asariFareboxFrame = {time:now, pose:pose, levels:levels};
    }
    var pose = cached.pose, levels = cached.levels;
    for (var renderEnd = 0; renderEnd < 2; renderEnd++) {
        asariRenderFareboxEnd(renderEnd === 0 ? asariFareboxParts.front : asariFareboxParts.rear,
            asariFareboxParts.geometry, renderEnd === 0 ? 1 : -1, pose.levels[renderEnd], pass,
            levels[renderEnd * 2], levels[renderEnd * 2 + 1]);
    }
}
