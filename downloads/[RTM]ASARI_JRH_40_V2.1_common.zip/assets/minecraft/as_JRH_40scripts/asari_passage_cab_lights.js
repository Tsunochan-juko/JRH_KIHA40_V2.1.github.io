// A traversable coupled end lights with the vehicle's passenger interior lights.
var asariCabRooms = null;
function asariCabRoomLitRaw(entity, data, end) {
    if (entity == null) return true;
    if (asariDoorwaySealedEnd(entity, end)) return false;
    var connected = end === 0 ? data.connected0 : data.connected1;
    if (connected) {
        // Connected, traversable cab end is emissive only while the vehicle's
        // passenger interior light is on (RTM train state 11).
        var interiorLight = Number(data.states[11]);
        try {
            if (typeof entity.getTrainStateData === "function")
                interiorLight = Number(entity.getTrainStateData(11));
        } catch (ignoredInteriorLightRead) {}
        return interiorLight >= 1;
    }
    // Manual crew-room lighting was removed; coupled passage lighting remains above.
    return false;
}
function asariInitCabRooms(names) {
    var front = [], rear = [];
    for (var i = 0; i < names.length; i++) {
        front.push(names[i] + '_cab_front');
        rear.push(names[i] + '_cab_rear');
    }
    asariCabRooms = [renderer.registerParts(new Parts(front[0], front[1], front[2], front.length > 3 ? front[3] : "")), renderer.registerParts(new Parts(rear[0], rear[1], rear[2], rear.length > 3 ? rear[3] : ""))];
}
function asariRenderCabRooms(entity, pass, data) {
    if (asariCabRooms == null || pass < 0 || pass > 4) return;
    for (var end = 0; end < 2; end++)
        if (pass < 2 || asariCabRoomLit(entity, data, end)) asariCabRooms[end].render(renderer);
}

// Per-render context is local to each model's script engine.
var asariCabRenderEntity=null,asariCabRenderData=null,asariCabRenderPass=0;
var ASARI_CAB_REST_PRESSURE=[900,500,0,500];
function asariSetCabContext(entity,pass,data) {
    asariCabRenderEntity=entity;asariCabRenderPass=pass;asariCabRenderData=data;
}
function asariCabPartPass(entity,pass,data,end) {
    if (pass===0 || pass===1) return true;
    return pass>=2 && pass<=4 && asariCabRoomLit(entity,data,end);
}
function asariCabRoomLit(entity,data,end) {
    if (entity==null) return true;
    var now=asariRenderFrameTime(entity),state=data.asariCabLightingFrame;
    if (state==null || state.time!==now) state=data.asariCabLightingFrame={time:now,values:[]};
    if (state.values[end]===undefined) state.values[end]=asariCabRoomLitRaw(entity,data,end);
    return state.values[end];
}
function asariCabRawPartDraw(part) {
    // Sway is disabled. An unresolved global typeof triggers expensive Java
    // class lookups under Nashorn mozilla_compat/importPackage on every draw.
    part.render(renderer);
}
function asariDrawCabPart(part,z) {
    var entity=asariCabRenderEntity,data=asariCabRenderData,pass=asariCabRenderPass,end=z<0?1:0;
    if (!asariCabPartPass(entity,pass,data,end)) return;
    // Cab handles/needles use mat4, which has no Light slot. Illuminate their
    // normal texture without adding a new emissive material pass to every car.
    if (entity==null || pass>=2 || !asariCabRoomLit(entity,data,end)) {asariCabRawPartDraw(part);return;}
    var helper=Packages.net.minecraft.client.renderer.OpenGlHelper;
    var oldX=NaN,oldY=NaN;
    try {oldX=Number(helper.lastBrightnessX);oldY=Number(helper.lastBrightnessY);} catch (ignoredLightmapFields) {}
    if (!isFinite(oldX) || !isFinite(oldY)) {
        var packed=Number(entity.func_70070_b(1));oldX=packed&65535;oldY=packed>>>16;
    }
    GL11.glPushAttrib(GL11.GL_LIGHTING_BIT|GL11.GL_ENABLE_BIT|GL11.GL_CURRENT_BIT);
    try {
        GL11.glDisable(GL11.GL_LIGHTING);
        Packages.jp.ngt.ngtlib.renderer.GLHelper.setLightmapMaxBrightness();
        asariCabRawPartDraw(part);
    } finally {
        try {helper.func_77475_a(helper.field_77476_b,oldX,oldY);}
        finally {GL11.glPopAttrib();}
    }
}
function asariRenderCabNotches(entity,pass,data,powerAngle,brakeAngle,cabPosX,cabPosY,cabPosZ) {
    for (var end=0;end<2;end++) {
        if(!asariCabControlEndVisible(entity,data,end))continue;
        if (!asariCabPartPass(entity,pass,data,end)) continue;
        var sign=end===0?1:-1,connected=end===0?data.connected0:data.connected1;
        renderCabPart(end===0?ebtf_MCa:ebtf_MCa2,connected,powerAngle,'Y',
            (cabPosX+sign*121.20)/100,(cabPosY+129.43)/100,(cabPosZ+sign*1002.50)/100);
        renderCabPart(end===0?ebtf_MCb:ebtf_MCb2,connected,brakeAngle,'Y',
            (cabPosX+sign*73.65)/100,(cabPosY+140.89)/100,(cabPosZ+sign*1000.15)/100);
    }
}
function asariPressureValuesForEnd(entity,data,end) {
    var connected=end===0?data.connected0:data.connected1;
    if (data.asariFrozenCabPressure==null) data.asariFrozenCabPressure=[];
    if (entity==null || !connected) {
        data.asariFrozenCabPressure[end]=null;
        return asariGaugeValues(entity,data);
    }
    var fixed=data.asariFrozenCabPressure[end];
    if (fixed==null) {
        fixed=(data.asariGaugePressure==null?ASARI_CAB_REST_PRESSURE:data.asariGaugePressure.values).slice(0);
        data.asariFrozenCabPressure[end]=fixed;
    }
    return fixed;
}
