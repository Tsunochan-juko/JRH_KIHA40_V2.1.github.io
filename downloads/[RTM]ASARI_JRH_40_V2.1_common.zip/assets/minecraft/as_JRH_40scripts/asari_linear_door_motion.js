// Passenger door positions are independent of one-man permission multipliers.
// Full travel is 0.9 m at 0.3 m/s, preserving the previous nominal speed.
function asariDoorMotionTime(entity) { return asariRenderFrameTime(entity); }
function asariDoorStep(state, targets, now, sealed) {
    if (state.linearTime == null) state.linearTime = now;
    // Do not spend time from an off-screen interval on a newly observed command.
    var elapsed = Math.max(0, Math.min(0.1, now - state.linearTime));
    state.linearTime = now;
    var edges = [];
    if (state.audioDirection == null) state.audioDirection = [0, 0, 0, 0];
    if (state.direction == null) state.direction = [0, 0, 0, 0];
    for (var i = 0; i < 4; i++) {
        var difference = targets[i] - state.motion[i];
        var direction = Math.abs(difference) > 0.000001 ? (difference > 0 ? 1 : -1) : 0;
        if (elapsed > 0 && direction !== 0) {
            if (direction !== state.audioDirection[i]) edges.push({side: i % 2, kind: direction > 0 ? 'open' : 'close'});
            state.motion[i] += Math.max(-0.3 * elapsed, Math.min(0.3 * elapsed, difference));
            state.audioDirection[i] = direction;
        } else if (direction === 0) state.audioDirection[i] = 0;
        state.direction[i] = Math.abs(targets[i] - state.motion[i]) > 0.000001 ? direction : 0;
    }
    return edges;
}
function asariPublishDoorEdges(entity, edges) {
    if (entity == null || edges.length === 0) return;
    var map = entity.getResourceState().getDataMap(), history = [];
    var now = new Date().getTime();
    try { history = JSON.parse(String(map.getString('AsariDoorMotionAudioV1'))); } catch (ignored) {}
    if (!Array.isArray(history)) history = [];
    history = history.filter(function(e) { return e && now - e.t >= 0 && now - e.t <= 2000; });
    var emitted = {};
    for (var i = 0; i < edges.length; i++) {
        var e = edges[i], key = e.side + ':' + e.kind;
        if (emitted[key]) continue;
        emitted[key] = true;
        history.push({id: String(now) + ':' + String(Math.random()), t: now, side: e.side, kind: e.kind});
    }
    // Every client derives local motion/audio; no network echo can replay this edge.
    map.setString('AsariDoorMotionAudioV1', JSON.stringify(history.slice(-16)), 0);
}
function asariRenderLinearDoors(entity, pass, data) {
    var moves = [0, 0, 0, 0];
    if (entity != null) {
        var state = data.asariLinearDoorState;
        if (state == null) state = data.asariLinearDoorState = {motion: [0, 0, 0, 0]};
        var targets = [], standard = Number(data.states[4]);
        for (var door = 0; door < 4; door++) {
            var allowed = door < 2 ? data.frontAllowed : data.rearAllowed;
            var bit = door % 2 === 0 ? 2 : 1;
            targets[door] = !data.sealed && allowed && (standard & bit) !== 0 ? 0.9 : 0;
        }
        var edges = asariDoorStep(state, targets, asariDoorMotionTime(entity), data.sealed);
        asariPublishDoorEdges(entity, edges);
        moves = state.motion;
    }
    // Exterior door indicators have their own Light material. Keep them lit
    // while that side is opening/open/closing, even with the cabin lights off.
    if (entity != null && !data.sealed && pass >= 0 && pass <= 4) {
        if (moves[0] > 0 || moves[2] > 0) doorLL.render(renderer);
        if (moves[1] > 0 || moves[3] > 0) doorRL.render(renderer);
    }
    if (entity != null && !(pass === 0 || (data.states[11] >= 1 && pass >= 2 && pass <= 4))) return;
    translatedDoor(door_LF, moves[0]);
    translatedDoor(door_RF, moves[1]);
    translatedDoor(door_LB, -moves[2]);
    translatedDoor(door_RB, -moves[3]);
}
