// DN label geometry is separate from fans and common exterior fittings.
var asariDNParts = null;
var asariJanpaParts = null;
var ASARI_DN_UPPER_OVERRIDES = {as_JRH_40_1762: true};
function asariInitDN(upper) {
    asariDNParts = {upper: renderer.registerParts(new Parts('dn_upper')),
        lower: renderer.registerParts(new Parts('dn_lower')), defaultUpper: upper};
    asariJanpaParts = {
        minusConnectedCable: renderer.registerParts(new Parts('janpa_minus_connected_cable')),
        plusConnectedTip: renderer.registerParts(new Parts('janpa_plus_connected_tip')),
        plusLidOpen: renderer.registerParts(new Parts('janpa_plus_connected_lid_open')),
        plusDisconnected: renderer.registerParts(new Parts('janpa_plus_disconnected'))
    };
}
function asariDNUpper(entity) {
    if (entity != null) {
        try {
            var name = String(entity.getResourceState().getResourceSet().getConfig().trainName);
            if (ASARI_DN_UPPER_OVERRIDES[name] != null) return ASARI_DN_UPPER_OVERRIDES[name];
        } catch (ignored) {}
    }
    return asariDNParts.defaultUpper;
}
function asariRenderDN(entity, pass) {
    if ((pass !== 0 && pass !== 1) || asariDNParts == null) return;
    (asariDNUpper(entity) ? asariDNParts.upper : asariDNParts.lower).render(renderer);
    asariRenderJanpa(entity);
}

// RTM end 0 faces +Z; end 1 faces -Z. Physical coupling stays connected
// when the passage door is sealed. The +Z open-lid and parked variants overlap,
// so they must never be rendered together.
function asariRenderJanpa(entity) {
    if (asariJanpaParts == null) return;
    var plusConnected = entity != null && entity.getConnectedTrain(0) != null;
    var minusConnected = entity != null && entity.getConnectedTrain(1) != null;
    if (plusConnected) {
        asariJanpaParts.plusLidOpen.render(renderer);
        asariJanpaParts.plusConnectedTip.render(renderer);
    } else {
        asariJanpaParts.plusDisconnected.render(renderer);
    }
    if (minusConnected) asariJanpaParts.minusConnectedCable.render(renderer);
}
