var renderClass = "jp.ngt.rtm.render.VehiclePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.jp.ngt.ngtlib.math);
importPackage(Packages.jp.ngt.rtm);
importPackage(Packages.jp.ngt.rtm.entity.train.util);
importPackage(Packages.jp.ngt.ngtlib.util);
importPackage(Packages.org.lwjgl.input);
importPackage(Packages.org.lwjgl.util.vector);

function trainConfig(par1)
{var doorLenght,cabPosX,cabPosY,cabPosZ,r,doorType,doorZ1,doorZ2;
//############################################
//############################################
//�ݒ荀�ځ�
  doorLenght = 0.88;	//�h�A�̈ړ�����(m�P��)	��0�ɂ���Ɖ��̍��W�ϊ����g����
  cabPosX = 0.0;		//�^�]����W��X(cm�P��)
  cabPosY = 0.0;		//�^�]����W��Y(cm�P��)
  cabPosZ = 0.0;		//�^�]����W��Z(cm�P��)
  doorType = "slow";//�h�A�̉��^�C�v default/linear/slow ��3���
 

 //�����W�ϊ��@�h�A�̈ړ��������킩��Ȃ��l����
  doorZ1 = 0.0; //�ǂ��ł������̂Ńh�A�𐳖ʂ��猩�č�����Z���W�����(cm�P��)
  doorZ2 = 0.0; //�h�A�𐳖ʂ��猩�ĉE����Z���W�����(cm�P��)
//############################################
//############################################
  doorZ1 = (Math.abs(doorZ1 - doorZ2))/100;
  if(doorZ1>0&&doorLenght==0){
    doorLenght = doorZ1;
  }
  switch(par1){
     case "doorLenght":r=doorLenght;break;
     case "cabPosX":r=cabPosX;break;
     case "cabPosY":r=cabPosY;break;
     case "cabPosZ":r=cabPosZ;break;
     case "doorType":r=doorType;break;
  }
  return(r);
}

function init(par1, par2)
{
  main = renderer.registerParts(new Parts("door1","door2","door3","door4","outsideBody","frame","face","hole",
"meiban3","meiban5","meiban7",
"sabouke1",


"700_fan",
"taifon",
"skirt_1","skirt_2",
"DMF13HZB",
"engine",
"stuff"));//�Е��̓~���[�����O�p
  main2 = renderer.registerParts(new Parts("700_fan","insideBody","insideBody2","toilet","seat2+2"   ,"seiriken3","untinhyoujiki2"));
  main3 = renderer.registerParts(new Parts("insideFace","doorStaff","ebtf_body"));
  main4 = renderer.registerParts(new Parts("always_light"));
//�h�A�O
  doorLF = renderer.registerParts(new Parts('doa1'));
  doorLB = renderer.registerParts(new Parts('doa3'));
  doorRF = renderer.registerParts(new Parts('doa2'));
  doorRB = renderer.registerParts(new Parts('doa4'));
//�h�A����
  doorLFL = renderer.registerParts(new Parts('doa1L'));
  doorLBL = renderer.registerParts(new Parts('doa3L'));
  doorRFL = renderer.registerParts(new Parts('doa2L'));
  doorRBL = renderer.registerParts(new Parts('doa4L'));
//�T�{
  sabo1 = renderer.registerParts(new Parts('sabo1'));
  sabo2 = renderer.registerParts(new Parts('sabo2'));
//�T�{side
  oneman1 = renderer.registerParts(new Parts('oneman1'));
  oneman2 = renderer.registerParts(new Parts('oneman2'));

  untinbako2_1  = renderer.registerParts(new Parts('untinbako2_1'));
  untinbako2_1l = renderer.registerParts(new Parts('untinbako2_1l'));
  untinbako2_2  = renderer.registerParts(new Parts('untinbako2_2'));


  s1_1 = renderer.registerParts(new Parts('1_1'));
  s2_1 = renderer.registerParts(new Parts('2_1'));
  s3_1 = renderer.registerParts(new Parts('3_1'));
  s4_1 = renderer.registerParts(new Parts('4_1'));
  s5_1 = renderer.registerParts(new Parts('5_1'));


  ebtf_MCb = renderer.registerParts(new Parts('ebtf_MCb'));
  ebtf_MCa = renderer.registerParts(new Parts('ebtf_MCa'));
  ebtf_Ms = renderer.registerParts(new Parts('ebtf_Ms'));
  ebtf_Mbc = renderer.registerParts(new Parts('ebtf_Mbc'));
  ebtf_Mmr = renderer.registerParts(new Parts('ebtf_Mmr'));

  ebtf_MCb2 = renderer.registerParts(new Parts('ebtf_MCb2'));
  ebtf_MCa2 = renderer.registerParts(new Parts('ebtf_MCa2'));
  ebtf_Ms2 = renderer.registerParts(new Parts('ebtf_Ms2'));
  ebtf_Mbc2 = renderer.registerParts(new Parts('ebtf_Mbc2'));
  ebtf_Mmr2 = renderer.registerParts(new Parts('ebtf_Mmr2'));

  ebtf_Lb1 = renderer.registerParts(new Parts('ebtf_Lb1'));
  ebtf_Lb2 = renderer.registerParts(new Parts('ebtf_Lb2'));
  ebtf_Lb3 = renderer.registerParts(new Parts('ebtf_Lb3'));
  ebtf_Lb4 = renderer.registerParts(new Parts('ebtf_Lb4'));
  ebtf_Lb5 = renderer.registerParts(new Parts('ebtf_Lb5'));
  ebtf_Lb6 = renderer.registerParts(new Parts('ebtf_Lb6'));
  ebtf_Lb7 = renderer.registerParts(new Parts('ebtf_Lb7'));
  ebtf_Lb8 = renderer.registerParts(new Parts('ebtf_Lb8'));
  doorLL = renderer.registerParts(new Parts("13"));
  doorRL = renderer.registerParts(new Parts("24"));
  doorLL_off = renderer.registerParts(new Parts("13_off"));
  doorRL_off = renderer.registerParts(new Parts("24_off"));
  door_light = renderer.registerParts(new Parts("door_light"));
  _choku = renderer.registerParts(new Parts("choku"));
  _chu = renderer.registerParts(new Parts("chu"));
  _hen = renderer.registerParts(new Parts("hen"));
  _nochoku = renderer.registerParts(new Parts("nochoku"));
  _nochu = renderer.registerParts(new Parts("nochu"));
  _nohen = renderer.registerParts(new Parts("nohen"));
  mae = renderer.registerParts(new Parts("0"));
  usiro = renderer.registerParts(new Parts("2"));
  nomae = renderer.registerParts(new Parts("no0"));
  nonaka = renderer.registerParts(new Parts("no1"));
  nousiro = renderer.registerParts(new Parts("no2"));
//���C�g
  L_main_1 = renderer.registerParts(new Parts("L_main_1"));
  L_tail_1 = renderer.registerParts(new Parts("L_tail_1"));
  L_main_2 = renderer.registerParts(new Parts("L_main_2"));
  L_tail_2 = renderer.registerParts(new Parts("L_tail_2"));

  L_main_1sub = renderer.registerParts(new Parts("L_main_1sub"));
  L_tail_1sub = renderer.registerParts(new Parts("L_tail_1sub"));
  L_main_2sub = renderer.registerParts(new Parts("L_main_2sub"));
  L_tail_2sub = renderer.registerParts(new Parts("L_tail_2sub"));
}


function hi03DoorMove(entity,LR)
{
  var doorML,doorMR,move;
  try{
    doorML = entity.doorMoveL;
    doorMR = entity.doorMoveR;
  }catch(e){}
  if(trainConfig("doorType") == "default"){
    if(LR=="L"){
      move = renderer.sigmoid(doorML/60);
    }
    if(LR=="R"){
      move = renderer.sigmoid(doorMR/60);
    }
  }
  if(trainConfig("doorType") == "linear"){
    if(LR=="L"){
      move = hi03Linear(doorML/60);
    }
    if(LR=="R"){
      move = hi03Linear(doorMR/60);
    }
  }
  if(trainConfig("doorType") == "slow"){
    if(LR=="L"){
      move = doorML/60;
    }
    if(LR=="R"){
      move = doorMR/60;
    }
  }
  return(move);
}

function render(entity, pass, par3)
{
  if(!entity||pass==0||pass==1||pass==2||pass==3||pass==4){main4.render(renderer);}
  if((!entity||entity.getTrainStateData(11) == 0)&& pass==0||pass == 1){main2.render(renderer);}
  if((!entity||entity.getTrainStateData(11) >= 1)&&(pass == 0||pass == 1||pass == 2||pass == 3||pass == 4)){main2.render(renderer);}
  if((!entity||entity.getResourceState().getDataMap().getInt("Button2")==0)&& pass==0||pass == 1){main3.render(renderer);}
  if((!entity||entity.getResourceState().getDataMap().getInt("Button2")==1)&&(pass == 0||pass == 1||pass == 2||pass == 3||pass == 4)){main3.render(renderer);}
  if(pass==0){main.render(renderer);}
  if(pass==1){main.render(renderer);}
  if(pass==2){main.render(renderer);}
  if(pass==3){main.render(renderer);}
  if(pass==4){main.render(renderer);}



  var doorLMove = hi03DoorMove(entity,"L") * trainConfig("doorLenght");
  var doorRMove = hi03DoorMove(entity,"R") * trainConfig("doorLenght");
  if(!entity||pass==0){
    GL11.glPushMatrix();
     GL11.glTranslatef(0.0, 0.0, doorLMove);
     doorLF.render(renderer);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
     GL11.glTranslatef(0.0, 0.0, -doorLMove);
     doorLB.render(renderer);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
     GL11.glTranslatef(0.0, 0.0, doorRMove);
     doorRF.render(renderer);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
     GL11.glTranslatef(0.0, 0.0, -doorRMove);
     doorRB.render(renderer);
    GL11.glPopMatrix();
  }



//
if(!entity||doorLMove !== 0){doorLL.render(renderer);}
if(!entity||doorRMove !== 0){doorRL.render(renderer);}
if(!entity||doorLMove == 0){doorLL_off.render(renderer);}
if(!entity||doorRMove == 0){doorRL_off.render(renderer);}
//
//
if((!entity||doorLMove == 0 && doorRMove == 0)){door_light.render(renderer);}
//

//��

 
  if(!entity||(entity.getResourceState().getDataMap().getInt("Button4")==1)&& pass==0){s1_1.render(renderer);}
  if(!entity||(entity.getResourceState().getDataMap().getInt("Button4")==2)&& pass==0){s2_1.render(renderer);}
  if(!entity||(entity.getResourceState().getDataMap().getInt("Button4")==3)&& pass==0){s3_1.render(renderer);}
  if(!entity||(entity.getResourceState().getDataMap().getInt("Button4")==4)&& pass==0){s4_1.render(renderer);}
  if(!entity||(entity.getResourceState().getDataMap().getInt("Button4")==5)&& pass==0){s5_1.render(renderer);}




//�^����
if(!entity||((pass == 0||pass == 1||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button5")==0)&&(entity.getResourceState().getDataMap().getInt("Button2")==1))){oneman2.render(renderer);}
if(!entity||((pass == 0||pass == 1||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button5")==1)&&(entity.getResourceState().getDataMap().getInt("Button2")==1))){oneman1.render(renderer);}
if(!entity||((pass == 0                                            )&&(entity.getResourceState().getDataMap().getInt("Button5")==0)&&(entity.getResourceState().getDataMap().getInt("Button2")==0))){oneman2.render(renderer);}
if(!entity||((pass == 0                                            )&&(entity.getResourceState().getDataMap().getInt("Button5")==1)&&(entity.getResourceState().getDataMap().getInt("Button2")==0))){oneman1.render(renderer);}

if(!entity||((pass == 0                                            )&&(entity.getResourceState().getDataMap().getInt("Button5")==1)&&entity.getTrainStateData(11) == 0)){untinbako2_1.render(renderer);}
if(!entity||((pass == 0                                            )&&(entity.getResourceState().getDataMap().getInt("Button5")==1)&&entity.getResourceState().getDataMap().getInt("Button2")==0)){untinbako2_1l.render(renderer);}
if(!entity||((pass == 0||pass == 1||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button5")==1)&&entity.getTrainStateData(11) >  0)){untinbako2_1.render(renderer);}
if(!entity||((pass == 0                                            )&&(entity.getResourceState().getDataMap().getInt("Button5")==0)&&entity.getResourceState().getDataMap().getInt("Button2")==0)){untinbako2_2.render(renderer);}
if(!entity||((pass == 0||pass == 1||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button5")==0)&&entity.getResourceState().getDataMap().getInt("Button2")==1)){untinbako2_2.render(renderer);}
if(!entity||((pass == 0||pass == 1||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button5")==1)&&entity.getResourceState().getDataMap().getInt("Button2")==1)){untinbako2_1l.render(renderer);}






//////////////
  var speed,BC,MR,notch,cabPosX,cabPosY,cabPosZ,move1,move2;
  try{
    speed = entity.getSpeed()*72.0;
    BC = entity.brakeCount*3;
    MR = ((entity.brakeAirCount+216)*(100/432))+700;
    notch = entity.getNotch();
  }catch(e){
  }
  cabPosX = trainConfig("cabPosX");
  cabPosY = trainConfig("cabPosY");
  cabPosZ = trainConfig("cabPosZ");
  switch (notch){
    case -8:move2=(9/8)*+90;break;
    case -7:move2=(7/8)*+90;break;
    case -6:move2=(6/8)*+90;break;
    case -5:move2=(5/8)*+90;break;
    case -4:move2=(4/8)*+90;break;
    case -3:move2=(3/8)*+90;break;
    case -2:move2=(2/8)*+90;break;
    case -1:move2=(1/8)*+90;break;
    case 1:move1=(1/5)*-120;break;
    case 2:move1=(2/5)*-120;break;
    case 3:move1=(3/5)*-120;break;
    case 4:move1=(4/5)*-120;break;
    case 5:move1=(5/5)*-120;break;
  }
  if(notch<=0){move1 = 0;}
  if(notch>=0){move2 = 0;}
//

  if((pass==0||pass==1||pass==2||pass==3||pass==4)&&notch >  0 && speed >= 60&&entity.getResourceState().getDataMap().getInt("Button2")==1){_choku.render(renderer);}
  if((pass==0||pass==1||pass==2||pass==3||pass==4)&&notch <= 0               &&entity.getResourceState().getDataMap().getInt("Button2")==1){_chu.render(renderer);}
  if((pass==0||pass==1||pass==2||pass==3||pass==4)&&notch >  0 && speed <  60&&entity.getResourceState().getDataMap().getInt("Button2")==1){_hen.render(renderer);}
  if((pass==0                                    )&&notch >  0 && speed >= 60&&entity.getResourceState().getDataMap().getInt("Button2")==0){_nochoku.render(renderer);}
  if((pass==0                                    )&&notch <= 0               &&entity.getResourceState().getDataMap().getInt("Button2")==0){_nochu.render(renderer);}
  if((pass==0                                    )&&notch >  0 && speed <  60&&entity.getResourceState().getDataMap().getInt("Button2")==0){_nohen.render(renderer);}

  if((pass==0                                    )&&notch >  0 && speed >= 60){_nochoku.render(renderer);}
  if((pass==0                                    )&&notch <= 0){_nochu.render(renderer);}
  if((pass==0                                    )&&notch >  0 && speed <  60){_nohen.render(renderer);}

  if(!entity||(pass==0||pass==1||pass==2||pass==3||pass==4)&& entity.getTrainStateData(10) == 0){mae.render(renderer);}
  if(!entity||(pass==0||pass==1||pass==2||pass==3||pass==4)&& entity.getTrainStateData(10) == 2){usiro.render(renderer);}

  if(!entity||(pass==0||pass==1||pass==2||pass==3||pass==4)&& entity.getTrainStateData(10) == 0&&entity.getResourceState().getDataMap().getInt("Button2")==1){nomae.render(renderer);}
  if(!entity||(pass==0||pass==1||pass==2||pass==3||pass==4)&& entity.getTrainStateData(10) == 1&&entity.getResourceState().getDataMap().getInt("Button2")==1){nonaka.render(renderer);}
  if(!entity||(pass==0||pass==1||pass==2||pass==3||pass==4)&& entity.getTrainStateData(10) == 2&&entity.getResourceState().getDataMap().getInt("Button2")==1){nousiro.render(renderer);}

  if(!entity||(pass==0                                    )&& entity.getTrainStateData(10) == 0&&entity.getResourceState().getDataMap().getInt("Button2")==0){nomae.render(renderer);}
  if(!entity||(pass==0                                    )&& entity.getTrainStateData(10) == 1&&entity.getResourceState().getDataMap().getInt("Button2")==0){nonaka.render(renderer);}
  if(!entity||(pass==0                                    )&& entity.getTrainStateData(10) == 2&&entity.getResourceState().getDataMap().getInt("Button2")==0){nousiro.render(renderer);}

//�T�{ entity �� preview


  if((!entity||entity.getResourceState().getDataMap().getInt("Button0")==1)&& pass==0){sabo1.render(renderer);}
  if((!entity||entity.getResourceState().getDataMap().getInt("Button0")==2)&& pass==0){sabo2.render(renderer);}






//�h�A�X�C�b�`




//���x




//

if(!entity ||(entity.getTrainStateData(0) == 0)&& entity.getResourceState().getDataMap().getInt("Button1")==0){
L_main_1sub.render(renderer);
L_main_2sub.render(renderer);
L_tail_1sub.render(renderer);
L_tail_2.render(renderer);
}
if(!entity ||(entity.getTrainStateData(0) == 0)&& entity.getResourceState().getDataMap().getInt("Button1")==1){
L_main_1.render(renderer);
L_main_2sub.render(renderer);
L_tail_1sub.render(renderer);
L_tail_2.render(renderer);
}
if(!entity ||(entity.getTrainStateData(0) == 1)&& entity.getResourceState().getDataMap().getInt("Button1")==0){
L_main_1sub.render(renderer);
L_main_2sub.render(renderer);
L_tail_1.render(renderer);
L_tail_2sub.render(renderer);
}
if(!entity ||(entity.getTrainStateData(0) == 1)&& entity.getResourceState().getDataMap().getInt("Button1")==1){
L_main_1sub.render(renderer);
L_main_2.render(renderer);
L_tail_1.render(renderer);
L_tail_2sub.render(renderer);
}



if(!entity ||entity.getResourceState().getDataMap().getInt("Button3")==1){
L_tail_1.render(renderer);
L_tail_2.render(renderer);
}

//(!entity || entity.getTrainStateData(10) == 0)

//######################
//

  if(!entity||(pass == 0||pass == 1||pass == 2||pass == 3||pass == 4)&&entity.getTrainStateData(0) == 0){
    GL11.glPushMatrix();
     var angle1 = (speed / 95) * 178;
     renderer.rotate(angle1, 'Z', (cabPosX+118.66)/100, (cabPosY+138.86)/100, (cabPosZ+1012.76)/100);
     ebtf_Ms.render(renderer);
    GL11.glPopMatrix();
  }


//######################
//
  if(!entity||(pass == 0||pass == 1||pass == 2||pass == 3||pass == 4)&&entity.getTrainStateData(0) == 1){
    GL11.glPushMatrix();
     var angle1 = (speed / 95) * -178;
     renderer.rotate(angle1, 'Z', (cabPosX-118.66)/100, (cabPosY+138.86)/100, (cabPosZ-1012.76)/100);
     ebtf_Ms2.render(renderer);
    GL11.glPopMatrix();
  }
//###########################
  
  if(!entity||(pass == 0)&&(entity.getResourceState().getDataMap().getInt("Button2")==0)){
    if(notch>-8){
      switch (notch){
        case -7:ebtf_Lb7.render(renderer);
        case -6:ebtf_Lb6.render(renderer);
        case -5:ebtf_Lb5.render(renderer);
        case -4:ebtf_Lb4.render(renderer);
        case -3:ebtf_Lb3.render(renderer);
        case -2:ebtf_Lb2.render(renderer);
        case -1:ebtf_Lb1.render(renderer);break;
      }
    }else if(!entity||(pass == 0||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button2")==1)&&notch==-8){
      ebtf_Lb8.render(renderer);
    } 
  if(!entity||(pass == 0)&&(entity.getResourceState().getDataMap().getInt("Button2")==0)&&entity.getTrainStateData(0) == 0){
    GL11.glPushMatrix();
     renderer.rotate(move1, 'Y', (cabPosX+121.20)/100, (cabPosY+129.43)/100, (cabPosZ+1002.50)/100);
     ebtf_MCa.render(renderer);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
     renderer.rotate(move2, 'Y', (cabPosX+73.65)/100, (cabPosY+140.89)/100, (cabPosZ+1000.15)/100);
     ebtf_MCb.render(renderer);
    GL11.glPopMatrix();
    }
  if(!entity||(pass == 0)&&(entity.getResourceState().getDataMap().getInt("Button2")==0)&&entity.getTrainStateData(0) == 1){
    GL11.glPushMatrix();
     renderer.rotate(move1, 'Y', (cabPosX-121.20)/100, (cabPosY+129.43)/100, (cabPosZ-1002.50)/100);
     ebtf_MCa2.render(renderer);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
     renderer.rotate(move2, 'Y', (cabPosX-73.65)/100, (cabPosY+140.89)/100, (cabPosZ-1000.15)/100);
     ebtf_MCb2.render(renderer);
    GL11.glPopMatrix();
    }
  }



  if(!entity||(pass == 0||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button2")==1)){
    if(notch>-8){
      switch (notch){
        case -7:ebtf_Lb7.render(renderer);
        case -6:ebtf_Lb6.render(renderer);
        case -5:ebtf_Lb5.render(renderer);
        case -4:ebtf_Lb4.render(renderer);
        case -3:ebtf_Lb3.render(renderer);
        case -2:ebtf_Lb2.render(renderer);
        case -1:ebtf_Lb1.render(renderer);break;
      }
    }else if(!entity||(pass == 0||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button2")==1)&&notch==-8){
      ebtf_Lb8.render(renderer);
    }
  if(!entity||(pass == 0||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button2")==1)&&entity.getTrainStateData(0) == 0){
    GL11.glPushMatrix();
     renderer.rotate(move1, 'Y', (cabPosX+121.20)/100, (cabPosY+129.43)/100, (cabPosZ+1002.50)/100);
     ebtf_MCa.render(renderer);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
     renderer.rotate(move2, 'Y', (cabPosX+73.65)/100, (cabPosY+140.89)/100, (cabPosZ+1000.15)/100);
     ebtf_MCb.render(renderer);
    GL11.glPopMatrix();
    }

  if(!entity||(pass == 0||pass == 2||pass == 3||pass == 4)&&(entity.getResourceState().getDataMap().getInt("Button2")==1)&&entity.getTrainStateData(0) == 1){
    GL11.glPushMatrix();
     renderer.rotate(move1, 'Y', (cabPosX-121.20)/100, (cabPosY+129.43)/100, (cabPosZ-1002.50)/100);
     ebtf_MCa2.render(renderer);
    GL11.glPopMatrix();
    GL11.glPushMatrix();
     renderer.rotate(move2, 'Y', (cabPosX-73.65)/100, (cabPosY+140.89)/100, (cabPosZ-1000.15)/100);
     ebtf_MCb2.render(renderer);
    GL11.glPopMatrix();
    }




 
  }
}