var renderClass = "jp.ngt.rtm.render.VehiclePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.jp.ngt.ngtlib.math);
importPackage(Packages.jp.ngt.rtm);
importPackage(Packages.jp.ngt.rtm.entity.train.util);
importPackage(Packages.jp.ngt.ngtlib.util);
importPackage(Packages.org.lwjgl.input);
importPackage(Packages.org.lwjgl.util.vector);

function trainConfig(par1)
{var doorLenght,cabPosX,cabPosY,cabPosZ,r,doorType,doorZ1,doorZ2;
//############################################
//############################################
//�ݒ荀�ځ�
  doorLenght = 0.88;	//�h�A�̈ړ�����(m�P��)	��0�ɂ���Ɖ��̍��W�ϊ����g����
  cabPosX = 0.0;		//�^�]����W��X(cm�P��)
  cabPosY = 0.0;		//�^�]����W��Y(cm�P��)
  cabPosZ = 0.0;		//�^�]����W��Z(cm�P��)
  doorType = "slow";//�h�A�̉��^�C�v default/linear/slow ��3���
 

 //�����W�ϊ��@�h�A�̈ړ��������킩��Ȃ��l����
  doorZ1 = 0.0; //�ǂ��ł������̂Ńh�A�𐳖ʂ��猩�č�����Z���W�����(cm�P��)
  doorZ2 = 0.0; //�h�A�𐳖ʂ��猩�ĉE����Z���W�����(cm�P��)
//############################################
//############################################
  doorZ1 = (Math.abs(doorZ1 - doorZ2))/100;
  if(doorZ1>0&&doorLenght==0){
    doorLenght = doorZ1;
  }
  switch(par1){
     case "doorLenght":r=doorLenght;break;
     case "cabPosX":r=cabPosX;break;
     case "cabPosY":r=cabPosY;break;
     case "cabPosZ":r=cabPosZ;break;
     case "doorType":r=doorType;break;
  }
  return(r);
}

function init(par1, par2)
{
  body = renderer.registerParts(new Parts("door1","door2","door3","door4","outsideBody","frame","face","hole",
"meiban6","meiban5","meiban7",
"sabouke1",



"taifon",
"skirt_1","skirt_2",
"DMF13HZI",
"engine",
"stuff", "doorLL_off", "doorRL_off")); //���ɓ������Ȃ����i���Ԃ�����
	main2 = renderer.registerParts(new Parts("700_fan", "insideBody",
		"insideBody2", "toilet", "seat2+2", "seiriken3", "untinhyoujiki2"));
	main3 = renderer.registerParts(new Parts("insideFace", "doorStaff",
		"ebtf_body"));
	main4 = renderer.registerParts(new Parts("always_light"));

	door_LF = renderer.registerParts(new Parts("doa1")); //�������牺�l�̓h�A���i
	door_RF = renderer.registerParts(new Parts("doa2"));
	door_LB = renderer.registerParts(new Parts("doa3"));
	door_RB = renderer.registerParts(new Parts("doa4"));

	door_LFL = renderer.registerParts(new Parts("doa1L")); //�������牺�l�̓h�A���i
	door_RFL = renderer.registerParts(new Parts("doa2L"));
	door_LBL = renderer.registerParts(new Parts("doa3L"));
	door_RBL = renderer.registerParts(new Parts("doa4L"));

	sabo1 = renderer.registerParts(new Parts('sabo1'));
	sabo2 = renderer.registerParts(new Parts('sabo2'));

	oneman1 = renderer.registerParts(new Parts('oneman1'));
	oneman2 = renderer.registerParts(new Parts('oneman2'));

	s1_1 = renderer.registerParts(new Parts('1_1'));
	s2_1 = renderer.registerParts(new Parts('2_1'));
	s3_1 = renderer.registerParts(new Parts('3_1'));
	s4_1 = renderer.registerParts(new Parts('4_1'));
	s5_1 = renderer.registerParts(new Parts('5_1'));
	s6_1 = renderer.registerParts(new Parts('6_1'));
	s7_1 = renderer.registerParts(new Parts('7_1'));
	s8_1 = renderer.registerParts(new Parts('8_1'));
	s9_1 = renderer.registerParts(new Parts('9_1'));
	s10_1 = renderer.registerParts(new Parts('10_1'));
	s11_1 = renderer.registerParts(new Parts('11_1'));
	s12_1 = renderer.registerParts(new Parts('12_1'));
	s13_1 = renderer.registerParts(new Parts('13_1'));
	s14_1 = renderer.registerParts(new Parts('14_1'));
	s15_1 = renderer.registerParts(new Parts('15_1'));
	s16_1 = renderer.registerParts(new Parts('16_1'));
	s17_1 = renderer.registerParts(new Parts('17_1'));
	s18_1 = renderer.registerParts(new Parts('18_1'));
	s19_1 = renderer.registerParts(new Parts('19_1'));
	s20_1 = renderer.registerParts(new Parts('20_1'));
	s21_1 = renderer.registerParts(new Parts('21_1'));
	s22_1 = renderer.registerParts(new Parts('22_1'));
	s23_1 = renderer.registerParts(new Parts('23_1'));
	s24_1 = renderer.registerParts(new Parts('24_1'));
	s25_1 = renderer.registerParts(new Parts('25_1'));
	s26_1 = renderer.registerParts(new Parts('26_1'));
	s27_1 = renderer.registerParts(new Parts('27_1'));
	s28_1 = renderer.registerParts(new Parts('28_1'));
	s29_1 = renderer.registerParts(new Parts('29_1'));
	s30_1 = renderer.registerParts(new Parts('30_1'));

	untinbako1 = renderer.registerParts(new Parts('untinbako2_1'));
	untinbako1l = renderer.registerParts(new Parts('untinbako2_1l'));
	untinbako2 = renderer.registerParts(new Parts('untinbako2_2'));

	ebtf_MCb = renderer.registerParts(new Parts('ebtf_MCb'));
	ebtf_MCa = renderer.registerParts(new Parts('ebtf_MCa'));
	ebtf_Ms = renderer.registerParts(new Parts('ebtf_Ms'));
	ebtf_Mbc = renderer.registerParts(new Parts('ebtf_Mbc'));
	ebtf_Mmr = renderer.registerParts(new Parts('ebtf_Mmr'));

	ebtf_MCb2 = renderer.registerParts(new Parts('ebtf_MCb2'));
	ebtf_MCa2 = renderer.registerParts(new Parts('ebtf_MCa2'));
	ebtf_Ms2 = renderer.registerParts(new Parts('ebtf_Ms2'));
	ebtf_Mbc2 = renderer.registerParts(new Parts('ebtf_Mbc2'));
	ebtf_Mmr2 = renderer.registerParts(new Parts('ebtf_Mmr2'));

	doorLL = renderer.registerParts(new Parts("13"));
	doorRL = renderer.registerParts(new Parts("24"));
	doorLL_lamp = renderer.registerParts(new Parts("13_lamp"));
	doorRL_lamp = renderer.registerParts(new Parts("24_lamp"));
	doorLL_off_lamp = renderer.registerParts(new Parts("13_off_lamp"));
	doorRL_off_lamp = renderer.registerParts(new Parts("24_off_lamp"));
	door_light = renderer.registerParts(new Parts("door_light"));

	under3km = renderer.registerParts(new Parts("under3km"));
	over4km = renderer.registerParts(new Parts("over4km"));

	ebtf_Lb8 = renderer.registerParts(new Parts('ebtf_Lb8'));

	_choku = renderer.registerParts(new Parts("choku"));
	_chu = renderer.registerParts(new Parts("chu"));
	_hen = renderer.registerParts(new Parts("hen"));
	_nochoku = renderer.registerParts(new Parts("nochoku"));
	_nochu = renderer.registerParts(new Parts("nochu"));
	_nohen = renderer.registerParts(new Parts("nohen"));
	mae = renderer.registerParts(new Parts("0"));
	usiro = renderer.registerParts(new Parts("2"));
	nomae = renderer.registerParts(new Parts("no0"));
	nonaka = renderer.registerParts(new Parts("no1"));
	nousiro = renderer.registerParts(new Parts("no2"));


	//���C�g
	L_main_1 = renderer.registerParts(new Parts("L_main_1"));
	L_tail_1 = renderer.registerParts(new Parts("L_tail_1"));
	L_main_2 = renderer.registerParts(new Parts("L_main_2"));
	L_tail_2 = renderer.registerParts(new Parts("L_tail_2"));

	L_main_1sub = renderer.registerParts(new Parts("L_main_1sub"));
	L_tail_1sub = renderer.registerParts(new Parts("L_tail_1sub"));
	L_main_2sub = renderer.registerParts(new Parts("L_main_2sub"));
	L_tail_2sub = renderer.registerParts(new Parts("L_tail_2sub"));


	door_LFa = renderer.registerParts(new Parts("doorFL1"));
	door_RFa = renderer.registerParts(new Parts("doorFR1"));
	door_LBa = renderer.registerParts(new Parts("doorBL1"));
	door_RBa = renderer.registerParts(new Parts("doorBR1"));


}


//##### �o�[�W�����擾 ####################
function MCVersionChecker() {
	var varsion = RTMCore.VERSION;
	if (varsion.indexOf("1.7.10") >= 0) return "1.7.10";
	else if (varsion.indexOf("2.0") >= 0) return "1.8.9";
	else if (varsion.indexOf("2.1") >= 0) return "1.9.4";
	else if (varsion.indexOf("2.2") >= 0) return "1.10.2";
	else if (varsion.indexOf("2.4") >= 0) return "1.12.2";
	else return "unknown";
}

//##### ���Ԏ擾 ####################
function isMiddleCar(entity) { //true�Ȃ璆�ԎԁAfalse�Ȃ�擪��/�����
	var formation = entity.getFormation(); //formation�^
	if (formation == null) { //formation���擾�ł��Ȃ��Ƃ��̏���
		return false;
	}
	var current = formation.getEntry(entity).entryId + 1; //���̎ԗ��̍��Ԃ��擾�B0���琔���邽��+1����
	var max = formation.size(); //�A�����Ă闼����Ԃ�
	if (current == 1 || current == max) { //���̎ԗ����擪or�Ō���Ȃ�
		return false;
	} else { //�����łȂ�(�܂蒆��)�Ȃ�
		return true;
	}
}

//##### �����擾 ####################
function isCarSize(entity) {
	var formation = entity.getFormation(); //formation�^
	if (formation == null) { //formation���擾�ł��Ȃ��Ƃ��̏���
		return 1;
	}
	var max = formation.size(); //�A�����Ă闼����Ԃ�
	return max;
}

//##### �אڎԗ��擾 ####################
function isFrontNextCar(entity) { //true�Ȃ�ԗ��O���ɁAfalse�Ȃ�ԗ�����Ɏԗ����聦�擪�Ԃł̂ݎ��s
	var frontNext = entity.getConnectedTrain(0);
	if (frontNext == null) { //�O���ɗאڎԂ̏�񂪎擾�ł��Ȃ����O���ɗאڎԂȂ�������ɗאڎԂ���
		return false;
	} else {
		return true;
	}
}


//##### render ####################
function render(entity, pass, par3) {
	//���l�ݒ�
	var doorMove = 0.9,
		pantaDistance = 7.0,
		pantaType = "Compatible";
	var onUpdateTick = false;



	//�ʏ�`��
	if (pass == 0) {
		body.render(renderer);
		onUpdateTick = detectTick(entity);
		render_body(entity, pass);
		render_door(entity, doorMove, pass, onUpdateTick);
		main4.render(renderer);
	}

	//�������`��
	if (pass == 1) {
		main4.render(renderer);
	}

	//�������`��
	if (pass >= 1) {
		body.render(renderer);
		main4.render(renderer);
		onUpdateTick = detectTick(entity);
		render_body(entity, pass);
		render_door(entity, doorMove, pass, onUpdateTick);
	}

	if (!entity ||(entity.getTrainStateData(11) == 0 && (pass == 0))) {
		main2.render(renderer);
	}
	if (!entity ||(entity.getTrainStateData(11) >= 1 &&(pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4))) {
		main2.render(renderer);
	}
	if (!entity ||(entity.getResourceState().getDataMap().getInt("Button2") == 0 &&
		pass == 0 || pass == 1)) {
		main3.render(renderer);
	}
	if (!entity ||(entity.getResourceState().getDataMap().getInt("Button2") == 1 &&
		(pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4))) {
		main3.render(renderer);
	}


	if (!entity || (entity.getTrainStateData(0) == 0 && entity.getResourceState()
		.getDataMap().getInt("Button1") == 0)) {

		L_main_1sub.render(renderer);
		L_main_2sub.render(renderer);
		L_tail_1sub.render(renderer);
		L_tail_2.render(renderer);

	}
	if (!entity || (entity.getTrainStateData(0) == 0 && entity.getResourceState()
		.getDataMap().getInt("Button1") == 1)) {

		L_main_1.render(renderer);
		L_main_2sub.render(renderer);
		L_tail_1sub.render(renderer);
		L_tail_2.render(renderer);

	}
	if (!entity || (entity.getTrainStateData(0) == 1 && entity.getResourceState()
		.getDataMap().getInt("Button1") == 0)) {

		L_main_1sub.render(renderer);
		L_main_2sub.render(renderer);
		L_tail_1.render(renderer);
		L_tail_2sub.render(renderer);

	}
	if (!entity || (entity.getTrainStateData(0) == 1) && entity.getResourceState()
		.getDataMap().getInt("Button1") == 1) {

		L_main_1sub.render(renderer);
		L_main_2.render(renderer);
		L_tail_1.render(renderer);
		L_tail_2sub.render(renderer);

	}


	//

	if (!entity || (pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4)) {
		if (!entity ||(entity.getTrainStateData(1) > 0 && entity.getSpeed() >= 60)) {
			_choku.render(renderer);
		}
		else if (!entity ||(entity.getTrainStateData(1) <= 0)) {
			_chu.render(renderer);
		}
		else if (!entity ||(entity.getTrainStateData(1) > 0 && entity.getSpeed() < 60)) {
			_hen.render(renderer);
		}
	}


	if (!entity || (pass == 0 && entity.getResourceState().getDataMap().getInt("Button2") == 0)) {
		if (!entity ||(entity.getTrainStateData(1) > 0 && entity.getSpeed() >= 60)) {
			_nochoku.render(renderer);
		}
		else if (!entity ||(entity.getTrainStateData(1) <= 0)) {
			_nochu.render(renderer);
		}
		else if (!entity ||(entity.getTrainStateData(1) > 0 && entity.getSpeed() < 60)) {
			_nohen.render(renderer);
		}
	}




	else if (!entity || ((pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) && entity.getResourceState().getDataMap().getInt("Button2") == 1)) {
		if (entity.getTrainStateData(1) > 0 && entity.getSpeed() >= 60) {
			_nochoku.render(renderer);
		}
		else if (!entity ||entity.getTrainStateData(1) <= 0) {
			_nochu.render(renderer);
		}
		else if (!entity ||(entity.getTrainStateData(1) > 0 && entity.getSpeed() < 60)) {
			_nohen.render(renderer);
		}
	}







	if (!entity || (pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4)) {
		if (!entity ||entity.getTrainStateData(10) == 0) {
			mae.render(renderer);
		}
		else if (!entity ||entity.getTrainStateData(10) == 2) {
			usiro.render(renderer);
		}
	}

	if (!entity || (pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) &&
		entity.getResourceState().getDataMap().getInt("Button2") == 1) {
		if (!entity ||entity.getTrainStateData(10) == 0) {
			nomae.render(renderer);
		}
		else if (!entity ||entity.getTrainStateData(10) == 1) {
			nonaka.render(renderer);
		}
		else if (!entity ||entity.getTrainStateData(10) == 2) {
			nousiro.render(renderer);
		}
	}

	else if (!entity || pass == 0 && entity.getResourceState().getDataMap().getInt(
			"Button2") == 0) {
		if (!entity ||entity.getTrainStateData(10) == 0) {
			nomae.render(renderer);
		}
		else if (!entity ||entity.getTrainStateData(10) == 1) {
			nonaka.render(renderer);
		}
		else if (!entity ||entity.getTrainStateData(10) == 2) {
			nousiro.render(renderer);
		}
	}

	//�T�{ entity �� preview


	if ((!entity || entity.getResourceState().getDataMap().getInt("Button0") == 1) &&
		pass == 0) {
		sabo1.render(renderer);
	}
	if ((!entity || entity.getResourceState().getDataMap().getInt("Button0") == 2) &&
		pass == 0) {
		sabo2.render(renderer);
	}


	//�^����
	if (!entity || ((pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) &&
			(entity.getResourceState().getDataMap().getInt("Button5") == 0) && (entity.getResourceState()
				.getDataMap().getInt("Button2") == 1))) {
		oneman2.render(renderer);
	}
	if (!entity || ((pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) &&
			(entity.getResourceState().getDataMap().getInt("Button5") == 1) && (entity.getResourceState()
				.getDataMap().getInt("Button2") == 1))) {
		oneman1.render(renderer);
	}
	if (!entity || ((pass == 0) && (entity.getResourceState().getDataMap().getInt(
			"Button5") == 0) && (entity.getResourceState().getDataMap().getInt(
			"Button2") == 0))) {
		oneman2.render(renderer);
	}
	if (!entity || ((pass == 0) && (entity.getResourceState().getDataMap().getInt(
			"Button5") == 1) && (entity.getResourceState().getDataMap().getInt(
			"Button2") == 0))) {
		oneman1.render(renderer);
	}

	if (!entity || ((pass == 0) && (entity.getResourceState().getDataMap().getInt(
			"Button5") == 1) && entity.getTrainStateData(11) == 0)) {
		untinbako1.render(renderer);
	}
	if (!entity || ((pass == 0) && (entity.getResourceState().getDataMap().getInt(
				"Button5") == 1) && entity.getResourceState().getDataMap().getInt("Button2") ==
			0)) {
		untinbako1l.render(renderer);
	}
	if (!entity || ((pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) &&
			(entity.getResourceState().getDataMap().getInt("Button5") == 1) && entity.getTrainStateData(
				11) > 0)) {
		untinbako1.render(renderer);
	}
	if (!entity || ((pass == 0) && (entity.getResourceState().getDataMap().getInt("Button5") == 0) && (entity.getResourceState().getDataMap().getInt("Button2") == 0))) {
		untinbako2.render(renderer);
	}
	if (!entity || ((pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) && (entity.getResourceState().getDataMap().getInt("Button5") == 0) && (entity.getResourceState().getDataMap().getInt("Button2") == 1))) {
		untinbako2.render(renderer);
	}
	if (!entity || ((pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) &&
			(entity.getResourceState().getDataMap().getInt("Button5") == 1) && entity.getResourceState()
			.getDataMap().getInt("Button2") == 1)) {
		untinbako1l.render(renderer);
	}


	//��


	if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 1) &&
		pass == 0) {
		s1_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 2) &&
		pass == 0) {
		s2_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 3) &&
		pass == 0) {
		s3_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 4) &&
		pass == 0) {
		s4_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 5) &&
		pass == 0) {
		s5_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 6) &&
		pass == 0) {
		s6_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 7) &&
		pass == 0) {
		s7_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 8) &&
		pass == 0) {
		s8_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 9) &&
		pass == 0) {
		s9_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 10) &&
		pass == 0) {
		s10_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 11) &&
		pass == 0) {
		s11_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 12) &&
		pass == 0) {
		s12_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 13) &&
		pass == 0) {
		s13_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 14) &&
		pass == 0) {
		s14_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 15) &&
		pass == 0) {
		s15_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 16) &&
		pass == 0) {
		s16_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 17) &&
		pass == 0) {
		s17_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 18) &&
		pass == 0) {
		s18_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 19) &&
		pass == 0) {
		s19_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 20) &&
		pass == 0) {
		s20_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 21) &&
		pass == 0) {
		s21_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 22) &&
		pass == 0) {
		s22_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 23) &&
		pass == 0) {
		s23_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 24) &&
		pass == 0) {
		s24_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 25) &&
		pass == 0) {
		s25_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 26) &&
		pass == 0) {
		s26_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 27) &&
		pass == 0) {
		s27_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 28) &&
		pass == 0) {
		s28_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 29) &&
		pass == 0) {
		s29_1.render(renderer);
	}
	else if (!entity || (entity.getResourceState().getDataMap().getInt("Button4") == 30) &&
		pass == 0) {
		s30_1.render(renderer);
	}


	if (!entity ||(pass == 0) && ( entity.getResourceState().getDataMap().getInt(
			"Button2") == 0)) {

		if (!entity ||(pass == 0) && (entity.getResourceState().getDataMap().getInt(
				"Button2") == 0)) {
			GL11.glPushMatrix();
			renderer.rotate(move1, 'Y', (cabPosX + 121.20) / 100, (cabPosY + 129.43) /
				100, (cabPosZ + 1002.50) / 100);
			ebtf_MCa.render(renderer);
			GL11.glPopMatrix();
			GL11.glPushMatrix();
			renderer.rotate(move2, 'Y', (cabPosX + 73.65) / 100, (cabPosY + 140.89) /
				100, (cabPosZ + 1000.15) / 100);
			ebtf_MCb.render(renderer);
			GL11.glPopMatrix();
		}
		if (!entity ||(pass == 0) && (entity.getResourceState().getDataMap().getInt(
				"Button2") == 0)) {
			GL11.glPushMatrix();
			renderer.rotate(move1, 'Y', (cabPosX - 121.20) / 100, (cabPosY + 129.43) /
				100, (cabPosZ - 1002.50) / 100);
			ebtf_MCa2.render(renderer);
			GL11.glPopMatrix();
			GL11.glPushMatrix();
			renderer.rotate(move2, 'Y', (cabPosX - 73.65) / 100, (cabPosY + 140.89) /
				100, (cabPosZ - 1000.15) / 100);
			ebtf_MCb2.render(renderer);
			GL11.glPopMatrix();
		}
	}


	var speed, BC, MR, notch, cabPosX, cabPosY, cabPosZ, move1, move2;
	try {
		speed = entity.getSpeed() * 72.0;
		BC = entity.brakeCount * 3;
		MR = ((entity.brakeAirCount + 216) * (100 / 432)) + 700;
		notch = entity.getNotch();
	} catch (e) {}
	cabPosX = trainConfig("cabPosX");
	cabPosY = trainConfig("cabPosY");
	cabPosZ = trainConfig("cabPosZ");
	switch (notch) {
		case -8:
			move2 = (9 / 8) * +90;
			break;
		case -7:
			move2 = (7 / 8) * +90;
			break;
		case -6:
			move2 = (6 / 8) * +90;
			break;
		case -5:
			move2 = (5 / 8) * +90;
			break;
		case -4:
			move2 = (4 / 8) * +90;
			break;
		case -3:
			move2 = (3 / 8) * +90;
			break;
		case -2:
			move2 = (2 / 8) * +90;
			break;
		case -1:
			move2 = (1 / 8) * +90;
			break;
		case 1:
			move1 = (1 / 5) * -120;
			break;
		case 2:
			move1 = (2 / 5) * -120;
			break;
		case 3:
			move1 = (3 / 5) * -120;
			break;
		case 4:
			move1 = (4 / 5) * -120;
			break;
		case 5:
			move1 = (5 / 5) * -120;
			break;
	}
	if (notch <= 0) {
		move1 = 0;
	}
	if (notch >= 0) {
		move2 = 0;
	}


	//#################################################################################################################################################################################################
	//

	if (!entity || (pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) &&
		entity.getTrainStateData(0) == 0) {
		GL11.glPushMatrix();
		var angle1 = (speed / 95) * 178;
		renderer.rotate(angle1, 'Z', (cabPosX + 118.66) / 100, (cabPosY + 138.86) /
			100, (cabPosZ + 1012.76) / 100);
		ebtf_Ms.render(renderer);
		GL11.glPopMatrix();
	}


	//######################
	//
	if (!entity || (pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) &&
		entity.getTrainStateData(0) == 1) {
		GL11.glPushMatrix();
		var angle1 = (speed / 95) * -178;
		renderer.rotate(angle1, 'Z', (cabPosX - 118.66) / 100, (cabPosY + 138.86) /
			100, (cabPosZ - 1012.76) / 100);
		ebtf_Ms2.render(renderer);
		GL11.glPopMatrix();
	}
	//###########################

		if (!entity ||(pass == 0 || pass == 2 || pass == 3 || pass == 4) && (entity.getResourceState().getDataMap().getInt("Button2") == 1) && entity.getTrainStateData(1) == -8) {
			ebtf_Lb8.render(renderer);
		}


	if (!entity || (pass == 0) && (entity.getResourceState().getDataMap().getInt(
			"Button2") == 0)) {

		if (!entity || (pass == 0) && (entity.getResourceState().getDataMap().getInt(
				"Button2") == 0) && entity.getTrainStateData(0) == 0) {
			GL11.glPushMatrix();
			renderer.rotate(move1, 'Y', (cabPosX + 121.20) / 100, (cabPosY + 129.43) /
				100, (cabPosZ + 1002.50) / 100);
			ebtf_MCa.render(renderer);
			GL11.glPopMatrix();
			GL11.glPushMatrix();
			renderer.rotate(move2, 'Y', (cabPosX + 73.65) / 100, (cabPosY + 140.89) /
				100, (cabPosZ + 1000.15) / 100);
			ebtf_MCb.render(renderer);
			GL11.glPopMatrix();
		}
		if (!entity || (pass == 0) && (entity.getResourceState().getDataMap().getInt(
				"Button2") == 0) && entity.getTrainStateData(0) == 1) {
			GL11.glPushMatrix();
			renderer.rotate(move1, 'Y', (cabPosX - 121.20) / 100, (cabPosY + 129.43) /
				100, (cabPosZ - 1002.50) / 100);
			ebtf_MCa2.render(renderer);
			GL11.glPopMatrix();
			GL11.glPushMatrix();
			renderer.rotate(move2, 'Y', (cabPosX - 73.65) / 100, (cabPosY + 140.89) /
				100, (cabPosZ - 1000.15) / 100);
			ebtf_MCb2.render(renderer);
			GL11.glPopMatrix();
		}
	}


	if (!entity || (pass == 0 || pass == 2 || pass == 3 || pass == 4) && (entity.getResourceState()
			.getDataMap().getInt("Button2") == 1)) {
		if (!entity || (pass == 0 || pass == 2 || pass == 3 || pass == 4) && (
				entity.getResourceState().getDataMap().getInt("Button2") == 1) && entity.getTrainStateData(1) ==
			-8) {
			ebtf_Lb8.render(renderer);
		}
		if (!entity || (pass == 0 || pass == 2 || pass == 3 || pass == 4) && (entity.getResourceState()
				.getDataMap().getInt("Button2") == 1) && entity.getTrainStateData(0) == 0) {
			GL11.glPushMatrix();
			renderer.rotate(move1, 'Y', (cabPosX + 121.20) / 100, (cabPosY + 129.43) /
				100, (cabPosZ + 1002.50) / 100);
			ebtf_MCa.render(renderer);
			GL11.glPopMatrix();
			GL11.glPushMatrix();
			renderer.rotate(move2, 'Y', (cabPosX + 73.65) / 100, (cabPosY + 140.89) /
				100, (cabPosZ + 1000.15) / 100);
			ebtf_MCb.render(renderer);
			GL11.glPopMatrix();
		}

		if (!entity || (pass == 0 || pass == 2 || pass == 3 || pass == 4) && (entity.getResourceState()
				.getDataMap().getInt("Button2") == 1) && entity.getTrainStateData(0) == 1) {
			GL11.glPushMatrix();
			renderer.rotate(move1, 'Y', (cabPosX - 121.20) / 100, (cabPosY + 129.43) /
				100, (cabPosZ - 1002.50) / 100);
			ebtf_MCa2.render(renderer);
			GL11.glPopMatrix();
			GL11.glPushMatrix();
			renderer.rotate(move2, 'Y', (cabPosX - 73.65) / 100, (cabPosY + 140.89) /
				100, (cabPosZ - 1000.15) / 100);
			ebtf_MCb2.render(renderer);
			GL11.glPopMatrix();
		}


	}
	if ((!entity || pass == 0 || pass == 2 || pass == 3 || pass == 4) && speed >=
		-3 || speed <= 3) {
		under3km.render(renderer);
	}
	if ((!entity || pass == 0 || pass == 2 || pass == 3 || pass == 4) && speed <
		-4 || speed > 4) {
		over4km.render(renderer);
	}


	//�O�ɏ���lightmove�͕��ɂȂ�
	//���ɏ���lightmove�͐��ɂȂ�

	//
	if (!entity || entity.doorMoveL > 1) {
		doorLL_lamp.render(renderer);
	}

	if (!entity || entity.doorMoveL <= 1) {
		doorLL_off_lamp.render(renderer);
	}

	if (!entity || entity.doorMoveR > 1) {
		doorRL_lamp.render(renderer);
	}

	if (!entity || entity.doorMoveR <= 1) {
		doorRL_off_lamp.render(renderer);
	}

	if ((!entity || entity.doorMoveL == 0 && entity.doorMoveR == 0)) {
		door_light.render(renderer);
	}


}


	//##### �ԗ����擾 ###########################
	function MCCTS(entity, par1) {
		var r;
		try {
			switch (par1) {
				case "entityID":
					r = entity.func_145782_y();
					break;
				case "tick":
					r = renderer.getTick(entity);
					break;
			}
		} catch (e) {}
		return r;
	}

	//##### DataID�V�t�g�Ǘ� #####################
	function MCCIDS(par1) {
		var r;
		switch (par1) {
			case "tick":
				r = 1;
				break;
			case "mode1":
				r = 2;
				break;
			case "mode2":
				r = 3;
				break;
		}
		return r;
	}

	//##### tick�Ǘ� #############################
	function detectTick(entity) {
		var entityID = MCCTS(entity, "entityID"),
			tick = MCCTS(entity, "tick"),
			prevTick = renderer.getData(entityID << MCCIDS("tick"));
		renderer.setData(entityID << MCCIDS("tick"), tick);
		if (tick != prevTick) return true;
		return false;
	}


//##### render_�ԑ� ####################
function render_body(entity, pass) {

	var varsion = MCVersionChecker();

	if (entity != null) {
		var form = isMiddleCar(entity);
		var Fnext = isFrontNextCar(entity);
		var max = isCarSize(entity);
	}


	if (entity != null) {
		if (varsion == "1.7.10" || varsion == "1.8.9" || varsion == "1.9.4") {
			var st0 = entity.getTrainStateData(0); //�i�s����
			var st1 = entity.getTrainStateData(1);
			var st2 = entity.getTrainStateData(2);
			var st3 = entity.getTrainStateData(3);
			var st4 = entity.getTrainStateData(4);
			var st5 = entity.getTrainStateData(5); //���C�g
			var st6 = entity.getTrainStateData(6);
			var st7 = entity.getTrainStateData(7);
			var st8 = entity.getTrainStateData(8); //������
			var st9 = entity.getTrainStateData(9); //�A�i�E���X
			var st10 = entity.getTrainStateData(10); //���o�[�T�[
			var st11 = entity.getTrainStateData(11); //������
		} else {
			var st0 = entity.getVehicleState(TrainState.getStateType(0)); //�i�s����
			var st1 = entity.getVehicleState(TrainState.getStateType(1));
			var st2 = entity.getVehicleState(TrainState.getStateType(2));
			var st3 = entity.getVehicleState(TrainState.getStateType(3));
			var st4 = entity.getVehicleState(TrainState.getStateType(4));
			var st5 = entity.getVehicleState(TrainState.getStateType(5)); //���C�g
			var st6 = entity.getVehicleState(TrainState.getStateType(6));
			var st7 = entity.getVehicleState(TrainState.getStateType(7));
			var st8 = entity.getVehicleState(TrainState.getStateType(8)); //������
			var st9 = entity.getVehicleState(TrainState.getStateType(9)); //�A�i�E���X
			var st10 = entity.getVehicleState(TrainState.getStateType(10)); //���o�[�T�[
			var st11 = entity.getVehicleState(TrainState.getStateType(11)); //������
		}
	}
}

//##### render_�h�A ####################
function render_door(entity, doorMove, pass, onUpdateTick) {

	var varsion = MCVersionChecker();

	var seatmode = 0,
		door = 0,
		Rev = 0;

	try {
		lightMove = (entity.seatRotation) / 45;
	} catch (e) {}

	if (entity != null) {
		var max = isCarSize(entity);
		if (varsion == "1.7.10" || varsion == "1.8.9" || varsion == "1.9.4") {
			seatmode = entity.getResourceState().getDataMap().getInt("Button5");
			door = entity.getTrainStateData(4);
			st10 = entity.getTrainStateData(10); //���o�[�T�[
		} else {
			seatmode = entity.getResourceState().getDataMap().getInt("Button5");
			door = entity.getVehicleState(TrainState.getStateType(4));
			Rev = entity.getVehicleState(TrainState.getStateType(10));
		}
		var dataMap = entity.getResourceState().getDataMap(); //dataMap�擾

		var s_mode3,
			s_mode4;

		var isControlCar = entity.isControlCar();


		if (isControlCar == false && max > 1 && seatmode > 0&&entity.getTrainStateData(10) >= 1&&(pass == 0 || pass == 2 || pass == 3 || pass == 4)) {

			GL11.glPushMatrix();
			door_LF.render(renderer);
			door_LB.render(renderer);
			door_RF.render(renderer);
			door_RB.render(renderer);
			GL11.glPopMatrix();

		} else {


			switch (door) {
				case 3:
					s_mode1 = doorMove;
					s_mode2 = doorMove;
					break;
				case 1:
					s_mode1 = doorMove;
					s_mode2 = 0;
					break;
				case 2:
					s_mode1 = 0;
					s_mode2 = doorMove;
					break;
				default:
					s_mode1 = 0;
					s_mode2 = 0;
					break;
			}

			if (seatmode > 0) {
				if (lightMove == 1) {
					s_mode3 = 1;
					s_mode4 = 0;
				}

				if (lightMove == -1) {
					s_mode3 = 0;
					s_mode4 = 1;
				}

			} else {
				s_mode3 = 1;
				s_mode4 = 1;
			}

			var mode1 = dataMap.getDouble("mode1S");
			var mode2 = dataMap.getDouble("mode2S");
			var mode3 = dataMap.getDouble("mode3S");
			var mode4 = dataMap.getDouble("mode4S");

			if (door > 0) {
				if (door == 1) {
					if (mode1 >= s_mode1) {
						mode1 = doorMove;
					}
				}
				if (door == 2) {
					if (mode2 >= s_mode2) {
						mode2 = doorMove;
					}
				}
				if (door == 3) {
					if (mode2 >= s_mode2) {
						mode2 = doorMove;
					}
					if (mode1 >= s_mode1) {
						mode1 = doorMove;
					}
				}
			} else {
				if (mode2 <= 0) {
					mode2 = 0;
				}
				if (mode1 <= 0) {
					mode1 = 0;
				}
			}

			if (seatmode > 0) {

				if (lightMove < 0) {
					if (mode4 >= 1) {
						mode4 = 1;
					}
					if (mode3 <= 0) {
						mode3 = 0;
					}
				}

				if (lightMove > 0) {
					if (mode3 >= 1) {
						mode3 = 1;
					}
					if (mode4 <= 0) {
						mode4 = 0;
					}
				}

			}

			if (seatmode == 0) {
				if (mode3 >= 1) {
					mode3 = 1;
				}
				if (mode4 >= 1) {
					mode4 = 1;
				}
			}

			//�덷�ɂ��U���h�~
			mode1 = mode1 * 1000;
			mode1 = Math.round(mode1);
			mode1 = mode1 / 1000;

			mode2 = mode2 * 1000;
			mode2 = Math.round(mode2);
			mode2 = mode2 / 1000;

			mode3 = mode3 * 1000;
			mode3 = Math.round(mode3);
			mode3 = mode3 / 1000;

			mode4 = mode4 * 1000;
			mode4 = Math.round(mode4);
			mode4 = mode4 / 1000;

			if (mode1 == 0 && entity.doorMoveL > 0) {

				GL11.glPushMatrix();
				doorLL.render(renderer);
				GL11.glPopMatrix();

			}

			if (mode2 == 0 && entity.doorMoveR > 0) {

				GL11.glPushMatrix();
				doorRL.render(renderer);
				GL11.glPopMatrix();

			}

			if (!(mode1 == 0 || mode2 == 0) && entity.doorMoveL > 0 && entity.doorMoveR >
				0) {

				GL11.glPushMatrix();
				doorLL.render(renderer);
				doorRL.render(renderer);
				GL11.glPopMatrix();

			}


			if (onUpdateTick == true) {

				if (s_mode1 > mode1) {
					mode1 = mode1 + 0.015;
				} else if (s_mode1 < mode1) {
					mode1 = mode1 - 0.015;
				}

				if (s_mode2 > mode2) {
					mode2 = mode2 + 0.015;
				} else if (s_mode2 < mode2) {
					mode2 = mode2 - 0.015;
				}

				if (s_mode3 > mode3) {
					mode3 = mode3 + 0.015;
				} else if (s_mode3 < mode3) {
					mode3 = mode3 - 0.015;
				}

				if (s_mode4 > mode4) {
					mode4 = mode4 + 0.015;
				} else if (s_mode4 < mode4) {
					mode4 = mode4 - 0.015;
				}

			}

			dataMap.setDouble("mode1S", mode1, false);
			dataMap.setDouble("mode2S", mode2, false);
			dataMap.setDouble("mode3S", mode3, false);
			dataMap.setDouble("mode4S", mode4, false);
		}

		GL11.glPushMatrix();
		GL11.glTranslatef(0.0, 0.0, mode2 * mode3);
		door_LF.render(renderer);
		GL11.glPopMatrix();

		GL11.glPushMatrix();
		GL11.glTranslatef(0.0, 0.0, -mode2 * mode4);
		door_LB.render(renderer);
		GL11.glPopMatrix();

		GL11.glPushMatrix();
		GL11.glTranslatef(0.0, 0.0, mode1 * mode3);
		door_RF.render(renderer);
		GL11.glPopMatrix();

		GL11.glPushMatrix();
		GL11.glTranslatef(0.0, 0.0, -mode1 * mode4);
		door_RB.render(renderer);
		GL11.glPopMatrix();

	}
}
