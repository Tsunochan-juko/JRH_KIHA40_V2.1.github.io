// GUI slots are compact; data.buttons retains stable internal semantic slots.
var ASARI_BUTTON_GUI_IDS=[4,0,-1,1,3,6,-1,9,7,8,12];
var asariSoundButtonLayouts=new Packages.java.util.WeakHashMap();
function asariReadButtonValues(map,out){
    for(var i=0;i<7;i++){var id=ASARI_BUTTON_GUI_IDS[i];out[i]=id<0?0:Number(map.getInt('Button'+id));}
}
function asariButtonWrite(map,key,value){
    // SYNC is echoed later on clients, so also apply a SAVE-only local write.
    map.setInt(key,value,3);map.setInt(key,value,2);
}
function asariMigrateButtons(entity){
    if(entity==null)return;
    var map=entity.getResourceState().getDataMap();
    if(Number(map.getInt('AsariButtonLayoutV3'))===1)return;
    var source=Number(map.getInt('AsariButtonLayoutV2'))===1?[4,0,1,3,6,9,7,8,12]:ASARI_BUTTON_GUI_IDS;
    var old=[];for(var i=0;i<source.length;i++)old[i]=Number(map.getInt('Button'+i));
    for(var j=0;j<source.length;j++)if(source[j]>=0)asariButtonWrite(map,'Button'+source[j],old[j]);
    var dummy=[2,5,10,11];for(var k=0;k<dummy.length;k++)asariButtonWrite(map,'Button'+dummy[k],0);
    asariButtonWrite(map,'AsariButtonLayoutV3',1);
}

function asariPrepareSoundButtons(su){
    var entity=su.getEntity();if(entity==null||asariSoundButtonLayouts.get(su)===entity)return;
    asariMigrateButtons(entity);asariSoundButtonLayouts.put(su,entity);
}

function asariMigrateKnownButtons(entity){
    var name=String(entity.getResourceState().getResourceSet().getConfig().trainName);
    if(/^as_JRH_40_/.test(name))asariMigrateButtons(entity);
}
