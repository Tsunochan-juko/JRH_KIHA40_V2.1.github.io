// RTM renders NORMAL/material 0 first, then the other material/alpha/light passes.
// Freeze one animation time per vehicle until its next NORMAL/material 0 call.
var asariVehicleRenderFrames = new Packages.java.util.WeakHashMap();
var asariPreviewRenderFrame = null;
function asariRealRenderTime() {
    try { return Number(Packages.java.lang.System.nanoTime()) / 1000000000; }
    catch (ignored) { return new Date().getTime() / 1000; }
}
function asariBeginRenderFrame(entity, pass, partialTick) {
    // PICK may be recursively invoked before NORMAL. Never start a frame for PICK.
    if (pass !== 0 || Number(renderer.currentMatId) !== 0) return;
    var state = {time: asariRealRenderTime()};
    if (entity == null) asariPreviewRenderFrame = state;
    else asariVehicleRenderFrames.put(entity, state);
}
function asariRenderFrameTime(entity) {
    var state = entity == null ? asariPreviewRenderFrame : asariVehicleRenderFrames.get(entity);
    if (state == null) {
        state = {time: asariRealRenderTime()};
        if (entity == null) asariPreviewRenderFrame = state;
        else asariVehicleRenderFrames.put(entity, state);
    }
    return state.time;
}

// Cache each animated Part's material membership once; do not transform empty draws.
var asariMaterialModel = null;
var asariPartMaterialCache = new Packages.java.util.WeakHashMap();
function asariInitMaterialFilter(modelObject) {
    asariMaterialModel = modelObject == null ? null : modelObject.model;
    asariPartMaterialCache.clear();
}
function asariPartUsesMaterial(part) {
    if (part == null) return false;
    var id=Number(renderer.currentMatId);
    if (asariMaterialModel == null || !isFinite(id) || id<0) return true;
    var materials=asariPartMaterialCache.get(part);
    if (materials == null) {
        materials={};
        var groups=part.getObjects(asariMaterialModel);
        for (var g=0;g<groups.length;g++) {
            if (groups[g]==null) continue;
            var faces=groups[g].faces;
            for (var f=0;f<faces.size();f++) materials[Number(faces.get(f).materialId)]=true;
        }
        asariPartMaterialCache.put(part,materials);
    }
    return materials[id]===true;
}
