// RTM local forward end: 0=+Z, 1=-Z. Formation resolves mixed car orientation.
function asariCabControlEnd(entity,data){
    if(entity==null)return 0;
    var now=asariRenderFrameTime(entity),state=data.asariControlFrame;
    if(state!=null&&state.time===now)return state.end;
    if(state==null)state=data.asariControlFrame={time:null,end:-1};
    var formation=entity.getFormation(),direction=Number(entity.getTrainDirection());
    var leading=formation==null||formation.isFrontCar(entity);
    state.end=leading&&(direction===0||direction===1)&&!(direction===0?data.connected0:data.connected1)?direction:-1;
    state.time=now;
    return state.end;
}
function asariCabControlEndVisible(entity,data,end){return asariCabControlEnd(entity,data)===end;}
