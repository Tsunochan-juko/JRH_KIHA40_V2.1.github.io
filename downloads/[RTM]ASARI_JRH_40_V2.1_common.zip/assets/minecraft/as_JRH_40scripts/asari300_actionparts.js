// KaizPatchX 1.10.4 / ES5 (Java 8 Nashorn).
// Model sides: 0 = +X (doa1/3), 1 = -X (doa2/4).
var AS300_VERSION = 3;
var AS300_SYNC_TICKS = 40;
var as300Cache = new Packages.java.util.WeakHashMap();
var as300Controls = [];
var as300Static;
var as300Sticker;
var as300NoAutoDoor1;
var as300NoAutoDoor2;
var as300AutoDoor1;
var as300AutoDoor2;
function as300Init(modelObject) {
    as300Static = renderer.registerParts(new Parts("as300_hanjidou_static"));
    as300Sticker = renderer.registerParts(new Parts("hanjido_sticker"));
    as300NoAutoDoor1 = renderer.registerParts(new Parts("NoAuto_door1"));
    as300NoAutoDoor2 = renderer.registerParts(new Parts("NoAuto_door2"));
    as300AutoDoor1 = renderer.registerParts(new Parts("Auto_door1"));
    as300AutoDoor2 = renderer.registerParts(new Parts("Auto_door2"));
    as300Controls = [];
    for (var i = 0; i < 4; i++) {
        as300AddControl("as300_out_" + i, "open", i);
        as300AddControl("as300_in_open_" + i, "open", i);
        as300AddControl("as300_in_close_" + i, "close", i);
    }
    // The modeled cab switches are grouped by door side, including both ends.
    // Match the corresponding Auto/NoAuto suffix, not each switch's X position.
    as300AddControl("insideface2_2", "cab", 0);
    as300AddControl("insideface2_1", "cab", 1);
    for (var j = 0; j < as300Controls.length; j++) {
        var part = as300Controls[j].part;
        as300Controls[j].materials = null;
        if (modelObject != null && modelObject.model != null) {
            var objects = part.getObjects(modelObject.model);
            var materials = {};
            for (var k = 0; k < objects.length; k++) {
                if (objects[k] != null) {
                    for (var faceIndex = 0; faceIndex < objects[k].faces.size(); faceIndex++) {
                        materials[Number(objects[k].faces.get(faceIndex).materialId)] = true;
                    }
                }
            }
            for (var meshIndex = 0; meshIndex < objects.length; meshIndex++) {
                if (objects[meshIndex] == null) continue;
                for (var fi = 0; fi < objects[meshIndex].faces.size(); fi++) {
                    var face = objects[meshIndex].faces.get(fi), vertices = face.vertices;
                    for (var ti = 1; ti < vertices.length - 1; ti++) {
                        var va = vertices[0], vb = vertices[ti], vc = vertices[ti + 1];
                        as300Controls[j].triangles.push([
                            Number(va.getX()), Number(va.getY()), Number(va.getZ()),
                            Number(vb.getX()), Number(vb.getY()), Number(vb.getZ()),
                            Number(vc.getX()), Number(vc.getY()), Number(vc.getZ())]);
                    }
                }
            }            as300Controls[j].materials = materials;
        }
    }
    as300InitCpuPicker();
}

function as300RenderDoorMode(entity, pass) {
    // Keep the Auto/NoAuto face visible while sealed, but suppress emissive RTM passes.
    if (as300IsSealed(entity) && pass >= 2 && pass <= 4) return;
    // Latest as_1: suffix 2 is +X (local RTM bit 2); suffix 1 is -X (bit 1).
    // Select exactly one mesh on each side, including when permission is closed.
    as300RenderDoorModeSide(entity, 0, as300NoAutoDoor2, as300AutoDoor2);
    as300RenderDoorModeSide(entity, 1, as300NoAutoDoor1, as300AutoDoor1);
}

function as300RenderDoorModeSide(entity, side, noAutoPart, autoPart) {
    var showNoAuto = entity != null && as300Semi(entity) && as300StandardSide(entity, side);
    var part = showNoAuto ? noAutoPart : autoPart;
    if (part != null) part.render(renderer);
}

function as300AddControl(name, action, door) {
    as300Controls.push({name: name, triangles: [], part: renderer.registerParts(new Parts(name)),
        action: action, door: door, side: door % 2,
        interior: name.indexOf("as300_in_") === 0});
}

function as300Tick(entity) {
    var world = entity.field_70170_p;
    if (world == null) world = entity.worldObj;
    return Number(typeof world.func_82737_E === "function" ? world.func_82737_E() : world.getTotalWorldTime());
}

function as300Stopped(entity) {
    var speed = Number(entity.getSpeed());
    return isFinite(speed) && Math.abs(speed) <= 0.001;
}

function as300Local(entity) {
    var c = as300Cache.get(entity);
    if (c == null) {
        c = {pending: {}, motion: [0, 0, 0, 0], direction: [0, 0, 0, 0], tick: null,
            targets: [0, 0, 0, 0], targetTick: null, targetsDirty: true};
        as300Cache.put(entity, c);
    }
    return c;
}

function as300Read(entity, key) {
    var map = entity.getResourceState().getDataMap();
    var raw = String(map.getString(key));
    var pending = as300Local(entity).pending[key];
    var now = as300Tick(entity);
    if (pending) {
        if (raw === pending.sent) {
            if (raw === pending.desired) {
                delete as300Local(entity).pending[key];
            } else {
                // Serialize repeated clicks on one key until the earlier echo arrives.
                pending.sent = pending.desired;
                pending.at = now;
                map.setString(key, pending.sent, 1);
                raw = pending.desired;
            }
        } else if (now >= pending.at && now - pending.at <= AS300_SYNC_TICKS) {
            raw = pending.desired;
        } else {
            // Prediction is temporary; a missing server echo must not stay active forever.
            delete as300Local(entity).pending[key];
        }
    }
    if (raw.length === 0) return null;
    try { return JSON.parse(raw); } catch (ignored) { return null; }
}

function as300Write(entity, key, value) {
    var raw = JSON.stringify(value);
    var local = as300Local(entity);
    var pending = local.pending[key];
    if (pending && pending.desired === raw) return;
    local.targetsDirty = true;
    if (pending) {
        pending.sent = raw; pending.desired = raw; pending.at = as300Tick(entity);
        entity.getResourceState().getDataMap().setString(key, raw, 1);
        return;
    }
    local.pending[key] = {sent: raw, desired: raw, at: as300Tick(entity)};
    // A SYNC write is echoed through the server; it is not an immediate local DataMap write.
    entity.getResourceState().getDataMap().setString(key, raw, 1);
}

function as300Semi(entity) {
    return Number(entity.getResourceState().getDataMap().getInt("Button9")) === 1;
}

function as300IsSealed(entity) {
    return entity != null && Number(entity.getResourceState().getDataMap().getInt("Button7")) === 1;
}

function as300StandardSide(entity, side) {
    return (Number(entity.getTrainStateData(TrainState.TrainStateType.State_Door.id)) &
        as300StandardBit(entity, side)) !== 0;
}

function as300Gate(entity, side) {
    var key = "Asari300Gate" + side;
    var value = as300Read(entity, key);
    if (value == null || value.v !== AS300_VERSION ||
        (value.enabled !== 0 && value.enabled !== 1) || typeof value.epoch !== "string" ||
        !isFinite(value.revision)) {
        value = {v: AS300_VERSION, enabled: 0, mode: 0, epoch: "3:0", revision: 0};
    }
    var mode = as300Semi(entity) ? 1 : 0;
    var enabled = !as300IsSealed(entity) && mode === 1 && as300StandardSide(entity, side) ? 1 : 0;
    if (value.enabled !== enabled || value.mode !== mode) {
        // Equal observed transitions derive equal records on different clients.
        // Closing the RTM side or leaving semi mode invalidates old door requests.
        // Count each changed field, so one engine seeing mode+permission together
        // derives the same epoch as another engine observing the two changes separately.
        var revision = Math.max(0, Math.floor(Number(value.revision))) +
            (value.enabled !== enabled ? 1 : 0) + (value.mode !== mode ? 1 : 0);
        value = {v: AS300_VERSION, enabled: enabled, mode: mode,
            epoch: "3:" + revision, revision: revision};
        as300Write(entity, key, value);
    }
    return value;
}

function as300DoorAllowed(entity, door) {
    // Semi-auto controls apply to each entrance on every car, including cars
    // coupled inside a consist. Keep the old one-man restriction for normal mode.
    if (as300Semi(entity)) return true;
    var map = entity.getResourceState().getDataMap();
    if (Number(map.getInt("Button6")) <= 0) return true;
    var direction = Number(entity.getTrainDirection());
    if (direction !== 0 && direction !== 1) return false;
    var leading = entity.getConnectedTrain(direction === 0 ? 0 : 1) == null;
    return leading && (direction === 0 ? door >= 2 : door < 2);
}

function as300IsOpen(entity, door, gate) {
    if (gate.enabled !== 1 || !as300DoorAllowed(entity, door)) return false;
    var value = as300Read(entity, "Asari300Door" + door);
    return value != null && value.v === AS300_VERSION && value.open === 1 &&
        value.epoch === gate.epoch;
}

function as300SideOpen(entity, side) {
    var gate = as300Gate(entity, side);
    return as300IsOpen(entity, side, gate) || as300IsOpen(entity, side + 2, gate);
}

function as300StandardBit(entity, side) {
    // Formation already converted the stored state to this car's coordinates.
    // Its geometry stays fixed when the driving cab or train direction changes.
    // Only as300SyncStandard converts the outgoing command to formation space.
    return side === 0 ? 2 : 1;
}

function as300SyncStandard(entity, side) {
    // Cab switches always toggle the RTM side. In semi mode this is permission;
    // in normal mode it opens/closes the whole side, including standard-key input.
    var id = TrainState.TrainStateType.State_Door.id;
    var old = Number(entity.getTrainStateData(id));
    var bit = as300StandardBit(entity, side);
    var next = old ^ bit;
    if ((next & bit) !== 0 && !as300Stopped(entity)) return false;
    // Reads are car-local, but Formation.setTrainStateData (also used by the
    // sync packet) expects the formation-oriented mask. A backwards car must
    // swap the bits before writing, or repeated clicks toggle different sides.
    var command = Number(entity.getTrainDirection()) === 0 ? next :
        ((next & 1) << 1) | ((next & 2) >> 1);
    entity.setTrainStateData(id, command);
    entity.syncTrainStateData(id, command);
    as300Gate(entity, side);
    return true;
}

function as300EmitSound(entity, kind, side, source) {
    var map = entity.getResourceState().getDataMap();
    var events;
    try { events = JSON.parse(String(map.getString("Asari300DoorSoundsV3"))); } catch (ignored) {}
    if (!Array.isArray(events)) events = [];
    var now = as300Tick(entity);
    events = events.filter(function(e) { return e && now - e.t >= 0 && now - e.t <= 40; });
    events.push({id: String(new Date().getTime()) + ":" + String(Math.random()),
        t: now, kind: kind, side: side, source: source,
        standard: Number(entity.getTrainStateData(TrainState.TrainStateType.State_Door.id))});
    var raw = JSON.stringify(events.slice(-16));
    // A local write lets the separate sound engine react without waiting for its own echo.
    // The SYNC write then relays the same event history to other clients.
    map.setString("Asari300DoorSoundsV3", raw, 0);
    map.setString("Asari300DoorSoundsV3", raw, 1);
}

function as300DoorPosition(entity, door, gate, request) {
    try {
        var motion = JSON.parse(String(entity.getResourceState().getDataMap().getString("Asari300DoorMotionV1")));
        if (Array.isArray(motion) && motion.length === 4 && isFinite(Number(motion[door])))
            return Math.max(0, Math.min(0.9, Number(motion[door])));
    } catch (ignoredMotion) {}
    if (request && request.v === AS300_VERSION && request.epoch === gate.epoch)
        return Number(request.open) === 1 ? 0.9 : 0;
    return 0;
}

function as300DoorMovingDirection(entity, door) {
    try {
        var direction = JSON.parse(String(entity.getResourceState().getDataMap().getString("Asari300DoorMotionDirV1")));
        if (Array.isArray(direction) && direction.length === 4) return Number(direction[door]);
    } catch (ignoredDirection) {}
    return 0;
}

function as300Click(entity, clickedPart) {
    if (entity == null || clickedPart == null || as300IsSealed(entity)) return;
    var control = null;
    for (var i = 0; i < as300Controls.length; i++) {
        if (clickedPart.equals(as300Controls[i].part)) { control = as300Controls[i]; break; }
    }
    if (control == null) return;
    var side = control.side;
    var gate = as300Gate(entity, side);
    if (control.action === "cab") {
        as300SyncStandard(entity, side);
        return;
    }
    // Closing remains possible while moving; opening requires a stationary car and permission.
    if (!as300Semi(entity) || gate.enabled !== 1 || !as300DoorAllowed(entity, control.door)) return;
    if (control.action === "open" && !as300Stopped(entity)) return;
    var open = control.action === "open" ? 1 : 0;
    var doorKey = "Asari300Door" + control.door;
    as300Write(entity, doorKey, {v: AS300_VERSION, open: open, epoch: gate.epoch});
}

function as300Movement(entity, partialTick) {
    if (entity == null) return [0, 0, 0, 0];
    var c = as300Local(entity), frame = asariRenderFrameTime(entity);
    if (c.motionFrame === frame) return c.motion;
    c.motionFrame = frame;
    var semi = as300Semi(entity), sealed = as300IsSealed(entity);
    var gates = [as300Gate(entity, 0), as300Gate(entity, 1)], targets = [];
    for (var door = 0; door < 4; door++) {
        var open = !sealed && (semi ? as300IsOpen(entity, door, gates[door % 2]) :
            as300DoorAllowed(entity, door) && as300StandardSide(entity, door % 2));
        targets[door] = open ? 0.9 : 0;
    }
    c.targets = targets;
    var edges = asariDoorStep(c, targets, asariDoorMotionTime(entity), sealed);
    asariPublishDoorEdges(entity, edges);
    return c.motion;
}

function as300PublishMotion(entity, moves) {
    var c = as300Local(entity);
    var positionChanged = c.publishedMotion == null;
    var directionChanged = c.publishedDirection == null;
    for (var i = 0; i < 4; i++) {
        var position = Math.max(0, Math.min(0.9, Number(moves[i]) || 0));
        if (!positionChanged && c.publishedMotion[i] !== position) positionChanged = true;
        if (!directionChanged && c.publishedDirection[i] !== c.direction[i]) directionChanged = true;
    }
    if (!positionChanged && !directionChanged) return;
    var map = entity.getResourceState().getDataMap();
    if (positionChanged) {
        var snapshot = [];
        for (var door = 0; door < 4; door++) snapshot.push(Math.max(0, Math.min(0.9, Number(moves[door]) || 0)));
        map.setString("Asari300DoorMotionV1", JSON.stringify(snapshot), 0);
        c.publishedMotion = snapshot;
    }
    if (directionChanged) {
        var directions = c.direction.slice(0);
        map.setString("Asari300DoorMotionDirV1", JSON.stringify(directions), 0);
        c.publishedDirection = directions;
    }
}

function as300RenderSideDoorLamps(entity, pass, data, moves) {
    if (entity == null || as300IsSealed(entity)) return;
    var semi = as300Semi(entity);
    // Semi mode follows side permission; normal mode follows actual door travel.
    // Both modes need Light passes even when the passenger interior lights are off.
    if (pass < 0 || pass > 4) return;
    var side0 = semi ? as300StandardSide(entity, 0) : moves[0] > 0 || moves[2] > 0;
    var side1 = semi ? as300StandardSide(entity, 1) : moves[1] > 0 || moves[3] > 0;
    // MQO: "13" is +X, "24" is -X, matching doa1/3 and doa2/4 respectively.
    if (side0) doorLL.render(renderer);
    if (side1) doorRL.render(renderer);
}

function as300RenderDoors(entity, pass, data, partialTick) {
    var moves = as300Movement(entity, partialTick);
    if (entity) as300PublishMotion(entity, moves);
    as300RenderSideDoorLamps(entity, pass, data, moves);
    if (entity && !(pass === 0 || (data.states[11] >= 1 && pass >= 2 && pass <= 4))) return;
    translatedDoor(door_LF, moves[0]);
    translatedDoor(door_RF, moves[1]);
    translatedDoor(door_LB, -moves[2]);
    translatedDoor(door_RB, -moves[3]);
}

function asariDoorwaySealedEnd(entity, side) {
    if (entity == null) return false;
    try {
        var ownMap = entity.getResourceState().getDataMap();
        if (Number(ownMap.getInt("Button7")) === 1) return true;
    } catch (ignoredOwnSeal) {}
    try {
        var neighbor = entity.getConnectedTrain(side);
        if (neighbor != null) {
            var neighborMap = neighbor.getResourceState().getDataMap();
            if (Number(neighborMap.getInt("Button7")) === 1) return true;
        }
    } catch (ignoredNeighborSeal) {}
    return false;
}
// No picking pass, glGet*, or per-frame triangle tests. Shared across script engines.
var AS300_PICK_SLOT = 830040;
var as300InputState = null;
var as300InputPlayer = null;
function as300InitCpuPicker() {
    for (var i = 0; i < as300Controls.length; i++) {
        var control = as300Controls[i], bounds = [Infinity, Infinity, Infinity, -Infinity, -Infinity, -Infinity];
        for (var j = 0; j < control.triangles.length; j++) {
            var triangle = control.triangles[j];
            for (var v = 0; v < 9; v++) {
                var axis = v % 3;
                bounds[axis] = Math.min(bounds[axis], triangle[v]);
                bounds[axis + 3] = Math.max(bounds[axis + 3], triangle[v]);
            }
        }
        control.bounds = bounds;
    }
    renderer.setData(AS300_PICK_SLOT, Packages.java.lang.Boolean.TRUE);
}
function as300RayBox(origin, direction, bounds, limit) {
    var near = 0, far = limit;
    for (var i = 0; i < 3; i++) {
        if (!isFinite(bounds[i]) || !isFinite(bounds[i + 3])) return null;
        if (Math.abs(direction[i]) < 1e-10) {
            if (origin[i] < bounds[i] - 0.0001 || origin[i] > bounds[i + 3] + 0.0001) return null;
        } else {
            var a = (bounds[i] - origin[i]) / direction[i], b = (bounds[i + 3] - origin[i]) / direction[i];
            near = Math.max(near, Math.min(a, b)); far = Math.min(far, Math.max(a, b));
            if (near > far + 0.0001) return null;
        }
    }
    return near;
}
function as300RayTriangle(origin, direction, t, limit) {
    var ax=t[3]-t[0], ay=t[4]-t[1], az=t[5]-t[2];
    var bx=t[6]-t[0], by=t[7]-t[1], bz=t[8]-t[2];
    var px=direction[1]*bz-direction[2]*by, py=direction[2]*bx-direction[0]*bz, pz=direction[0]*by-direction[1]*bx;
    var det=ax*px+ay*py+az*pz;
    if (Math.abs(det)<1e-10) return null;
    var x=origin[0]-t[0], y=origin[1]-t[1], z=origin[2]-t[2];
    var u=(x*px+y*py+z*pz)/det;
    if (u < -1e-7 || u > 1.0000001) return null;
    var qx=y*az-z*ay, qy=z*ax-x*az, qz=x*ay-y*ax;
    var v=(direction[0]*qx+direction[1]*qy+direction[2]*qz)/det;
    if (v < -1e-7 || u+v > 1.0000001) return null;
    var distance=(bx*qx+by*qy+bz*qz)/det;
    return distance >= 0 && distance <= limit ? distance : null;
}
function as300InverseRotation(v, yaw, pitch, roll) {
    // Inverse of RTM 1.10.4: Ry(yaw) * Rx(-pitch) * Rz(roll).
    var c=Math.cos(yaw), s=Math.sin(yaw), x=c*v[0]-s*v[2], z=s*v[0]+c*v[2], y=v[1];
    c=Math.cos(pitch); s=Math.sin(pitch);
    var yy=c*y-s*z; z=s*y+c*z; y=yy;
    c=Math.cos(roll); s=Math.sin(roll);
    return [c*x+s*y, -s*x+c*y, z];
}
function as300LocalRay(entity, ox, oy, oz, dx, dy, dz, partialTick) {
    var p=Math.max(0, Math.min(1, Number(partialTick))), radians=Math.PI/180;
    var yawDelta=(Number(entity.field_70177_z)-Number(entity.field_70126_B))%360;
    if (yawDelta>180) yawDelta-=360;
    if (yawDelta<-180) yawDelta+=360;
    var yaw=(Number(entity.field_70126_B)+yawDelta*p)*radians;
    var pitch=(Number(entity.field_70127_C)+(Number(entity.field_70125_A)-Number(entity.field_70127_C))*p)*radians;
    var roll=(Number(entity.prevRotationRoll)+(Number(entity.rotationRoll)-Number(entity.prevRotationRoll))*p)*radians;
    var x=Number(entity.field_70142_S)+(Number(entity.field_70165_t)-Number(entity.field_70142_S))*p;
    var y=Number(entity.field_70137_T)+(Number(entity.field_70163_u)-Number(entity.field_70137_T))*p;
    var z=Number(entity.field_70136_U)+(Number(entity.field_70161_v)-Number(entity.field_70136_U))*p;
    var origin=as300InverseRotation([ox-x,oy-y,oz-z],yaw,pitch,roll);
    var direction=as300InverseRotation([dx,dy,dz],yaw,pitch,roll);
    var offset=entity.getModelSet().getConfig().offset;
    if (offset != null) for (var i=0;i<3;i++) origin[i]-=Number(offset[i]);
    return {origin:origin,direction:direction};
}
function as300PickQuery(entity, ox, oy, oz, dx, dy, dz, partialTick, limit) {
    var ray=as300LocalRay(entity,ox,oy,oz,dx,dy,dz,partialTick), best=null, distance=Number(limit);
    var inside=Math.abs(ray.origin[0])<1.48 && Math.abs(ray.origin[2])<11.3 && ray.origin[1]>0 && ray.origin[1]<4.1;
    for (var i=0;i<as300Controls.length;i++) {
        var control=as300Controls[i], interior=control.interior || control.action==="cab";
        if (interior && !inside) continue;
        if (!interior) {
            var x=(control.bounds[0]+control.bounds[3])/2;
            if (x>0 ? ray.origin[0]<x-0.05 : ray.origin[0]>x+0.05) continue;
        }
        if (as300RayBox(ray.origin,ray.direction,control.bounds,distance)==null) continue;
        for (var j=0;j<control.triangles.length;j++) {
            var hit=as300RayTriangle(ray.origin,ray.direction,control.triangles[j],distance);
            if (hit!=null && (best==null || hit<distance)) {distance=hit;best=control;}
        }
    }
    return best==null ? "" : String(distance)+"|"+best.name;
}
function as300ClickNamed(entity, name) {
    for (var i=0;i<as300Controls.length;i++) if (as300Controls[i].name===String(name)) {
        as300Click(entity,as300Controls[i].part); return;
    }
}
function as300InvokePicker(targetRenderer, name, args) {
    return targetRenderer.getScript().invokeFunction(name,Java.to(args,"java.lang.Object[]"));
}
function as300PollCpuClick(entity, pass, partialTick) {
    if (entity==null || pass!==0 || Number(renderer.currentMatId)!==0) return;
    var mc=Packages.net.minecraft.client.Minecraft.func_71410_x(),player=mc.field_71439_g;
    if (player==null) return;
    // Forge's client-player custom NBT is shared by all model script engines.
    // It is only an input latch; no door state or network messages are stored here.
    if (as300InputPlayer!==player) {as300InputPlayer=player;as300InputState=player.getEntityData();}
    var down=Packages.org.lwjgl.input.Mouse.isButtonDown(1);
    if (!down) {if (as300InputState.func_74767_n("AsariCpuDoorHeldV1")) as300InputState.func_74757_a("AsariCpuDoorHeldV1",false);return;}
    if (as300InputState.func_74767_n("AsariCpuDoorHeldV1")) return;
    as300InputState.func_74757_a("AsariCpuDoorHeldV1",true);
    try {
        if (mc.field_71462_r!=null || !mc.field_71415_G) return;
        var viewer=mc.field_71451_h, world=mc.field_71441_e;
        if (viewer==null || world==null) return;
        // Use the same eye and look APIs as vanilla mouse interaction, never GL matrices.
        var eye=viewer.func_70666_h(partialTick), look=viewer.func_70676_i(partialTick);
        var ox=Number(eye.field_72450_a),oy=Number(eye.field_72448_b),oz=Number(eye.field_72449_c);
        var dx=Number(look.field_72450_a),dy=Number(look.field_72448_b),dz=Number(look.field_72449_c);
        var reach=Number(mc.field_71442_b.func_78757_d());
        if (!isFinite(reach) || reach<=0) return;
        var end=Packages.net.minecraft.util.Vec3.func_72443_a(ox+dx*reach,oy+dy*reach,oz+dz*reach);
        var block=world.func_72933_a(eye,end);
        if (block!=null && block.field_72307_f!=null) {
            var hit=block.field_72307_f, bx=Number(hit.field_72450_a)-ox,by=Number(hit.field_72448_b)-oy,bz=Number(hit.field_72449_c)-oz;
            reach=Math.min(reach,Math.sqrt(bx*bx+by*by+bz*bz));
        }
        var entities=world.field_72996_f, bestEntity=null,bestRenderer=null,bestName=null,bestDistance=Infinity;
        // A full world scan and the geometry tests happen once per press across all cars.
        for (var i=0;i<entities.size();i++) {
            var candidate=entities.get(i);
            if (!(candidate instanceof Packages.jp.ngt.rtm.entity.train.EntityTrainBase)) continue;
            if (Math.abs(Number(candidate.field_70165_t)-ox)>18 || Math.abs(Number(candidate.field_70163_u)-oy)>8 || Math.abs(Number(candidate.field_70161_v)-oz)>18) continue;
            var model=candidate.getModelSet().vehicleModel;
            // A conservative solid core prevents reaching another KiHa40 through a car side.
            // The outer shell stays outside this core so exterior buttons remain reachable.
            if (String(candidate.getModelName()).indexOf("as_JRH_40_")===0) {
                var localRay=as300LocalRay(candidate,ox,oy,oz,dx,dy,dz,partialTick);
                var origin=localRay.origin;
                var inCar=Math.abs(origin[0])<1.48 && Math.abs(origin[2])<11.3 && origin[1]>0 && origin[1]<4.1;
                if (!inCar) {
                    var core=as300RayBox(origin,localRay.direction,[-1.25,0.6,-10.3,1.25,3.4,10.3],reach);
                    if (core!=null) reach=Math.min(reach,core);
                }
            }
            if (model==null || model.renderer==null || model.renderer.getData(AS300_PICK_SLOT)==null) continue;
            var result=String(as300InvokePicker(model.renderer,"as300PickQuery",[candidate,ox,oy,oz,dx,dy,dz,partialTick,reach]));
            var separator=result.indexOf("|");
            if (separator<0) continue;
            var distance=Number(result.substring(0,separator));
            if (distance<=reach) {reach=distance;bestDistance=distance;bestEntity=candidate;bestRenderer=model.renderer;bestName=result.substring(separator+1);}
        }
        if (bestEntity!=null && bestDistance<=reach) as300InvokePicker(bestRenderer,"as300ClickNamed",[bestEntity,bestName]);
    } catch (error) {
        if (!as300InputState.func_74767_n("AsariCpuDoorWarnedV1")) {
            as300InputState.func_74757_a("AsariCpuDoorWarnedV1",true);
            if (typeof print==="function") print("[ASARI CPU door picker] "+error);
        }
    }
}

function as300RenderControls(entity, pass) {
    // AlphaBlend and all three Light textures require passes 1, 2, 3 and 4.
    if (!(pass >= 0 && pass <= 4) && pass !== RenderPass.PICK.id) return;
    // The exterior sticker uses normal/alpha passes only, with no emitted light.
    if ((pass === 0 || pass === 1) && as300Sticker != null) as300Sticker.render(renderer);
    // State 11 is RTM's standard interior light. Keep normal/transparent and
    // PICK geometry even with the light off; only gate the emissive passes.
    var drawInterior = !(pass >= 2 && pass <= 4) || entity == null ||
        Number(entity.getTrainStateData(11)) >= 1;
    // In the current 300/330 models this static group contains hanjidou2 signs.
    if (pass !== RenderPass.PICK.id && drawInterior && !as300IsSealed(entity)) as300Static.render(renderer);
    var material = Number(renderer.currentMatId);
    var filterMaterial = pass !== RenderPass.PICK.id && isFinite(material);
    for (var i = 0; i < as300Controls.length; i++) {
        var control = as300Controls[i];
        if (filterMaterial && control.materials != null && !control.materials[material]) continue;
        if (drawInterior || !control.interior) control.part.render(renderer);
    }
}

// Cab indicators use the same permission edges as the side lamps in semi mode.
function as300CabDoorSideLampOn(entity, data, side) {
    if (entity == null) return true;
    if (as300IsSealed(entity)) return false;
    if (as300Semi(entity)) return as300StandardSide(entity, side);
    return (side === 0 ? data.doorMoveL : data.doorMoveR) > 1;
}

function as300CabDoorLampOn(entity, data) {
    if (entity == null) return true;
    if (as300IsSealed(entity)) return false;
    if (as300Semi(entity)) return as300StandardSide(entity, 0) || as300StandardSide(entity, 1);
    return data.doorMoveL == 0 && data.doorMoveR == 0;
}
