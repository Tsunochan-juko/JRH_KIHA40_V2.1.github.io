// Shared KiHa40 cab partition motion and headlight fade. Seconds use a monotonic clock.
var ASARI_CAB_MOVE_SECONDS = 0.5;
var asariOnemanParts = null;
function asariCabStoredEnds(entity, data, controlButton) {
    var result = [];
    // One-man partition follows Button5; farebox exposure uses its own Button9.
    var exposed = entity != null && (controlButton === 9 ?
        Number(entity.getResourceState().getDataMap().getInt("Button9")) === 1 : data.buttons[5] == 1);
    for (var end = 0; end < 2; end++) {
        var connected = end === 0 ? data.connected0 : data.connected1;
        var passage = entity != null && connected && !asariDoorwaySealedEnd(entity, end);
        result[end] = entity != null && (!exposed || passage);
    }
    return result;
}
function asariCabPose(entity, data, now, controlButton) {
    var stored = asariCabStoredEnds(entity, data, controlButton);
    var targets = [stored[0] ? 0 : 1, stored[1] ? 0 : 1];
    var stateKey = controlButton === 9 ? "asariFareboxMotion" : "asariOnemanMotion";
    var state = data[stateKey];
    if (state == null) state = data[stateKey] = {time: now, levels: targets.slice(0), targets: targets.slice(0)};
    var step = Math.max(0, now - state.time) / ASARI_CAB_MOVE_SECONDS;
    for (var i = 0; i < 2; i++) {
        var delta = state.targets[i] - state.levels[i];
        state.levels[i] += Math.max(-step, Math.min(step, delta));
    }
    state.time = now;
    state.targets = targets;
    return {levels: state.levels, stored: stored};
}
function asariInitOneman(type) {
    asariOnemanParts = {
        front: renderer.registerParts(new Parts('oneman_pivot' + type + '_front')),
        rear: renderer.registerParts(new Parts('oneman_pivot' + type + '_rear'))
    };
}
function asariCabRotate(angle, x, z, draw) {
    var previousMode = GL11.glGetInteger(GL11.GL_MATRIX_MODE);
    GL11.glMatrixMode(GL11.GL_MODELVIEW);
    GL11.glPushMatrix();
    try { renderer.rotate(angle, 'Y', x, 0, z); draw(); }
    finally {
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
        GL11.glPopMatrix();
        GL11.glMatrixMode(previousMode);
    }
}
function asariRenderOneman(entity, pass, data) {
    if (pass < 0 || pass > 4 || asariOnemanParts == null) return;
    var now = asariFareboxLightTime(entity);
    var cached = data.asariOnemanFrame;
    if (cached == null || cached.time !== now) {
    var pose = asariCabPose(entity, data, now, 5);
    if (data.asariOnemanLight == null) data.asariOnemanLight = {};
    var levels = asariUpdateFareboxLightLevels(data.asariOnemanLight, now, [asariCabRoomLit(entity, data, 0), asariCabRoomLit(entity, data, 1)]);
    cached = data.asariOnemanFrame = {time:now, pose:pose, levels:levels};
    }
    var pose = cached.pose, levels = cached.levels;
    for (var end = 0; end < 2; end++) {
        var sign = end === 0 ? 1 : -1;
        var part = end === 0 ? asariOnemanParts.front : asariOnemanParts.rear;
        if (!asariPartUsesMaterial(part)) continue;
        // Reverse the arc while preserving the original endpoints: -162 + 360 = +198.
        asariCabRotate(198 * pose.levels[end], sign * 0.25630169, sign * 9.34423646,
            function () { asariRenderFareboxSurface(part, pass, levels[end]); });
    }
}
function asariHeadlightLevels(entity, data, now) {
    if (data.asariHeadlightLight == null) data.asariHeadlightLight = {};
    var targets = [data.buttons[1] == 1 && data.states[0] == 0 && !data.connected0,
        data.buttons[1] == 1 && data.states[0] == 1 && !data.connected1];
    var levels = asariUpdateFareboxLightLevels(data.asariHeadlightLight, now, targets, 0.075, 0.15);
    // Connected faces must never illuminate the neighbouring vehicle.
    if (data.connected0) levels[0] = 0;
    if (data.connected1) levels[1] = 0;
    return levels;
}
function asariRenderHeadlights(entity, pass, data) {
    if (pass < 0 || pass > 4) return;
    var levels = entity == null ? [1, 1] : asariHeadlightLevels(entity, data, asariFareboxLightTime(entity));
    if (pass < 2) { L_main_1sub.render(renderer); L_main_2sub.render(renderer); return; }
    if (entity == null) { asariRenderFareboxSurface(L_main_1, pass, 1); asariRenderFareboxSurface(L_main_2, pass, 1); return; }
    asariRenderFareboxSurface(L_main_1, pass, levels[0]);
    asariRenderFareboxSurface(L_main_2, pass, levels[1]);
}
