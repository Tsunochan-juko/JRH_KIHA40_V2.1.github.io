// Tested smoothstep motion: update once per vehicle/frame and hold settled values.
var asariLightNotchMaterials={},asariLightNotchPosition=[0,0,0];
function asariInitLightNotch(){
    asariLightNotchMaterials={};
    asariLightNotchPosition=[trainConfig('cabPosX'),trainConfig('cabPosY'),trainConfig('cabPosZ')];
}
function asariLightNotchTargets(notch,out){
    out[0]=notch>=1&&notch<=5&&notch===Math.floor(notch)?notch/5*-120:0;
    out[1]=notch===-8?9/8*90:notch<=-1&&notch>=-7&&notch===Math.floor(notch)?(-notch)/8*90:0;
    return out;
}
function asariLightNotchAdvance(state,power,brake,now){
    if(state==null)return {values:[power,brake],from:[power,brake],targets:[power,brake],started:now,moving:false};
    if(state.moving){
        var t=Math.min(1,Math.max(0,(now-state.started)/ASARI_NOTCH_MOVE_SECONDS));
        var f=t*t*(3-2*t);
        state.values[0]=state.from[0]+(state.targets[0]-state.from[0])*f;
        state.values[1]=state.from[1]+(state.targets[1]-state.from[1])*f;
        if(t>=1)state.moving=false;
    }
    if(state.targets[0]!==power||state.targets[1]!==brake){
        state.from[0]=state.values[0];state.from[1]=state.values[1];state.targets[0]=power;state.targets[1]=brake;state.started=now;
        state.moving=state.from[0]!==power||state.from[1]!==brake;
    }
    return state;
}

function asariRenderLightNotch(entity,pass,data){
    if(asariCabControlEnd(entity,data)<0)return;
    var mat=Number(renderer.currentMatId);
    if(asariLightNotchMaterials[mat]===undefined)asariLightNotchMaterials[mat]=asariPartUsesMaterial(ebtf_MCa)||asariPartUsesMaterial(ebtf_MCb)||asariPartUsesMaterial(ebtf_MCa2)||asariPartUsesMaterial(ebtf_MCb2);
    if(!asariLightNotchMaterials[mat])return;
    var owner=asariCabEasingState(entity),now=asariRenderFrameTime(entity),car=owner.asariLightNotch;
    if(car==null){car={frame:null,motion:null,lastInput:null,targets:[0,0]};owner.asariLightNotch=car;}
    if(car.frame!==now){
        car.frame=now;
        if(car.motion==null||car.motion.moving||car.lastInput!==data.notch){
            var goals=asariLightNotchTargets(data.notch,car.targets);
            car.motion=asariLightNotchAdvance(car.motion,goals[0],goals[1],now);
        }
        car.lastInput=data.notch;
    }
    asariRenderCabNotches(entity,pass,data,car.motion.values[0],car.motion.values[1],asariLightNotchPosition[0],asariLightNotchPosition[1],asariLightNotchPosition[2]);
}

// Legacy variant renderers retain their own lighting/draw paths.
var asariLightNotchEmpty=[0,0];
function asariLightNotchAngles(entity,data,power,brake){
    if(asariCabControlEnd(entity,data)<0)return asariLightNotchEmpty;
    var mat=Number(renderer.currentMatId);
    if(asariLightNotchMaterials[mat]===undefined)asariLightNotchMaterials[mat]=asariPartUsesMaterial(ebtf_MCa)||asariPartUsesMaterial(ebtf_MCb)||asariPartUsesMaterial(ebtf_MCa2)||asariPartUsesMaterial(ebtf_MCb2);
    if(!asariLightNotchMaterials[mat])return asariLightNotchEmpty;
    var owner=asariCabEasingState(entity),now=asariRenderFrameTime(entity),car=owner.asariLightNotch;
    if(car==null){car={frame:null,motion:null};owner.asariLightNotch=car;}
    if(car.frame!==now){
        car.frame=now;
        if(car.motion==null||car.motion.moving||car.motion.targets[0]!==power||car.motion.targets[1]!==brake)car.motion=asariLightNotchAdvance(car.motion,power,brake,now);
    }
    return car.motion.values;
}
