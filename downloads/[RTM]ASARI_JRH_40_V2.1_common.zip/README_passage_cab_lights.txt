Per-end cab illumination at an open gangway (2026-10-29)

All 132 vehicles / 53 renderers use asari_passage_cab_lights.js.
At a connected, traversable end, the cab room light is forced on while the
vehicle's passenger interior light (RTM train state 11) is on. It stays dark
when that interior light is off or either adjoining vehicle is sealed.
An uncoupled cab continues to follow its manual Button2 crew-room lamp switch.
Coupling never changes either switch.

Cab wall/door/console-body light surfaces are split by vehicle end:
insideFace_cab_front/rear, doorStaff_cab_front/rear,
ebtf_body_cab_front/rear, jomuin_2_cab_front/rear (where present).
The stored UVs, materials and face vertices are retained without modification.
Original insideface2_1/2 hit meshes remain intact for door operation.
Normal and alpha passes show both ends; light passes select the lit end only.
Farebox and oneman illumination uses the same per-end condition, retaining fades.
Instrument status indicators and external lights keep their existing conditions.

Backup: backups/before_passage_cab_lights_20261029
Validation/staged ZIPs: trials/passage_cab_lights_20261029
Minecraft runtime verification is still required.
