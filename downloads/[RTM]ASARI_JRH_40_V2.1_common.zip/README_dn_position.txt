DN labels: one set of four per vehicle (2026-10-29)

The screenshot's small square DN symbol uses mat6, UV U=0.475..0.596,
V=0.003..0.119 in as_Hokkaido_Light.png. It is not t_k_g_023.png.

Previously, stuff contained four upper symbols while 1700_fan contained
four lower symbols. Rendering both objects showed eight symbols on 1803.
700_fan also contained the upper symbols, overlapping those in stuff.

DN faces have been extracted into dn_upper / dn_lower without UV, material
or position changes. Duplicate upper surfaces are removed. Renderer helper
asari_dn_position.js submits exactly one set on normal/alpha passes only.

Series 1700: lower, except 1762 explicitly uses upper.
Series 700: upper. Other series keep their former upper placement.
as_2 uses eight triangles representing four physical symbols.
Backup: backups/before_dn_position_20261029
Validation, vehicle table and ZIPs: trials/dn_position_20261029
Minecraft runtime verification is still required.
