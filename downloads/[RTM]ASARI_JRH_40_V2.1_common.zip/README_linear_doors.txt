Passenger door continuity and motion-driven audio (2026-10-29)

All 132 vehicles / 53 renderers use asari_linear_door_motion.js.
Each door retains its own position, regardless of one-man restrictions or
semi-auto permission/mode changes. Changed conditions only change its target.
Motion is a straight translation at 0.3 metres/second over 0.9 metres.
A repeated same-direction command does not restart motion or sound.
A reversal starts at the current position and emits the new direction's sound.

Time uses a monotonic clock, independent of partial/material pass resets.
Elapsed time is capped to 0.1 seconds per update so returning from an off-screen
interval cannot teleport a door to a newly observed target.
The existing immediate sealed-car lock is preserved: closed, no door sound,
no announcements, and no door opening regardless of RTM commands.

AsariDoorMotionAudioV1 is a client-local queue of actual movement edges.
asari_linear_door_audio.js consumes each edge once via the existing sound updater.
All native JSON sound_DoorOpen/Close entries are empty to avoid playing sounds
on RTM permission commands when the physical doors did not move.
Original per-vehicle sound IDs are preserved in asariLinearSoundMap.
Series 300/330 retain open/close sound IDs and the semi-auto announcement rules.
Simultaneous opening and closing doors do not stop each other's sound.

Backup: backups/before_linear_doors_20261029
Validation and staged archives: trials/linear_doors_20261029
Minecraft runtime verification is still required.
