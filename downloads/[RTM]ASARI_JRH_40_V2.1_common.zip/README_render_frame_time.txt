Shared animation time for all material passes (2026-10-29)

Cause: door translation and farebox/partition rotation sampled the real-time
clock on every material call. NORMAL and LIGHT therefore rendered slightly
different positions, making the light texture visibly overlap during motion.

All 53 renderers / 132 vehicles now call asariBeginRenderFrame at render entry.
The installed KaizPatchX renderer starts NORMAL/material 0 before the remaining
normal, alpha and light material calls. That call samples one monotonic time
per vehicle. Subsequent material calls reuse it until the next base draw.
PICK and its partialTick resets cannot start or advance an animation frame.
Different vehicles have independent frame snapshots; preview has its own slot.

Passenger doors (normal and semi-auto), fareboxes, oneman partitions and their
light fades now share this captured time. Motion and sound edge updates thus
run at most once for the frame instead of advancing between base/light layers.
No MQO geometry, UVs, textures, depth offsets or OpenGL stack code was changed.

Backup: backups/before_render_frame_time_20261029
Validation/staged archives: trials/render_frame_time_20261029
Simulation covers 408 material calls with artificially delayed passes,
per-vehicle isolation, partialTick resets and continuing animation next frame.
Minecraft runtime appearance still requires in-game verification.
