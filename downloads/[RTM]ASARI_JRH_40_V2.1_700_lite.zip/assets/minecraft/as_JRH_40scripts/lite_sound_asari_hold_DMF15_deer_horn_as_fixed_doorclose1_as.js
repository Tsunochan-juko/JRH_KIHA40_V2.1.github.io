//include <scripts/DMF15.js>
var lite400EngineUpdate=onUpdate;
//include <as_JRH_40scripts/lite_horn_common.js>
var lite400HornConfig={"prefix":"asari_hold_deer_horn_as","fade":0.1,"volume":1,"start":0.126,"loop":0.876,"end":1.251,"lids":false};
onUpdate=function(su){try{lite400EngineUpdate(su);}finally{asariHornUpdate(su,lite400HornConfig);lite400DoorAudio(su);}};
var lite400AudioSeen=new Packages.java.util.WeakHashMap();
function lite400DoorAudio(su){
    var entity=su.getEntity();if(entity==null)return;
    var raw=String(entity.getResourceState().getDataMap().getString('Lite400DoorAudio'));
    if(lite400AudioSeen.get(su)===raw)return;lite400AudioSeen.put(su,raw);
    var event;try{event=JSON.parse(raw);}catch(ignored){return;}
    if(!event||!isFinite(event.at)||Math.abs(new Date().getTime()-event.at)>1500)return;
    if(event.open){su.stopSound("sound_asari40lite_700","dooropen_as");su.playSound("sound_asari40lite_700","dooropen_as",1,1,false);}
    if(event.close){su.stopSound("sound_asari40lite_700","doorclose1_as");su.playSound("sound_asari40lite_700","doorclose1_as",1,1,false);}
}
