// Trial for series 300 only. Full-range fade durations at 20 ticks/second.
var AS300_HALOGEN_RISE_TICKS = 3;
var AS300_HALOGEN_FALL_TICKS = 6;

function as300HalogenAdvance(value, target, elapsed) {
	var step = elapsed / (target ? AS300_HALOGEN_RISE_TICKS : AS300_HALOGEN_FALL_TICKS);
	return target ? Math.min(1, value + step) : Math.max(0, value - step);
}

function as300HalogenLevels(entity, data, partialTick) {
	// Advance only on world ticks. RTM invokes render once for several material passes,
	// so partialTick can reset between passes and must not drive the fade state.
	var now = Number(renderer.getTick(entity));
	if (!isFinite(now)) now = 0;
	var frontTarget = data.buttons[1] == 1 && data.states[0] == 0 && !data.connected0;
	var rearTarget = data.buttons[1] == 1 && data.states[0] == 1 && !data.connected1;
	var state = data.halogen300;
	// Start dark so a newly seen vehicle also fades in instead of snapping to Light.
	if (!state || now < state.time) {
		state = {time: now, front: 0, rear: 0,
			frontTarget: frontTarget, rearTarget: rearTarget};
		data.halogen300 = state;
	}
	var elapsed = Math.max(0, now - state.time);
	state.front = as300HalogenAdvance(state.front, frontTarget, elapsed);
	state.rear = as300HalogenAdvance(state.rear, rearTarget, elapsed);
	state.time = now;
	state.frontTarget = frontTarget;
	state.rearTarget = rearTarget;
	// A newly coupled end goes dark immediately; it must never glow into a cab.
	if (data.connected0) state.front = 0;
	if (data.connected1) state.rear = 0;
	return state;
}
function as300HalogenRenderPair(offPart, onPart, level, pass) {
	// Keep the ordinary lens texture fixed; only emissive passes are faded.
	if (pass < 2) { offPart.render(renderer); return; }
	// Never draw the ordinary/off texture into an RTM light-texture pass.
	if (level <= 0) return;
	if (level >= 1) { onPart.render(renderer); return; }
	GL11.glPushAttrib(GL11.GL_CURRENT_BIT | GL11.GL_COLOR_BUFFER_BIT |
		GL11.GL_ENABLE_BIT | GL11.GL_DEPTH_BUFFER_BIT);
	try {
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glDisable(GL11.GL_ALPHA_TEST);
		GL11.glDepthFunc(GL11.GL_LEQUAL);
		GL11.glDepthMask(false);
		// RTM's directional light passes normally use alpha 0.8.
		var alpha = (pass == 3 || pass == 4) ? 0.8 : 1;
		GL11.glColor4f(level, level, level, alpha);
		onPart.render(renderer);
	} finally {
		GL11.glPopAttrib();
	}
}

function as300RenderHalogenLights(entity, pass, data, partialTick) {
	if (pass < 0 || pass > 4) return;
	if (!entity) { L_main_1.render(renderer); L_main_2.render(renderer); return; }
	var state = as300HalogenLevels(entity, data, partialTick);
	as300HalogenRenderPair(L_main_1sub, L_main_1, state.front, pass);
	as300HalogenRenderPair(L_main_2sub, L_main_2, state.rear, pass);
}
