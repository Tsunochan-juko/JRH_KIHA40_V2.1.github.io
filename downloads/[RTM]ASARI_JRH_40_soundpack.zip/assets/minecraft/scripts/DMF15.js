importPackage(Packages.jp.ngt.ngtlib.util);
importPackage(Packages.jp.ngt.rtm.sound);
importPackage(Packages.jp.ngt.ngtlib.io);

function onUpdate(su) {
    onUpdate_RSM2(su);
}

//ここから下のプログラムをコピペしてonUpdate(su)にonUpdate_RSM2(su);を記述することで別のスクリプトに移植できます。
//##### 定数 #####

//音量フェードの時間の長さを設定します 単位:tick
var PowerFadeTime = 5;

//音量フェードの開始時間を遅らせます 単位:tick
var PowerFadeDelay = 0;

//トンネル走行音のフェードの時間の長さを設定します 単位:tick
var TunnelFadeTime = 10;


//##### データ #####
var SoundTrackData = [{"pitch":[[0,0.5],[10,0.7],[65,2]],"volume":[[0,0],[2,0],[7,0.3],[10,0.4],[19.9,0.5],[20,0],[95,0]],"isMute":false,"isNotchPower":true,"isNotchOff":true,"isNotchBrake":true,"isFadeMixer":false,"isTunnelFade":false,"fileName":"40joint_1.ogg"},{"pitch":[[0,0.1],[10,0.37],[57,0.95],[95,1.3],[130,1.5]],"volume":[[0,0],[49.9,0],[50,0.5],[130,0.5]],"isMute":false,"isNotchPower":true,"isNotchOff":true,"isNotchBrake":true,"isFadeMixer":false,"isTunnelFade":false,"fileName":"40joint_2.ogg"},{"pitch":[[0,0.1],[10,0.4],[57,1.2],[95,1.3]],"volume":[[0,0],[19.9,0],[20,0.5],[49.9,0.5],[50,0],[95,0]],"isMute":false,"isNotchPower":true,"isNotchOff":true,"isNotchBrake":true,"isFadeMixer":false,"isTunnelFade":false,"fileName":"40joint_3.ogg"},{"pitch":[[0,0.8],[20,0.9],[40,0.95],[95,1],[130,1.1]],"volume":[[0,0],[20,0.4],[50,0.9],[95,1],[130,1]],"isMute":false,"isNotchPower":true,"isNotchOff":true,"isNotchBrake":true,"isFadeMixer":false,"isTunnelFade":true,"fileName":"tunnel_sound.ogg"},{"pitch":[[0,0.9],[95,1.1]],"volume":[[0,0.2],[95,0.5],[130,0.5]],"isMute":false,"isNotchPower":true,"isNotchOff":true,"isNotchBrake":true,"isFadeMixer":false,"isTunnelFade":false,"fileName":"1700_neutral_sound.ogg"},{"pitch":[[0,0.9],[95,1.05]],"volume":[[0,0],[2,0],[10,0.1],[24,0.3],[130,0.5]],"isMute":false,"isNotchPower":false,"isNotchOff":false,"isNotchBrake":true,"isFadeMixer":true,"isTunnelFade":null,"fileName":"brake_sound.ogg"},{"pitch":[[0,1],[130,1]],"volume":[[0,0.3],[95,0.3]],"isMute":false,"isNotchPower":false,"isNotchOff":false,"isNotchBrake":true,"isFadeMixer":true,"isTunnelFade":null,"fileName":"brake1.ogg","isNotchOneShot":true},{"pitch":[[0,1],[130,1]],"volume":[[0,0],[1,0.2],[10,0.2],[130,0.2]],"isMute":false,"isNotchPower":true,"isNotchOff":true,"isNotchBrake":true,"isFadeMixer":false,"isTunnelFade":null,"fileName":"B_Idling_700.ogg"},{"pitch":[[0,1],[130,1]],"volume":[[0,0.4],[10,0.2],[30,0]],"isMute":false,"isNotchPower":true,"isNotchOff":true,"isNotchBrake":true,"isFadeMixer":false,"isTunnelFade":null,"fileName":"B_idling2_sound3.ogg"},{"pitch":[[0,1],[70,1.1],[130,1.12]],"volume":[[0,0],[20,0],[30,0.7],[60,0.8],[90,0.7],[130,0]],"isMute":false,"isNotchPower":true,"isNotchOff":false,"isNotchBrake":false,"isFadeMixer":true,"isTunnelFade":null,"fileName":"B_DMF15_sound1.ogg"},{"pitch":[[0,1],[70,1.7],[130,2]],"volume":[[0,0],[20,0],[30,0.4],[60,0.4],[90,0.3],[130,0.2]],"isMute":false,"isNotchPower":true,"isNotchOff":false,"isNotchBrake":false,"isFadeMixer":true,"isTunnelFade":null,"fileName":"B_DMF15_sound2.ogg"},{"pitch":[[0,0.9],[70,1],[130,1.1]],"volume":[[0,0],[20,0],[30,0.4],[60,0.6],[90,0.7],[130,0.8]],"isMute":false,"isNotchPower":true,"isNotchOff":false,"isNotchBrake":false,"isFadeMixer":true,"isTunnelFade":null,"fileName":"B_start_5_40-700.ogg"},{"pitch":[[0,1],[70,1.2],[130,1.2]],"volume":[[0,0.6],[20,0.4],[30,0.2],[35,0]],"isMute":false,"isNotchPower":true,"isNotchOff":false,"isNotchBrake":false,"isFadeMixer":true,"isTunnelFade":null,"fileName":"B_DMF15_acceralation2_so und.ogg"}];
var SoundEffectData = {};
var SoundData = {"40joint_1.ogg":["sound_asari_hokkaido","DMF13.40joint_1"],"40joint_2.ogg":["sound_asari_hokkaido","DMF13.40joint_2"],"40joint_3.ogg":["sound_asari_hokkaido","DMF13.40joint_3"],"tunnel_sound.ogg":["sound_asari_hokkaido","DMF13.tunnel_sound"],"1700_neutral_sound.ogg":["sound_asari_hokkaido","DMF13.1700_neutral_sound"],"brake_sound.ogg":["sound_asari_hokkaido","DMF13.brake_sound"],"brake1.ogg":["sound_asari_hokkaido","DMF13.brake1"],"B_Idling_700.ogg":["sound_asari_hokkaido","DMF15.B_Idling_700"],"B_idling2_sound3.ogg":["sound_asari_hokkaido","DMF15.B_idling2_sound3"],"B_DMF15_sound1.ogg":["sound_asari_hokkaido","DMF15.B_DMF15_sound1"],"B_DMF15_sound2.ogg":["sound_asari_hokkaido","DMF15.B_DMF15_sound2"],"B_start_5_40-700.ogg":["sound_asari_hokkaido","DMF15.B_start_5_40-700"],"B_DMF15_acceralation2_so und.ogg":["sound_asari_hokkaido","DMF15.B_DMF15_acceralation2_so und"]};
//##### データ #####

//##### onUpdate #####
function onUpdate_RSM2(su) {
    var entity = su.getEntity();
    var dataMap = entity.getResourceState().getDataMap();
    var speed = su.getSpeed();
    var notch = su.getNotch();
    //powerFade
    var powerFade = dataMap.getInt("powerFade");
    var powerFadeDelayTime = dataMap.getInt("powerFadeDelayTime");
    if (notch === 0) powerFadeDelayTime = Math.min(powerFadeDelayTime + 1, PowerFadeDelay);
    else if (speed > 0) powerFadeDelayTime = Math.max(powerFadeDelayTime - 1, 0);
    if (notch > 0 && powerFadeDelayTime === 0) powerFade = Math.min(powerFade + 1, PowerFadeTime);
    else if (notch < 0 && powerFadeDelayTime === 0) powerFade = Math.max(powerFade - 1, -PowerFadeTime);
    else if (powerFadeDelayTime === PowerFadeDelay) powerFade += powerFade < 0 ? 1 : powerFade > 0 ? -1 : 0;
    dataMap.setInt("powerFadeDelayTime", powerFadeDelayTime, 0);
    dataMap.setInt("powerFade", powerFade, 0);
    powerFade = powerFade / PowerFadeTime;
    //tunnelFade
    var isTunnel = su.inTunnel();
    var tunnelFade = dataMap.getInt("tunnelFade");
    if (isTunnel) tunnelFade = Math.min(tunnelFade + 1, TunnelFadeTime);
    else tunnelFade = Math.max(tunnelFade - 1, 0);
    dataMap.setInt("tunnelFade", tunnelFade, 0);
    tunnelFade = tunnelFade / TunnelFadeTime;
    // Reuse the vehicle-local notch history already maintained by RSM2.
    var prevNotch = dataMap.getInt("prevNotch");
    var brakeReady = dataMap.getInt("asariBrakeOperationReady") === 1;
    var brakeOperation = brakeReady && prevNotch === 0 && notch === -1;
    if (!brakeReady) dataMap.setInt("asariBrakeOperationReady", 1, 0);
    //SoundTrack
    SoundTrackData.forEach(function (trackData) {
        var soundName = trackData.fileName;
        var customPitch = 1;
        var customVolume = 1;
        /* 指定の音源でpitchとvolumeを乗算でカスタムすることができます
        例)
        if (soundName === "run_mo0.ogg") {//soundNameはRSM2での音源の表示名に対応します(拡張子付きファイル名)
            customPitch = 1.0;//ノッチに対して変化を加えるなど
            customVolume = 1.0;
        }
        */
        var sound = new SoundState(su, trackData);
        if (trackData.isNotchOneShot) {
            if (brakeOperation) sound.playOperation(speed, notch, tunnelFade, customPitch, customVolume);
        } else sound.play(speed, notch, powerFade, tunnelFade, customPitch, customVolume);
    });
    //SoundEffect
    var se = {};
    Object.keys(SoundEffectData).forEach(function (key) {
        var trackData = SoundEffectData[key];
        se[key] = new SoundState(su, trackData);
    });
    //Compressor
    var isCPActive = su.isComplessorActive();
    if (se["cpStart"]) se["cpStart"].playSE(isCPActive, false);
    if (se["cpLoop"]) se["cpLoop"].playSE(isCPActive, true);
    if (se["cpEnd"]) se["cpEnd"].playSE(!isCPActive, false);
    //Brake release
    dataMap.setInt("prevNotch", notch, 0);
    var isPlayBrakeH = prevNotch < notch && prevNotch === -8;
    var isPlayBrakeL = prevNotch <= 0 && prevNotch < notch && prevNotch < -1;
    var isPlayBrakeN = prevNotch < 0 && prevNotch < notch && notch >= 0;
    if (speed < 1) {
        if (se["brakeLow"]) se["brakeLow"].playSEOnce(isPlayBrakeL);
        if (se["brakeOff"]) se["brakeOff"].playSEOnce(isPlayBrakeN);
    }
    if (se["brakeHigh"]) se["brakeHigh"].playSEOnce(isPlayBrakeH);
}

//##### 関数 #####
var SoundState = function (su, trackData) {
    this.su = su;
    this.pitch = trackData.pitch || null;
    this.volume = trackData.volume || null;
    this.isMute = trackData.isMute || null;
    this.isNotchPower = trackData.isNotchPower || null;
    this.isNotchOff = trackData.isNotchOff || null;
    this.isNotchBrake = trackData.isNotchBrake || null;
    this.isFadeMixer = trackData.isFadeMixer || null;
    this.isTunnelFade = trackData.isTunnelFade; // null / true / false
    if (this.isTunnelFade === undefined) this.isTunnelFade = null;
    this.fileName = trackData.fileName;
    this.soundDmain = null;
    this.soundName = null;
    if (SoundData[this.fileName]) {
        this.soundDmain = SoundData[this.fileName][0];
        this.soundName = SoundData[this.fileName][1];
    }
};
SoundState.prototype = {
    getPitch: function (speed) {
        var pitch = interpolate(this.pitch, speed);
        return Math.min(Math.max(pitch, 0.5), 2.0);
    },
    getVolume: function (speed) {
        var volume = interpolate(this.volume, speed);
        if (speed > this.volume[this.volume.length - 1][0]) return 0;
        return Math.min(Math.max(volume, 0), 1.0);
    },
    getMixerVolume: function (notch, volumeFade, tunnelFade) {
        var volume = 1;
        var isNotchPower = this.isNotchPower;
        var isNotchOff = this.isNotchOff;
        var isNotchBrake = this.isNotchBrake;
        //Volume fade
        if (this.isFadeMixer && (isNotchOff !== isNotchPower || isNotchOff !== isNotchBrake)) {
            var notchFade = Number(volumeFade);
            var notchFadeF = Number(1 - Math.abs(notchFade));
            volume *= Math.max(
                Number(isNotchPower && notchFade > 0),
                Number(isNotchOff && notchFadeF > 0),
                Number(isNotchBrake && notchFade < 0)
            );
            volume *= isNotchOff ? Number(notchFadeF) : Number(Math.abs(notchFade));
        }
        else {
            volume *= Math.max(
                Number(isNotchPower && notch > 0),
                Number(isNotchOff && notch === 0),
                Number(isNotchBrake && notch < 0)
            );
        }
        //Tunnnel fade
        if (this.isTunnelFade !== null) {
            if (this.isTunnelFade === true) volume *= Number(tunnelFade);
            else volume *= Number(1 - tunnelFade);
        }
        volume *= Number(!this.isMute);
        return volume;
    },
    play: function (speed, notch, volumeFade, tunnelFade, customPitch, customVolume) {
        if (!this.soundDmain || !this.soundName) return;
        var pitch = this.getPitch(speed) * customPitch;
        var volume = this.getVolume(speed) * this.getMixerVolume(notch, volumeFade, tunnelFade) * customVolume;
        if (volume > 0) {
            this.su.playSound(this.soundDmain, this.soundName, volume, pitch, true);
        }
        else {
            this.su.stopSound(this.soundDmain, this.soundName);
        }
    },
    // One operation, one non-looping sample. Do not reissue playback while held.
    playOperation: function (speed, notch, tunnelFade, customPitch, customVolume) {
        if (!this.soundDmain || !this.soundName) return;
        var pitch = this.getPitch(speed) * customPitch;
        // A handle event must be audible immediately, before the continuous brake fade catches up.
        var volume = this.getVolume(speed) * this.getMixerVolume(notch, -1, tunnelFade) * customVolume;
        if (volume > 0) {
            this.su.stopSound(this.soundDmain, this.soundName);
            this.su.playSound(this.soundDmain, this.soundName, volume, pitch, false);
        }
    },
    //条件分岐がtrueのときに再生する(falseで停止)
    playSE: function (condition, isLoop) {
        if (condition) this.su.playSound(this.soundDmain, this.soundName, 1, 1, isLoop);
        else this.su.stopSound(this.soundDmain, this.soundName);
    },
    //1tickだけ再生処理を実行するSEに使用する
    playSEOnce: function (condition) {
        if (condition) {
            this.su.stopSound(this.soundDmain, this.soundName);
            this.su.playSound(this.soundDmain, this.soundName, 1, 1, false);
        }
    }
};
function interpolate(valueList, speed) {
    if (valueList.length === 1) return 0;
    if (speed < valueList[0][0]) return valueList[0][1];
    for (var i = 0; i < valueList.length - 1; i++) {
        var currentSpeed = valueList[i][0];
        var currentValue = valueList[i][1];
        var nextSpeed = valueList[i + 1][0];
        var nextValue = valueList[i + 1][1];
        if (speed >= currentSpeed && speed <= nextSpeed) {
            var ratio = (speed - currentSpeed) / (nextSpeed - currentSpeed);
            return currentValue + (nextValue - currentValue) * ratio;
        }
    }
    return valueList[valueList.length - 1][1];
}
