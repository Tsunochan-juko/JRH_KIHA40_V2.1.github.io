// KaizPatchX 1.10.4: DataMap flag 1 relays client -> server -> tracking clients.
// One atomic record avoids splitting an edge across separate network packets.
var ASARI_HORN_SYNC_KEY = "AsariHornSyncV3";
var ASARI_HORN_HEARTBEAT_TICKS = 5;
var ASARI_HORN_TIMEOUT_TICKS = 40;
var ASARI_HORN_TAP_TICKS = 10;
var asariHornSenders = new Packages.java.util.WeakHashMap();
var asariHornReaders = new Packages.java.util.WeakHashMap();

function asariHornField(object, normal, srg) {
    if (object == null) return null;
    // Missing dynamic Java fields are null in Java 8 Nashorn.
    var value = object[srg];
    return value != null ? value : object[normal];
}

function asariHornEntityId(entity) {
    return Number(typeof entity.func_145782_y === "function" ?
        entity.func_145782_y() : entity.getEntityId());
}

function asariHornWorldTick(entity) {
    var world = asariHornField(entity, "worldObj", "field_70170_p");
    return Number(typeof world.func_82737_E === "function" ?
        world.func_82737_E() : world.getTotalWorldTime());
}

function asariHornInput(entity) {
    var mc = Packages.jp.ngt.ngtlib.util.NGTUtilClient.getMinecraft();
    var player = asariHornField(mc, "thePlayer", "field_71439_g");
    var sameWorld = asariHornField(mc, "theWorld", "field_71441_e") ===
        asariHornField(entity, "worldObj", "field_70170_p");
    var owned = player != null && sameWorld &&
        !asariHornField(entity, "isDead", "field_70128_L") &&
        asariHornField(player, "ridingEntity", "field_70154_o") === entity;
    var down = false;
    if (owned && asariHornField(mc, "currentScreen", "field_71462_r") == null &&
        asariHornField(mc, "inGameHasFocus", "field_71415_G") !== false) {
        var key = Packages.jp.ngt.rtm.event.RTMKeyHandlerClient.KEY_HORN;
        var code = typeof key.getKeyCode === "function" ? key.getKeyCode() : key.func_151463_i();
        // isPressed() would consume RTM's key event.
        down = code > 0 ? Packages.org.lwjgl.input.Keyboard.isKeyDown(code) :
            code < 0 ? Packages.org.lwjgl.input.Mouse.isButtonDown(code + 100) : false;
    }
    return {owned: owned, down: !!down, player: player, sameWorld: sameWorld};
}

function asariHornSignal(record, tick, local) {
    return {valid: true, local: local, down: record.d === 1,
        token: record.s + ":" + record.p, age: Math.max(0, tick - record.a) / 20,
        tap: record.p > 0 && record.d === 0 && record.z - record.a <= ASARI_HORN_TAP_TICKS &&
            tick - record.z <= ASARI_HORN_TAP_TICKS,
        pressTicks: Math.max(0, record.z - record.a)};
}

function asariHornSyncRead(entity, input) {
    if (entity == null) return {valid: false, down: false};
    input = input || asariHornInput(entity);
    if (input.owned) {
        var sender = asariHornSenders.get(entity);
        var predicted = sender != null && sender.owned ?
            asariHornSignal(sender.record, asariHornWorldTick(entity), true) :
            {valid: true, local: true, token: "", tap: false, age: 0};
        // Client SYNC writes do not change DataMap until the server echoes them.
        predicted.down = input.down;
        return predicted;
    }
    if (!input.sameWorld || asariHornField(entity, "isDead", "field_70128_L"))
        return {valid: false, down: false};
    var raw = String(entity.getResourceState().getDataMap().getString(ASARI_HORN_SYNC_KEY));
    var cache = asariHornReaders.get(entity);
    if (cache == null || cache.raw !== raw) {
        var record = null;
        try { record = JSON.parse(raw); } catch (ignored) {}
        cache = {raw: raw, record: record};
        asariHornReaders.put(entity, cache);
    }
    var r = cache.record;
    var tick = asariHornWorldTick(entity);
    var rider = asariHornField(entity, "riddenByEntity", "field_70153_n");
    if (r == null || r.v !== 3 || !isFinite(r.t) || !isFinite(r.a) || !isFinite(r.z) ||
        !isFinite(r.p) || (r.d !== 0 && r.d !== 1) || typeof r.s !== "string" ||
        rider == null || asariHornEntityId(rider) !== r.o ||
        tick - r.t > ASARI_HORN_TIMEOUT_TICKS || r.t - tick > ASARI_HORN_TIMEOUT_TICKS)
        return {valid: false, down: false};
    return asariHornSignal(r, tick, false);
}

function asariHornSyncPublish(entity) {
    var input = asariHornInput(entity);
    var state = asariHornSenders.get(entity);
    var tick = asariHornWorldTick(entity);
    if (input.owned) {
        if (state == null || !state.owned) {
            state = {owned: true, sent: -Infinity, record: {
                v: 3, o: asariHornEntityId(input.player),
                s: String(Packages.java.lang.System.nanoTime()),
                p: 0, d: 0, t: tick, a: tick, z: tick}};
            asariHornSenders.put(entity, state);
        }
        var r = state.record;
        var changed = r.d !== (input.down ? 1 : 0);
        if (changed) {
            r.d = input.down ? 1 : 0;
            if (input.down) { r.p++; r.a = tick; }
            else r.z = tick;
        }
        if (changed || state.sent === -Infinity ||
            (r.d === 1 && (tick - state.sent >= ASARI_HORN_HEARTBEAT_TICKS || tick < state.sent))) {
            r.t = tick;
            entity.getResourceState().getDataMap().setString(ASARI_HORN_SYNC_KEY, JSON.stringify(r), 1);
            state.sent = tick;
        }
    } else if (state != null && state.owned) {
        state.owned = false;
        state.record.d = 0;
        state.record.z = tick;
        state.record.t = tick;
        // A dimension change must not address an entity ID in the new world.
        if (input.sameWorld)
            entity.getResourceState().getDataMap().setString(ASARI_HORN_SYNC_KEY, JSON.stringify(state.record), 1);
    }
    return asariHornSyncRead(entity, input);
}
