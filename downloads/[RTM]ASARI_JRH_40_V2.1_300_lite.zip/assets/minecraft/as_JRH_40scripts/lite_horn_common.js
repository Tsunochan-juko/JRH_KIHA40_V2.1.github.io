// KaizPatchX / Minecraft 1.7.10, Nashorn. Included AFTER the engine script.
// Sound ticks, not render/material passes, drive the controller.
var asariHornStates = new Packages.java.util.WeakHashMap();
var asariHornDomain = "sound_asari40lite_300";
var asariHornEvents = new Packages.java.util.WeakHashMap();

function asariHornNow() {
    return Number(Packages.java.lang.System.nanoTime()) / 1000000000;
}

//include <as_JRH_40scripts/lite_horn_sync.js>

function asariHornClamp(value) {
    return Math.max(0, Math.min(1, value));
}

function asariHornGain(voice, now) {
    var age = Math.max(0, now - voice.born);
    if (voice.kind !== "loop" && age >= voice.duration) return 0;
    var gain = 1;
    if (voice.kind === "start" && voice.fade > 0) {
        gain = asariHornClamp((voice.duration - age) / voice.fade);
    } else if (voice.kind === "loop") {
        if (voice.fade > 0) {
            gain = asariHornClamp((age - voice.delay) / voice.fade);
        }
    } else if (voice.kind === "end" && voice.fade > 0) {
        gain = asariHornClamp(age / voice.fade);
    }
    if (voice.released >= 0) {
        gain = Math.min(gain, voice.releaseGain *
            asariHornClamp(1 - (now - voice.released) / voice.fade));
    }
    return gain;
}

function asariHornStopVoice(voice) {
    if (!voice.stopped) {
        voice.stopped = true;
        voice.su.stopSound(asariHornDomain, voice.path);
    }
}

function asariHornCreateVoice(su, state, config, kind, now, delay) {
    var voice = {kind: kind, born: now, delay: delay || 0, fade: config.fade,
        duration: kind === "start" ? config.start : config.end,
        released: -1, releaseGain: 1, stopped: false, su: su,
        path: config.prefix + "_" + kind, volume: config.volume};
    state.voices.push(voice);
    // RTM's own updater owns creation, volume updates, repeats and model-change
    // cleanup. No Java.extend or Minecraft method override is needed.
    su.playSound(asariHornDomain, voice.path,
        Math.max(0.00001, asariHornGain(voice, now)) * config.volume, 1.0, kind === "loop");
    return voice;
}

function asariHornRefresh(state, now) {
    for (var i = 0; i < state.voices.length; i++) {
        var voice = state.voices[i];
        if (voice.stopped) continue;
        if ((voice.kind !== "loop" && now - voice.born >= voice.duration + 0.05) ||
            (voice.released >= 0 && now - voice.released >= voice.fade)) {
            asariHornStopVoice(voice);
        } else {
            voice.su.playSound(asariHornDomain, voice.path,
                Math.max(0.00001, asariHornGain(voice, now)) * voice.volume,
                1.0, voice.kind === "loop");
        }
    }
}

function asariHornReleaseVoice(voice, now) {
    if (voice.stopped || voice.released >= 0) return;
    if (voice.fade === 0) {
        // Optional zero-fade configuration.
        asariHornStopVoice(voice);
    } else {
        voice.releaseGain = asariHornGain(voice, now);
        voice.released = now;
    }
}

function asariHornAbort(state) {
    for (var i = 0; i < state.voices.length; i++) asariHornStopVoice(state.voices[i]);
    state.voices = [];
    state.down = false;
    state.loop = null;
    state.attack = null;
}

function asariHornPress(su, state, config, now, late) {
    asariHornAbort(state);
    su.stopSound(asariHornDomain, config.prefix + "_start");
    su.stopSound(asariHornDomain, config.prefix + "_loop");
    su.stopSound(asariHornDomain, config.prefix + "_end");
    if (!late) state.attack = asariHornCreateVoice(su, state, config, "start", now, 0);
    if (late) {
        // A player entering tracking range during a hold joins the sustained
        // loop; the original attack is not replayed seconds later.
        state.loop = asariHornCreateVoice(su, state, config, "loop", now - config.fade, 0);
    } else if (config.fade > 0) {
        state.loop = asariHornCreateVoice(su, state, config, "loop", now,
            Math.max(0, config.start - config.fade));
    } else {
        state.loopDue = now + Math.max(0, config.start - 0.05);
    }
    state.down = true;
}


function asariHornUpdate(su, config) {
    var entity = su.getEntity();
    // Only the local rider publishes. Every client consumes the same record.
    var signal = asariHornSyncPublish(entity);
    if(config.lids)lite400PublishHornLid(entity,signal);
    var now = asariHornNow();
    var state = asariHornStates.get(su);
    if (!signal.valid) {
        if (state != null) {
            asariHornAbort(state);
            asariHornStates.remove(su);
        }
        return;
    }
    var seen = asariHornEvents.get(su);
    var newPress = signal.token !== seen && (signal.down || signal.tap);
    asariHornEvents.put(su, signal.token);
    if (state == null) {
        if (!signal.down && !newPress) return;
        state = {down: false, voices: [], touched: now, attack: null,
            loop: null, loopDue: -1};
        asariHornStates.put(su, state);
    }
    state.touched = now;
    if (newPress || (signal.down && !state.down)) {
        asariHornPress(su, state, config, now,
            !signal.local && signal.down && signal.age > config.start + 0.1);
    }
    if (signal.down && config.fade === 0 && state.loop == null && now >= state.loopDue) {
        state.loop = asariHornCreateVoice(su, state, config, "loop", now, 0);
    }
    if (!signal.down && state.down) {
        if (state.loop != null) asariHornReleaseVoice(state.loop, now);
        // A coalesced short tap still plays both intact start/end clips once.
        asariHornCreateVoice(su, state, config, "end", now, 0);
        state.loop = null;
        state.loopDue = -1;
    }
    state.down = signal.down;
    asariHornRefresh(state, now);
    state.voices = state.voices.filter(function(v) {return !v.stopped;});
    if (!state.down && state.voices.length === 0) asariHornStates.remove(su);
}



var lite400LidSignals=new Packages.java.util.WeakHashMap();
function lite400PublishHornLid(entity,signal){
    if(entity==null)return;
    var down=!!(signal.valid&&signal.down),token=signal.token||'',old=lite400LidSignals.get(entity);
    if(old!=null&&old.down===down&&old.token===token)return;
    lite400LidSignals.put(entity,{down:down,token:token});
    entity.getResourceState().getDataMap().setString('Lite400HornLid',JSON.stringify({down:down,token:token,tap:!!signal.tap,pressTicks:signal.pressTicks||0}),0);
}
