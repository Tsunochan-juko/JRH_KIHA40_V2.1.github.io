var LITE_MATERIALS={"13":{"6":true},"24":{"6":true},"lite_shell":{"0":true,"1":true,"2":true,"3":true,"4":true,"5":true},"lite_unlit":{"5":true},"lite_interior":{"0":true,"2":true,"3":true,"6":true,"7":true},"lite_cab_front":{"0":true,"2":true,"3":true,"5":true,"6":true},"lite_cab_rear":{"0":true,"2":true,"3":true,"5":true,"6":true},"doa1":{"0":true,"3":true,"5":true,"6":true},"doa2":{"0":true,"3":true,"5":true,"6":true},"doa3":{"0":true,"3":true,"5":true,"6":true},"doa4":{"0":true,"3":true,"5":true,"6":true},"L_main_1":{"5":true},"L_main_2":{"5":true},"13_lamp":{"5":true},"24_lamp":{"5":true},"13_off_lamp":{"5":true},"24_off_lamp":{"5":true},"door_light":{"0":true},"oneman_pivot1_front":{"0":true,"5":true},"oneman_pivot1_rear":{"0":true,"5":true},"horo_kakunou":{"0":true,"2":true,"3":true,"4":true},"horo_renketsu":{"0":true,"2":true,"3":true,"4":true},"not_horo_kakunou":{"0":true,"2":true,"3":true,"4":true},"not_horo_renketsu":{"0":true,"2":true,"3":true,"4":true},"1_2":{"8":true},"2_2":{"8":true},"3_2":{"8":true},"4_2":{"8":true},"5_2":{"8":true},"6_2":{"8":true},"7_2":{"8":true},"8_2":{"8":true},"9_2":{"8":true},"10_2":{"8":true},"11_2":{"8":true},"12_2":{"8":true},"13_2":{"8":true},"14_2":{"8":true},"15_2":{"8":true},"16_2":{"8":true},"17_2":{"8":true},"18_2":{"8":true},"19_2":{"8":true},"20_2":{"8":true},"21_2":{"8":true},"22_2":{"8":true},"23_2":{"8":true},"24_2":{"8":true},"25_2":{"8":true},"26_2":{"8":true},"27_2":{"8":true},"28_2":{"8":true},"29_2":{"8":true},"30_2":{"8":true},"lite_end_front":{},"lite_end_rear":{},"lite_hm_default":{},"lite_hm_linked":{},"lite_typhon_closed":{"3":true},"taifon_L":{"3":true},"taifon_R":{"3":true},"lite_typhon_front_minus_L":{"3":true},"lite_typhon_front_minus_R":{"3":true},"lite_typhon_rear_minus_L":{"3":true},"lite_typhon_rear_minus_R":{"3":true},"lite_typhon_rear_plus_L":{"3":true},"lite_typhon_rear_plus_R":{"3":true}};
var LITE_HORN_LEAVES=[{"name":"taifon_L","pivotX":1.1206,"pivotZ":10.5888,"direction":1,"pos":"front_plus","leaf":"L","sx":1,"sz":1},{"name":"taifon_R","pivotX":1.1206,"pivotZ":10.5888,"direction":-1,"pos":"front_plus","leaf":"R","sx":1,"sz":1},{"name":"lite_typhon_front_minus_L","pivotX":-1.1206,"pivotZ":10.5888,"direction":-1,"pos":"front_minus","leaf":"L","sx":-1,"sz":1},{"name":"lite_typhon_front_minus_R","pivotX":-1.1206,"pivotZ":10.5888,"direction":1,"pos":"front_minus","leaf":"R","sx":-1,"sz":1},{"name":"lite_typhon_rear_minus_L","pivotX":-1.1206,"pivotZ":-10.5888,"direction":1,"pos":"rear_minus","leaf":"L","sx":-1,"sz":-1},{"name":"lite_typhon_rear_minus_R","pivotX":-1.1206,"pivotZ":-10.5888,"direction":-1,"pos":"rear_minus","leaf":"R","sx":-1,"sz":-1},{"name":"lite_typhon_rear_plus_L","pivotX":1.1206,"pivotZ":-10.5888,"direction":-1,"pos":"rear_plus","leaf":"L","sx":1,"sz":-1},{"name":"lite_typhon_rear_plus_R","pivotX":1.1206,"pivotZ":-10.5888,"direction":1,"pos":"rear_plus","leaf":"R","sx":1,"sz":-1}];
var LITE_HAS_TYPHON=true;
// KiHa40 400 lightweight: no animated controls, gauges, farebox, picking or diagnostics.
var renderClass='jp.ngt.rtm.render.VehiclePartsRenderer';
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.org.lwjgl.opengl);
var liteParts={},liteCache={},liteKeys=[],liteLastEntity=null,liteLastState=null;
// LITE_MATERIALS is generated from the dedicated MQO, not scanned during rendering.
function init(par1,par2){
    liteParts={};liteCache={};liteKeys=[];liteLastEntity=null;liteLastState=null;
    liteParts["13"]=renderer.registerParts(new Parts("13"));
    liteParts["24"]=renderer.registerParts(new Parts("24"));
    liteParts["lite_shell"]=renderer.registerParts(new Parts("outsideBody","frame","face","hole","meiban3","meiban5","meiban7","sabouke1","zebra","KE93_1","KE93_2","taifon","skirt_1","skirt_2","engine","stuff","haisen","oneman_sticker","dn_lower","janpa_plus_disconnected"));
    liteParts["lite_unlit"]=renderer.registerParts(new Parts("L_main_1sub","L_main_2sub","L_tail_1sub","L_tail_2sub","13_off","24_off"));
    liteParts["lite_interior"]=renderer.registerParts(new Parts("amidana1","sikiri1","normal_wall","yanefan","1700_fan","insideBody","insideBody2","toilet","seat2+2","seiriken0","seiriken1","untinhyoujiki2"));
    liteParts["lite_cab_front"]=renderer.registerParts(new Parts("insideFace_cab_front","doorStaff_cab_front","ebtf_body_cab_front","ebtf_MCa","ebtf_MCb","ebtf_Mreverser_front","ebtf_Mdrive_front","ebtf_Ms","lite_cab_under3km_front","lite_cab_chu_front","lite_cab_always_light_front","lite_cab_insideface2_1_front","lite_cab_insideface2_2_front","ebtf_Mpressure_MR","ebtf_Mpressure_ER","ebtf_Mpressure_BC","ebtf_Mpressure_BP","farebox1_front","farebox1_front_lamp"));
    liteParts["lite_cab_rear"]=renderer.registerParts(new Parts("insideFace_cab_rear","doorStaff_cab_rear","ebtf_body_cab_rear","ebtf_MCa2","ebtf_MCb2","ebtf_Mreverser_rear","ebtf_Mdrive_rear","ebtf_Ms2","lite_cab_under3km_rear","lite_cab_chu_rear","lite_cab_always_light_rear","lite_cab_insideface2_1_rear","lite_cab_insideface2_2_rear","ebtf_Mpressure_MR2","ebtf_Mpressure_ER2","ebtf_Mpressure_BC2","ebtf_Mpressure_BP2","farebox1_rear","farebox1_rear_lamp"));
    liteParts["doa1"]=renderer.registerParts(new Parts("doa1"));
    liteParts["doa2"]=renderer.registerParts(new Parts("doa2"));
    liteParts["doa3"]=renderer.registerParts(new Parts("doa3"));
    liteParts["doa4"]=renderer.registerParts(new Parts("doa4"));
    liteParts["L_main_1"]=renderer.registerParts(new Parts("L_main_1"));
    liteParts["L_main_2"]=renderer.registerParts(new Parts("L_main_2"));
    liteParts["13_lamp"]=renderer.registerParts(new Parts("13_lamp"));
    liteParts["24_lamp"]=renderer.registerParts(new Parts("24_lamp"));
    liteParts["13_off_lamp"]=renderer.registerParts(new Parts("13_off_lamp"));
    liteParts["24_off_lamp"]=renderer.registerParts(new Parts("24_off_lamp"));
    liteParts["door_light"]=renderer.registerParts(new Parts("door_light"));
    liteParts["oneman_pivot1_front"]=renderer.registerParts(new Parts("oneman_pivot1_front"));
    liteParts["oneman_pivot1_rear"]=renderer.registerParts(new Parts("oneman_pivot1_rear"));
    liteParts["horo_kakunou"]=renderer.registerParts(new Parts("horo_kakunou"));
    liteParts["horo_renketsu"]=renderer.registerParts(new Parts("horo_renketsu"));
    liteParts["not_horo_kakunou"]=renderer.registerParts(new Parts("not_horo_kakunou"));
    liteParts["not_horo_renketsu"]=renderer.registerParts(new Parts("not_horo_renketsu"));
    liteParts["1_2"]=renderer.registerParts(new Parts("1_1"));
    liteParts["2_2"]=renderer.registerParts(new Parts("2_1"));
    liteParts["3_2"]=renderer.registerParts(new Parts("3_1"));
    liteParts["4_2"]=renderer.registerParts(new Parts("4_1"));
    liteParts["5_2"]=renderer.registerParts(new Parts("5_1"));
    liteParts["6_2"]=renderer.registerParts(new Parts("6_1"));
    liteParts["7_2"]=renderer.registerParts(new Parts("7_1"));
    liteParts["8_2"]=renderer.registerParts(new Parts("8_1"));
    liteParts["9_2"]=renderer.registerParts(new Parts("9_1"));
    liteParts["10_2"]=renderer.registerParts(new Parts("10_1"));
    liteParts["11_2"]=renderer.registerParts(new Parts("11_1"));
    liteParts["12_2"]=renderer.registerParts(new Parts("12_1"));
    liteParts["13_2"]=renderer.registerParts(new Parts("13_1"));
    liteParts["14_2"]=renderer.registerParts(new Parts("14_1"));
    liteParts["15_2"]=renderer.registerParts(new Parts("15_1"));
    liteParts["16_2"]=renderer.registerParts(new Parts("16_1"));
    liteParts["17_2"]=renderer.registerParts(new Parts("17_1"));
    liteParts["18_2"]=renderer.registerParts(new Parts("18_1"));
    liteParts["19_2"]=renderer.registerParts(new Parts("19_1"));
    liteParts["20_2"]=renderer.registerParts(new Parts("20_1"));
    liteParts["21_2"]=renderer.registerParts(new Parts("21_1"));
    liteParts["22_2"]=renderer.registerParts(new Parts("22_1"));
    liteParts["23_2"]=renderer.registerParts(new Parts("23_1"));
    liteParts["24_2"]=renderer.registerParts(new Parts("24_1"));
    liteParts["25_2"]=renderer.registerParts(new Parts("25_1"));
    liteParts["26_2"]=renderer.registerParts(new Parts("26_1"));
    liteParts["27_2"]=renderer.registerParts(new Parts("27_1"));
    liteParts["28_2"]=renderer.registerParts(new Parts("28_1"));
    liteParts["29_2"]=renderer.registerParts(new Parts("29_1"));
    liteParts["30_2"]=renderer.registerParts(new Parts("30_1"));
    liteParts["lite_end_front"]=renderer.registerParts(new Parts(""));
    liteParts["lite_end_rear"]=renderer.registerParts(new Parts(""));
    liteParts["lite_hm_default"]=renderer.registerParts(new Parts(""));
    liteParts["lite_hm_linked"]=renderer.registerParts(new Parts(""));
    liteParts["lite_typhon_closed"]=renderer.registerParts(new Parts("taifon_L","taifon_R","lite_typhon_front_minus_L","lite_typhon_front_minus_R","lite_typhon_rear_minus_L","lite_typhon_rear_minus_R","lite_typhon_rear_plus_L","lite_typhon_rear_plus_R"));
    liteParts["taifon_L"]=renderer.registerParts(new Parts("taifon_L"));
    liteParts["taifon_R"]=renderer.registerParts(new Parts("taifon_R"));
    liteParts["lite_typhon_front_minus_L"]=renderer.registerParts(new Parts("lite_typhon_front_minus_L"));
    liteParts["lite_typhon_front_minus_R"]=renderer.registerParts(new Parts("lite_typhon_front_minus_R"));
    liteParts["lite_typhon_rear_minus_L"]=renderer.registerParts(new Parts("lite_typhon_rear_minus_L"));
    liteParts["lite_typhon_rear_minus_R"]=renderer.registerParts(new Parts("lite_typhon_rear_minus_R"));
    liteParts["lite_typhon_rear_plus_L"]=renderer.registerParts(new Parts("lite_typhon_rear_plus_L"));
    liteParts["lite_typhon_rear_plus_R"]=renderer.registerParts(new Parts("lite_typhon_rear_plus_R"));
}

function liteDraw(name){
    if(LITE_MATERIALS[name][Number(renderer.currentMatId)]===true)liteParts[name].render(renderer);
}
function liteClock(){return Number(Packages.java.lang.System.nanoTime())/1000000000;}
function liteClamp(value){return Math.min(1,Math.max(0,value));}
function liteNeighborSealed(neighbor){
    if(neighbor==null)return false;
    var set=neighbor.getResourceState(),name=String(set.getResourceSet().getConfig().trainName);
    if(!/^as_JRH_40_/.test(name))return false;
    var map=set.getDataMap(),key=Number(map.getInt('AsariButtonLayoutV3'))===1?'Button7':Number(map.getInt('AsariButtonLayoutV2'))===1?'Button6':'Button8';
    return Number(map.getInt(key))===1;
}
function liteNewState(){return {tick:null,time:null,head:[0,0],headTarget:[0,0],pose:[0,0],poseTarget:[0,0],passage:[false,false],connected:[false,false],headOn:0,sign:0,one:0,interior:0,direction:0,doorMask:0,left:0,right:0,trainDir:0,moves:[0,0,0,0],motionDirection:[0,0,0,0],audioSerial:0};}
var litePreview=liteNewState();
function liteState(entity,pass,partialTick){
    var state;
    if(entity==null)state=litePreview;
    else if(liteLastEntity===entity)state=liteLastState;
    else{
        var key='e'+entity.func_145782_y();state=liteCache[key];
        if(state==null){if(liteKeys.length>=128)delete liteCache[liteKeys.shift()];liteKeys.push(key);state=liteCache[key]=liteNewState();}
        liteLastEntity=entity;liteLastState=state;
    }
    if(state.time!==null&&!(pass===0&&Number(renderer.currentMatId)===0))return state;
    var now=liteClock(),initial=state.time===null,dt=initial?0:Math.max(0,now-state.time);
    if(entity==null){state.direction=0;state.headOn=1;state.sign=1;state.one=0;state.interior=1;state.left=0;state.right=0;}
    else{
        var tick=Math.floor(Number(renderer.getTick(entity)));
        if(state.tick!==tick){
            state.tick=tick;var map=entity.getResourceState().getDataMap();
            state.headOn=Number(map.getInt('Button0'));state.sign=Number(map.getInt('Button3'));state.one=Number(map.getInt('Button6'));state.hornRaw=LITE_HAS_TYPHON?String(map.getString('Lite400HornLid')):'';
            state.trainDir=Number(entity.getTrainDirection());state.direction=Number(entity.getTrainStateData(0));state.interior=Number(entity.getTrainStateData(11));state.doorMask=Number(entity.getTrainStateData(4));
            for(var end=0;end<2;end++){var neighbor=entity.getConnectedTrain(end);state.connected[end]=neighbor!=null;state.passage[end]=neighbor!=null&&!liteNeighborSealed(neighbor);}
        }
        var leading=(state.trainDir===0||state.trainDir===1)&&!state.connected[state.trainDir];
        var frontAllowed=state.one!==1||leading&&state.trainDir===1;
        var rearAllowed=state.one!==1||leading&&state.trainDir===0;
        var rawLeft=.9*liteClamp(Number(renderer.getDoorMovementL(entity))),rawRight=.9*liteClamp(Number(renderer.getDoorMovementR(entity)));
        var audioOpen=false,audioClose=false;
        for(var door=0;door<4;door++){
            var previous=state.moves[door];
            var allowed=door<2?frontAllowed:rearAllowed,bit=door%2===0?2:1;
            var requested=allowed&&(state.doorMask&bit)!==0 ? .9 : 0;
            if(initial)state.moves[door]=allowed?(door%2===0?rawLeft:rawRight):0;
            else{var delta=requested-state.moves[door],step=Math.min(.1,dt)*.3;state.moves[door]+=Math.max(-step,Math.min(step,delta));}
            var motion=initial?0:state.moves[door]>previous?1:state.moves[door]<previous?-1:0;
            if(motion!==0&&motion!==state.motionDirection[door]){if(motion>0)audioOpen=true;else audioClose=true;}
            state.motionDirection[door]=motion;
        }

    }
    if(entity!=null&&(audioOpen||audioClose)){
        state.audioSerial++;
        entity.getResourceState().getDataMap().setString('Lite400DoorAudio',JSON.stringify({serial:state.audioSerial,open:audioOpen,close:audioClose,at:new Date().getTime()}),0);
    }
    for(var i=0;i<2;i++){
        var head=entity==null?1:state.headOn===1&&state.direction===i&&!state.connected[i]?1:0;
        var exposed=entity==null?1:state.one===1&&!state.passage[i]?1:0;
        if(initial){state.head[i]=head;state.pose[i]=exposed;}
        else{
            var target=state.headTarget[i],step=dt/(target ? .075 : .15);
            if(state.head[i]!==target)state.head[i]=target?Math.min(1,state.head[i]+step):Math.max(0,state.head[i]-step);
            var delta=state.poseTarget[i]-state.pose[i],move=dt/.5;
            if(delta!==0)state.pose[i]+=Math.max(-move,Math.min(move,delta));
        }
        if(state.connected[i])state.head[i]=0;
        state.headTarget[i]=head;state.poseTarget[i]=exposed;
    }
    liteUpdateHornLid(state,now);
    state.time=now;return state;
}
function liteTranslated(name,move){
    if(!LITE_MATERIALS[name][Number(renderer.currentMatId)])return;
    if(move===0){liteDraw(name);return;}
    GL11.glPushMatrix();try{GL11.glTranslatef(0,0,move);liteDraw(name);}finally{GL11.glPopMatrix();}
}
function liteOneman(name,end,exposure){
    if(!LITE_MATERIALS[name][Number(renderer.currentMatId)])return;
    if(exposure===0){liteDraw(name);return;}
    var sign=end===0?1:-1;
    GL11.glPushMatrix();try{renderer.rotate(198*exposure,'Y',sign*.25630169,0,sign*9.34423646);liteDraw(name);}finally{GL11.glPopMatrix();}
}
function liteHeadlight(name,pass,level){
    if(level<=0||!LITE_MATERIALS[name][Number(renderer.currentMatId)])return;
    GL11.glPushAttrib(GL11.GL_CURRENT_BIT|GL11.GL_COLOR_BUFFER_BIT|GL11.GL_ENABLE_BIT|GL11.GL_DEPTH_BUFFER_BIT);
    try{
        GL11.glEnable(GL11.GL_BLEND);GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);GL11.glDisable(GL11.GL_ALPHA_TEST);GL11.glDepthFunc(GL11.GL_LEQUAL);GL11.glDepthMask(false);
        GL11.glColor4f(1,1,1,(pass===3||pass===4 ? .8 : 1)*level);liteDraw(name);
    }finally{GL11.glPopAttrib();}
}
function render(entity,pass,partialTick){
    if(pass<0||pass>4)return;
    var state=liteState(entity,pass,partialTick),base=pass<2,inside=base||state.interior>=1;
    liteDraw('lite_shell');if(LITE_HAS_TYPHON)liteDrawHornLids(state.hornAngle||0);
    if(base){if(!state.passage[0])liteDraw('lite_end_front');if(!state.passage[1])liteDraw('lite_end_rear');liteDraw(state.connected[1]?'lite_hm_linked':'lite_hm_default');}
    if(base)liteDraw('lite_unlit');
    var cabFrontLit=state.interior>=1&&state.passage[0],cabRearLit=state.interior>=1&&state.passage[1];
    liteDrawCab('lite_cab_front',pass,cabFrontLit,entity);liteDrawCab('lite_cab_rear',pass,cabRearLit,entity);
    if(inside){
        liteDraw('lite_interior');
        liteTranslated('doa1',state.moves[0]);liteTranslated('doa2',state.moves[1]);liteTranslated('doa3',-state.moves[2]);liteTranslated('doa4',-state.moves[3]);

    }
    if(base||cabFrontLit)liteOneman('oneman_pivot1_front',0,state.pose[0]);
    if(base||cabRearLit)liteOneman('oneman_pivot1_rear',1,state.pose[1]);
    if(base||cabFrontLit)liteDraw(state.passage[0]?'horo_renketsu':'horo_kakunou');
    if(base||cabRearLit)liteDraw(state.passage[1]?'not_horo_renketsu':'not_horo_kakunou');
    var leftOpen=state.moves[0]>0||state.moves[2]>0,rightOpen=state.moves[1]>0||state.moves[3]>0;
    if(leftOpen)liteDraw('13');if(rightOpen)liteDraw('24');
    liteDraw(leftOpen?'13_lamp':'13_off_lamp');liteDraw(rightOpen?'24_lamp':'24_off_lamp');
    if(!leftOpen&&!rightOpen)liteDraw('door_light');
    if(base&&state.sign>=1&&state.sign<=30)liteDraw(state.sign+'_2');
    if(pass>=2){liteHeadlight('L_main_1',pass,state.head[0]);liteHeadlight('L_main_2',pass,state.head[1]);}
}

// Sound ticks publish changes; rendering only samples the per-vehicle record.
function liteUpdateHornLid(state,now){
    if(state.hornAt===undefined){state.hornAt=now;state.hornFrom=0;state.hornTarget=false;state.hornAngle=0;}
    var elapsed=Math.max(0,now-state.hornAt);
    state.hornAngle=state.hornTarget?Math.min(86,state.hornFrom+86*elapsed/.03):Math.max(0,state.hornFrom*(1-elapsed/.2));
    if(state.hornRaw===state.hornSeen)return;
    state.hornSeen=state.hornRaw;var event;
    try{event=JSON.parse(state.hornRaw);}catch(ignored){return;}
    if(!event||typeof event.down!=='boolean')return;
    if(!event.down&&event.tap&&event.token!==state.hornToken)state.hornAngle=Math.max(state.hornAngle,Math.min(86,86*Math.max(0,event.pressTicks||0)/.6));
    state.hornFrom=state.hornAngle;state.hornTarget=event.down;state.hornAt=now;state.hornToken=event.token;
}
function liteDrawHornLids(angle){
    if(!LITE_MATERIALS.lite_typhon_closed[Number(renderer.currentMatId)])return;
    if(angle===0){liteDraw('lite_typhon_closed');return;}
    for(var i=0;i<LITE_HORN_LEAVES.length;i++){
        var leaf=LITE_HORN_LEAVES[i];
        GL11.glPushMatrix();try{renderer.rotate(leaf.direction*angle,'Y',leaf.pivotX,0,leaf.pivotZ);liteDraw(leaf.name);}finally{GL11.glPopMatrix();}
    }
}

function liteDrawCab(name,pass,lit,entity){
    var mat=Number(renderer.currentMatId);if(!LITE_MATERIALS[name][mat])return;
    if(pass>=2){if(lit&&mat!==3)liteDraw(name);return;}
    if(!lit||mat!==3){liteDraw(name);return;}
    // The ordinary instrument/handle material has no Light slot.
    var helper=Packages.net.minecraft.client.renderer.OpenGlHelper,oldX=NaN,oldY=NaN;
    try{oldX=Number(helper.lastBrightnessX);oldY=Number(helper.lastBrightnessY);}catch(ignored){}
    if(!isFinite(oldX)||!isFinite(oldY)){var packed=Number(entity.func_70070_b(1));oldX=packed&65535;oldY=packed>>>16;}
    GL11.glPushAttrib(GL11.GL_LIGHTING_BIT|GL11.GL_ENABLE_BIT|GL11.GL_CURRENT_BIT);
    try{GL11.glDisable(GL11.GL_LIGHTING);Packages.jp.ngt.ngtlib.renderer.GLHelper.setLightmapMaxBrightness();liteDraw(name);}
    finally{try{helper.func_77475_a(helper.field_77476_b,oldX,oldY);}finally{GL11.glPopAttrib();}}
}
