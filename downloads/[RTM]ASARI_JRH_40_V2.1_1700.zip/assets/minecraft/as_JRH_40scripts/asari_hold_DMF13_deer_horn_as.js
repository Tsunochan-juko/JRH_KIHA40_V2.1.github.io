//include <scripts/DMF13.js>
var asariHornOriginalUpdate = onUpdate;
//include <as_JRH_40scripts/asari_horn_hold_common.js>
var asariHornConfig = {"prefix": "asari_hold_deer_horn_as", "fade": 0.1, "volume": 1.0, "start": 0.126, "loop": 0.876, "end": 1.251};
var asariHornEngineErrorReported = false;
var asariHornErrorReported = false;
onUpdate = function(su) {
    asariPrepareSoundButtons(su);
    try { asariHornOriginalUpdate(su); }
    catch (error) {
        if (!asariHornEngineErrorReported) {
            asariHornEngineErrorReported = true;
            print("[AsariHorn v3 sync] engine error: " + error);
            if (error.stack) print(error.stack);
        }
    }
    try { asariHornUpdate(su, asariHornConfig); }
    catch (error) {
        if (!asariHornErrorReported) {
            asariHornErrorReported = true;
            print("[AsariHorn v3 sync] horn error: " + error);
            if (error.stack) print(error.stack);
        }
        var failedState = asariHornStates.get(su);
        if (failedState != null) asariHornAbort(failedState);
    }
};

//include <as_JRH_40scripts/asari_button_layout.js>
