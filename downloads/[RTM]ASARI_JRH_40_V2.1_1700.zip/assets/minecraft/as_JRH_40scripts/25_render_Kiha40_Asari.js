var renderClass = "jp.ngt.rtm.render.VehiclePartsRenderer";
importPackage(Packages.org.lwjgl.opengl);
importPackage(Packages.jp.ngt.rtm.render);
importPackage(Packages.jp.ngt.ngtlib.math);
importPackage(Packages.jp.ngt.rtm);
importPackage(Packages.jp.ngt.rtm.entity.train.util);
importPackage(Packages.jp.ngt.ngtlib.util);
importPackage(Packages.org.lwjgl.input);
importPackage(Packages.org.lwjgl.util.vector);


function trainConfig(par1) {
	var doorLenght, cabPosX, cabPosY, cabPosZ, r, doorType, doorZ1, doorZ2;
	//############################################
	//############################################
	//
	doorLenght = 0.88; //
	cabPosX = 0.0; //
	cabPosY = 0.0; //
	cabPosZ = 0.0; //
	doorType = "slow"; //


	//
	doorZ1 = 0.0; //
	doorZ2 = 0.0; //
	//############################################
	//############################################
	doorZ1 = (Math.abs(doorZ1 - doorZ2)) / 100;
	if (doorZ1 > 0 && doorLenght == 0) {
		doorLenght = doorZ1;
	}
	switch (par1) {
		case "doorLenght":
			r = doorLenght;
			break;
		case "cabPosX":
			r = cabPosX;
			break;
		case "cabPosY":
			r = cabPosY;
			break;
		case "cabPosZ":
			r = cabPosZ;
			break;
		case "doorType":
			r = doorType;
			break;
	}
	return (r);
}



// Smoothly move the two existing notch handles between their existing angles.
var ASARI_NOTCH_MOVE_SECONDS = 0.1;
// Animation state must survive replacement of the per-tick render-data cache.
var asariCabEasingStates = new Packages.java.util.WeakHashMap();
var asariCabPreviewEasingState = {};
function asariCabEasingState(entity) {
    if (entity == null) return asariCabPreviewEasingState;
    var state=asariCabEasingStates.get(entity);
    if (state == null) {
        state={};
        asariCabEasingStates.put(entity,state);
    }
    return state;
}
function asariNotchEasedAngles(entity, data, targetPower, targetBrake) {
    var now=asariRenderFrameTime(entity), owner=asariCabEasingState(entity), state=owner.asariNotchMotion;
    if (!state) state=owner.asariNotchMotion={time:now,from:[targetPower,targetBrake],target:[targetPower,targetBrake]};
    var value=[0,0];
    for (var i=0;i<2;i++) {
        var elapsed=Math.max(0,now-state.time)/ASARI_NOTCH_MOVE_SECONDS;
        var t=Math.min(1,elapsed), eased=t*t*(3-2*t);
        value[i]=state.from[i]+(state.target[i]-state.from[i])*eased;
    }
    if (state.target[0]!==targetPower || state.target[1]!==targetBrake) {
        state.from=value;
        state.target=[targetPower,targetBrake];
        state.time=now;
    }
    if (state.target[0]!==targetPower || state.target[1]!==targetBrake) return value;
    var elapsed=Math.max(0,now-state.time)/ASARI_NOTCH_MOVE_SECONDS;
    var t=Math.min(1,elapsed), eased=t*t*(3-2*t);
    return [state.from[0]+(state.target[0]-state.from[0])*eased,
        state.from[1]+(state.target[1]-state.from[1])*eased];
}


// The former no0/no1/no2 meshes differ by -45/0/+45 degrees around Y.
var ASARI_REVERSER_PIVOT_X=1.2928644, ASARI_REVERSER_PIVOT_Z=10.0292147;
function asariReverserAngle(entity, selected, now) {
    var target=selected===0?-45:selected===2?45:0;
    var owner=asariCabEasingState(entity), state=owner.asariReverserMotion;
    if (!state) state=owner.asariReverserMotion={time:now,from:target,target:target};
    var elapsed=Math.min(1,Math.max(0,(now-state.time)/ASARI_NOTCH_MOVE_SECONDS));
    var eased=elapsed*elapsed*(3-2*elapsed);
    var angle=state.from+(state.target-state.from)*eased;
    if (state.target!==target) {
        state.from=angle;
        state.target=target;
        state.time=now;
    }
    return angle;
}

// Three drive-selector poses are Y rotations of the neutral mesh.
var ASARI_DRIVE_PIVOT_X=1.1397058, ASARI_DRIVE_PIVOT_Z=10.029348;
function asariDriveSelectorAngle(entity, modeTarget, now) {
    var selected=-1;
    for(var i=0;i<modeTarget.length;i++)if(modeTarget[i]>0.5){selected=i;break;}
    var owner=asariCabEasingState(entity), state=owner.asariDriveSelectorMotion;
    var requested=selected===0?45:selected===2?-45:0;
    if (!state) state=owner.asariDriveSelectorMotion={time:now,from:requested,target:requested};
    if(selected<0)requested=state.target;
    var elapsed=Math.min(1,Math.max(0,(now-state.time)/ASARI_NOTCH_MOVE_SECONDS));
    var eased=elapsed*elapsed*(3-2*elapsed);
    var angle=state.from+(state.target-state.from)*eased;
    if(state.target!==requested){
        state.from=angle;
        state.target=requested;
        state.time=now;
    }
    return angle;
}

function asariSelectorWeights(entity, key, target, now) {
    var owner=asariCabEasingState(entity), state=owner[key], count=target.length, levels=[];
    var selected=-1;for(var k=0;k<count;k++)if(target[k]>0.5){selected=k;break;}
    if (state && state.sampleTime===now && state.sampleSelected===selected) return state.sampleLevels;
    if (!state) {
        state=owner[key]={time:now,from:selected,target:selected};
        for(var n=0;n<count;n++)levels[n]=n===selected?1:0;
        return levels;
    }
    function sample(time) {
        var result=[];for(var i=0;i<count;i++)result[i]=0;
        if(state.from===state.target){if(state.target>=0)result[state.target]=1;return result;}
        var t=Math.min(1,Math.max(0,(time-state.time)/0.1));
        if(t<0.5){var out=1-((t*2)*(t*2)*(3-2*t*2));if(state.from>=0)result[state.from]=out;}
        else {var u=t*2-1,on=u*u*(3-2*u);if(state.target>=0)result[state.target]=on;}
        return result;
    }
    if(selected!==state.target){
        var current=sample(now),dominant=-1,best=0;
        for(var j=0;j<count;j++)if(current[j]>best){best=current[j];dominant=j;}
        if(dominant<0)dominant=now-state.time<0.15?state.from:state.target;
        state.from=dominant;state.target=selected;state.time=now;
    }
    state.sampleTime=now;state.sampleSelected=selected;state.sampleLevels=sample(now);
    return state.sampleLevels;
}
function asariRenderSelectorPart(part, alpha) {
    if (!asariPartUsesMaterial(part)) return;
    if(alpha<=0) return;
    if(alpha>=0.999){part.render(renderer);return;}
    GL11.glPushAttrib(GL11.GL_CURRENT_BIT|GL11.GL_COLOR_BUFFER_BIT|GL11.GL_ENABLE_BIT|GL11.GL_DEPTH_BUFFER_BIT);
    try {
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_ALPHA_TEST);
        GL11.glDepthFunc(GL11.GL_LEQUAL);
        GL11.glDepthMask(false);
        GL11.glColor4f(1,1,1,alpha);
        part.render(renderer);
    } finally { GL11.glPopAttrib(); }
}

function init(par1, par2) {
    asariInitMaterialFilter(par2);
    asariInitLightNotch();
	asariInitPressureNeedles();
	sampleobject = renderer.registerParts(new Parts("")); //

	body = renderer.registerParts(new Parts("door1", "door2", "door3", "door4",
		"outsideBody", "frame", "face", "hole",
		"meiban3", "meiban5", "meiban7",
		"sabouke2",



		"horn3",
		"skirt_1", "skirt_2",
		"DMF13HZI",
		"engine",
		"stuff", "doorLL_off", "doorRL_off")); //
	main2 = renderer.registerParts(new Parts("amidana1","sikiri1","normal_wall","yanefan","amidana1","sikiri1","normal_wall","yanefan","1700_fan", "insideBody",
		"insideBody2", "toilet", "seat2+2", "seiriken0","seiriken2", "untinhyoujiki1"));
	asariInitCabRooms(["insideFace","doorStaff","ebtf_body"]);
	haisenPart = renderer.registerParts(new Parts("haisen", "oneman_sticker"));
	asariInitDN(false);
	main4 = renderer.registerParts(new Parts("always_light"));

	door_LF = renderer.registerParts(new Parts("doa1")); //
	door_RF = renderer.registerParts(new Parts("doa2"));
	door_LB = renderer.registerParts(new Parts("doa3"));
	door_RB = renderer.registerParts(new Parts("doa4"));

	door_LFL = renderer.registerParts(new Parts("doa1L")); //
	door_RFL = renderer.registerParts(new Parts("doa2L"));
	door_LBL = renderer.registerParts(new Parts("doa3L"));
	door_RBL = renderer.registerParts(new Parts("doa4L"));

	sabo1 = renderer.registerParts(new Parts('sabo1'));
	sabo2 = renderer.registerParts(new Parts('sabo2'));

	asariInitOneman(1);

	s1_1 = renderer.registerParts(new Parts('1_2'));
	s2_1 = renderer.registerParts(new Parts('2_2'));
	s3_1 = renderer.registerParts(new Parts('3_2'));
	s4_1 = renderer.registerParts(new Parts('4_2'));
	s5_1 = renderer.registerParts(new Parts('5_2'));
	s6_1 = renderer.registerParts(new Parts('6_2'));
	s7_1 = renderer.registerParts(new Parts('7_2'));
	s8_1 = renderer.registerParts(new Parts('8_2'));
	s9_1 = renderer.registerParts(new Parts('9_2'));
	s10_1 = renderer.registerParts(new Parts('10_2'));
	s11_1 = renderer.registerParts(new Parts('11_2'));
	s12_1 = renderer.registerParts(new Parts('12_2'));
	s13_1 = renderer.registerParts(new Parts('13_2'));
	s14_1 = renderer.registerParts(new Parts('14_2'));
	s15_1 = renderer.registerParts(new Parts('15_2'));
	s16_1 = renderer.registerParts(new Parts('16_2'));
	s17_1 = renderer.registerParts(new Parts('17_2'));
	s18_1 = renderer.registerParts(new Parts('18_2'));
	s19_1 = renderer.registerParts(new Parts('19_2'));
	s20_1 = renderer.registerParts(new Parts('20_2'));
	s21_1 = renderer.registerParts(new Parts('21_2'));
	s22_1 = renderer.registerParts(new Parts('22_2'));
	s23_1 = renderer.registerParts(new Parts('23_2'));
	s24_1 = renderer.registerParts(new Parts('24_2'));
	s25_1 = renderer.registerParts(new Parts('25_2'));
	s26_1 = renderer.registerParts(new Parts('26_2'));
	s27_1 = renderer.registerParts(new Parts('27_2'));
	s28_1 = renderer.registerParts(new Parts('28_2'));
	s29_1 = renderer.registerParts(new Parts('29_2'));
	s30_1 = renderer.registerParts(new Parts('30_2'));

	asariInitFarebox(1);

	ebtf_MCb = renderer.registerParts(new Parts('ebtf_MCb'));
	ebtf_MCa = renderer.registerParts(new Parts('ebtf_MCa'));
	ebtf_Ms = renderer.registerParts(new Parts('ebtf_Ms'));
	ebtf_Mbc = renderer.registerParts(new Parts('ebtf_Mbc'));
	ebtf_Mmr = renderer.registerParts(new Parts('ebtf_Mmr'));

	ebtf_MCb2 = renderer.registerParts(new Parts('ebtf_MCb2'));
	ebtf_MCa2 = renderer.registerParts(new Parts('ebtf_MCa2'));
	ebtf_Ms2 = renderer.registerParts(new Parts('ebtf_Ms2'));
	ebtf_Mbc2 = renderer.registerParts(new Parts('ebtf_Mbc2'));
	ebtf_Mmr2 = renderer.registerParts(new Parts('ebtf_Mmr2'));

	doorLL = renderer.registerParts(new Parts("13"));
	doorRL = renderer.registerParts(new Parts("24"));
	doorLL_lamp = renderer.registerParts(new Parts("13_lamp"));
	doorRL_lamp = renderer.registerParts(new Parts("24_lamp"));
	doorLL_off_lamp = renderer.registerParts(new Parts("13_off_lamp"));
	doorRL_off_lamp = renderer.registerParts(new Parts("24_off_lamp"));
	door_light = renderer.registerParts(new Parts("door_light"));

	under3km = renderer.registerParts(new Parts("under3km"));
	over4km = renderer.registerParts(new Parts("over4km"));

	ebtf_Lb8 = renderer.registerParts(new Parts('ebtf_Lb8'));

	_choku = renderer.registerParts(new Parts("choku"));
	_chu = renderer.registerParts(new Parts("chu"));
	_hen = renderer.registerParts(new Parts("hen"));
	driveSelectorFront = renderer.registerParts(new Parts("ebtf_Mdrive_front"));
	driveSelectorRear = renderer.registerParts(new Parts("ebtf_Mdrive_rear"));
	mae = renderer.registerParts(new Parts("0"));
	usiro = renderer.registerParts(new Parts("2"));
	reverserFront = renderer.registerParts(new Parts("ebtf_Mreverser_front"));
	reverserRear = renderer.registerParts(new Parts("ebtf_Mreverser_rear"));


	//
	L_main_1 = renderer.registerParts(new Parts("L_main_1"));
	L_tail_1 = renderer.registerParts(new Parts("L_tail_1"));
	L_main_2 = renderer.registerParts(new Parts("L_main_2"));
	L_tail_2 = renderer.registerParts(new Parts("L_tail_2"));

	L_main_1sub = renderer.registerParts(new Parts("L_main_1sub"));
	L_tail_1sub = renderer.registerParts(new Parts("L_tail_1sub"));
	L_main_2sub = renderer.registerParts(new Parts("L_main_2sub"));
	L_tail_2sub = renderer.registerParts(new Parts("L_tail_2sub"));


	door_LFa = renderer.registerParts(new Parts("doorFL1"));
	door_RFa = renderer.registerParts(new Parts("doorFR1"));
	door_LBa = renderer.registerParts(new Parts("doorBL1"));
	door_RBa = renderer.registerParts(new Parts("doorBR1"));



	rollsignParts = [s1_1, s2_1, s3_1, s4_1, s5_1, s6_1, s7_1, s8_1, s9_1, s10_1, s11_1, s12_1, s13_1, s14_1, s15_1, s16_1, s17_1, s18_1, s19_1, s20_1, s21_1, s22_1, s23_1, s24_1, s25_1, s26_1, s27_1, s28_1, s29_1, s30_1];

	// +Z and -Z gangways; register the four independent MQO objects.
	horoKakunou = renderer.registerParts(new Parts("horo_kakunou"));
	horoRenketsu = renderer.registerParts(new Parts("horo_renketsu"));
	notHoroKakunou = renderer.registerParts(new Parts("not_horo_kakunou"));
	notHoroRenketsu = renderer.registerParts(new Parts("not_horo_renketsu"));
}
var rollsignParts;
// Bounded JS cache: no per-frame Java Map calls or closure/array allocation.
var vehicleCache = {};
var vehicleCacheKeys = [];
var previewData = {states: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
	buttons: [0, 0, 0, 0, 0, 0, 0], rawSpeed: 0, notch: 0,
	mode1: 0, mode2: 0, mode3: 1, mode4: 1, frontAllowed: true, rearAllowed: true};

function finiteNumber(value, fallback) {
	var n = Number(value);
	return isFinite(n) ? n : fallback;
}

function readTrainState(entity, id) {
	if (!entity) return 0;
	// Prefer the original accessor when available; modern RTM uses vehicle states.
	if (typeof entity.getTrainStateData == "function") return entity.getTrainStateData(id);
	return entity.getVehicleState(TrainState.getStateType(id));
}

function clamp(value, maximum) {
	return Math.max(0, Math.min(maximum, finiteNumber(value, 0)));
}

function approach(value, target, step) {
	if (value < target) return Math.min(target, value + step);
	if (value > target) return Math.max(target, value - step);
	return value;
}

function getRenderData(entity) {
	if (!entity) return previewData;
	var key = "e" + entity.func_145782_y();
	var data = vehicleCache[key];
	var tick = Math.floor(finiteNumber(renderer.getTick(entity), NaN));
	if (!data || data.entity !== entity) {
		if (!data) {
			if (vehicleCacheKeys.length >= 128) delete vehicleCache[vehicleCacheKeys.shift()];
			vehicleCacheKeys.push(key);
		}
		data = {entity: entity, tick: null, states: [], buttons: []};
		vehicleCache[key] = data;
	}
	if (data.tick !== null && data.tick === tick) return data;
	var elapsed = data.tick === null ? 1 : tick - data.tick;
	if (!isFinite(elapsed)) elapsed = 0;
	else if (elapsed < 0) elapsed = 1;
	data.tick = isFinite(tick) ? tick : null;
	if(!data.asariButtonLayoutReady){asariMigrateButtons(entity);data.asariButtonLayoutReady=true;}
	var map = entity.getResourceState().getDataMap();
	var states = data.states, buttons = data.buttons;
	states[0] = readTrainState(entity, 0);
	states[1] = readTrainState(entity, 1);
	states[4] = readTrainState(entity, 4);
	states[10] = readTrainState(entity, 10);
	states[11] = readTrainState(entity, 11);
	asariReadButtonValues(map,buttons);
	data.rawSpeed = finiteNumber(entity.getSpeed(), 0);
	var neighbor0=entity.getConnectedTrain(0);
    if(neighbor0!=null&&data.asariButtonNeighbor0!==neighbor0)asariMigrateKnownButtons(neighbor0);
    data.asariButtonNeighbor0=neighbor0;data.connected0=neighbor0!=null;
	var neighbor1=entity.getConnectedTrain(1);
    if(neighbor1!=null&&data.asariButtonNeighbor1!==neighbor1)asariMigrateKnownButtons(neighbor1);
    data.asariButtonNeighbor1=neighbor1;data.connected1=neighbor1!=null;
	data.notch = data.connected0 && data.connected1 ? 0 : finiteNumber(entity.getNotch(), 0);
	var frontAllowed = true, rearAllowed = true;
	if (buttons[5] > 0) {
		var direction = Number(entity.getTrainDirection());
		var leading = (direction == 0 || direction == 1) &&
			(direction == 0 ? !data.connected0 : !data.connected1);
		// Corrected from actual model feedback: direction 0 opens doa3/doa4.
		frontAllowed = leading && direction == 1;
		rearAllowed = leading && direction == 0;
	}
	data.frontAllowed = frontAllowed;
	data.rearAllowed = rearAllowed;
	var original1 = Number(map.getDouble("mode1S"));
	var original2 = Number(map.getDouble("mode2S"));
	var original3 = Number(map.getDouble("mode3S"));
	var original4 = Number(map.getDouble("mode4S"));
	var mode1 = clamp(original1, 0.9), mode2 = clamp(original2, 0.9);
	var mode3 = clamp(original3, 1), mode4 = clamp(original4, 1);
	if (elapsed > 0) {
		var step = 0.015 * elapsed, door = states[4];
		var active = frontAllowed || rearAllowed;
		mode1 = approach(mode1, active && (door == 1 || door == 3) ? 0.9 : 0, step);
		mode2 = approach(mode2, active && (door == 2 || door == 3) ? 0.9 : 0, step);
		mode3 = approach(mode3, frontAllowed ? 1 : 0, step);
		mode4 = approach(mode4, rearAllowed ? 1 : 0, step);
	}
	// Stable saved values require no write. Invalid values are repaired once.
	if (mode1 !== original1) map.setDouble("mode1S", mode1, false);
	if (mode2 !== original2) map.setDouble("mode2S", mode2, false);
	if (mode3 !== original3) map.setDouble("mode3S", mode3, false);
	if (mode4 !== original4) map.setDouble("mode4S", mode4, false);
	data.mode1 = mode1; data.mode2 = mode2;
	data.mode3 = mode3; data.mode4 = mode4;
	data.doorMoveL = entity.doorMoveL; data.doorMoveR = entity.doorMoveR;
	data.sealed = Number(map.getInt("Button7")) === 1;
	if (data.sealed) {
		states[4] = 0;
		data.frontAllowed = false; data.rearAllowed = false;
		data.mode1 = 0; data.mode2 = 0; data.mode3 = 0; data.mode4 = 0;
		data.doorMoveL = 0; data.doorMoveR = 0;
	}
	return data;
}

function translatedDoor(part, z) {
    if (!asariPartUsesMaterial(part)) return;
	if (z == 0) { part.render(renderer); return; }
	GL11.glPushMatrix();
	try {
		GL11.glTranslatef(0.0, 0.0, z);
		part.render(renderer);
	} finally {
		GL11.glPopMatrix();
	}
}

function render_door(entity, pass, data) {
	asariRenderLinearDoors(entity, pass, data);
}

// Coupled-end cab parts stay at the model rest position, without matrix work.
function renderCabPart(part, connected, angle, axis, x, y, z) {
    if(!asariCabControlEndVisible(asariCabRenderEntity,asariCabRenderData,z<0?1:0))return;
    if (!asariPartUsesMaterial(part)) return;
    if (!asariCabPartPass(asariCabRenderEntity,asariCabRenderPass,asariCabRenderData,z<0?1:0)) return;
	if (connected) {
		asariDrawCabPart(part,z);
		return;
	}
	GL11.glPushMatrix();
	renderer.rotate(angle, axis, x, y, z);
	asariDrawCabPart(part,z);
	GL11.glPopMatrix();
}
function asariRenderGaugePart(part, connected, angle, axis, x, y, z) {
    if (!asariPartUsesMaterial(part)) return;
    if (!asariCabPartPass(asariCabRenderEntity,asariCabRenderPass,asariCabRenderData,z<0?1:0)) return;
	if (renderer.currentMatId >= 0 && renderer.currentMatId != 3) return;

	GL11.glPushMatrix();
	renderer.rotate(z < 0 ? -17.612 : 17.612, 'X', x, y, z);
		renderer.rotate(connected ? (z<0 ? -0.551 : 0.551) : angle, axis, x, y, z);
	asariDrawCabPart(part,z);
	GL11.glPopMatrix();
}

// Gauge needles: flat source XY -> dial plane -> rotation about the dial normal.
// RTM counters are NOT kPa: pressure values below are an instrument approximation.
var asariPressureParts;
function asariInitPressureNeedles() {
    asariPressureParts = [];
    var names = ['MR','ER','BC','BP'];
    for (var end=0; end<2; end++) for (var i=0; i<4; i++)
        asariPressureParts.push(renderer.registerParts(new Parts('ebtf_Mpressure_'+names[i]+(end ? '2' : ''))));
}
function asariSpeedNeedleAngle(speed) {
    var kmh = Math.abs(Number(speed));
    if (!isFinite(kmh)) kmh = 0;
    // Dial: 0=-15 degrees, 60=90, 120=195. Original tip is -15.551 degrees.
    return Math.min(120, kmh)*1.75 + 0.551;
}
function asariGaugeValues(entity, data) {
    var now=asariFareboxLightTime(entity), state=data.asariGaugePressure;
    if (state && state.time === now) return state.values;
    var bc=0, mr=900, bp=500;
    if (entity != null) {
        bc=Number(entity.brakeCount); mr=Number(entity.brakeAirCount);
        if (!isFinite(bc)) bc=0;
        if (!isFinite(mr)) mr=2880;
        bc=Math.max(0,Math.min(144,bc))*500/144;
        mr=Math.max(0,Math.min(1000,mr*900/2880));
        bp=data.notch<=-8 ? 0 : 500-bc*0.3;
    }
    var target=[mr,500,bc,bp];
    if (!state) state=data.asariGaugePressure={time:now,values:target.slice(0)};
    var dt=Math.max(0,Math.min(1,now-state.time));
    if (dt>0) {
        var blend=1-Math.exp(-dt/0.12);
        for (var i=0;i<4;i++) state.values[i]+=(target[i]-state.values[i])*blend;
        state.time=now;
    }
    return state.values;
}
function asariRenderPressureNeedles(entity,pass,data) {
    if (pass<0 || pass>4 || (renderer.currentMatId>=0 && renderer.currentMatId!=3)) return;
    for (var end=0;end<2;end++) {
        if (!asariCabPartPass(entity,pass,data,end)) continue;
        var values=asariPressureValuesForEnd(entity,data,end),sign=end?-1:1;
        for (var i=0;i<4;i++) {
            var x=i<2?104.42544:92.25362,z=i%2===0?1012.69:1012.72;
            asariRenderGaugePart(asariPressureParts[end*4+i],false,sign*values[i]*0.24,
                'Z',(trainConfig('cabPosX')+sign*x)/100,
                (trainConfig('cabPosY')+138.75945)/100,(trainConfig('cabPosZ')+sign*z)/100);
        }
    }
}


// Keep stored gangways opaque/alpha-visible, but omit their emissive passes
// when Button2 (the existing cab-light switch) is off.
function asariDoorwaySealedEnd(entity, side) {
    if (entity == null) return false;
    try {
        var ownMap = entity.getResourceState().getDataMap();
        if (Number(ownMap.getInt("Button7")) === 1) return true;
    } catch (ignoredOwnSeal) {}
    try {
        var neighbor = entity.getConnectedTrain(side);
        if (neighbor != null) {
            var neighborMap = neighbor.getResourceState().getDataMap();
            if (Number(neighborMap.getInt("Button7")) === 1) return true;
        }
    } catch (ignoredNeighborSeal) {}
    return false;
}
function renderGangway(connected, linkedPart, storedPart, pass, data) {
	if (connected) linkedPart.render(renderer);
	else if (pass < 2 || data.buttons[2] == 1) storedPart.render(renderer);
}

function render(entity, pass, par3) {
	asariBeginRenderFrame(entity, pass, par3);
	var data = getRenderData(entity);
	var states = data.states, buttons = data.buttons;
    asariSetCabContext(entity,pass,data);
	// Different alpha/light passes remain; repeat calls within one pass are removed.
	if (pass >= 0) {
		body.render(renderer);
		// Use the cached connection state already used by the lamps and doors.
		renderGangway(data.connected0 && !asariDoorwaySealedEnd(entity, 0), horoRenketsu, horoKakunou, pass, data);
		renderGangway(data.connected1 && !asariDoorwaySealedEnd(entity, 1), notHoroRenketsu, notHoroKakunou, pass, data);
		main4.render(renderer);
		render_door(entity, pass, data);
	}

	if (!entity || ((pass == 0 || pass == 1) && states[11] >= 0) ||
		(states[11] >= 1 && pass >= 2 && pass <= 4)) main2.render(renderer);
	// Preserve the original unconditional pass-1 cab wall visibility.
	asariRenderCabRooms(entity, pass, data);
	if (pass == 0 || pass == 1) haisenPart.render(renderer);
	asariRenderDN(entity, pass);


	asariRenderHeadlights(entity, pass, data);
	if (!entity || states[0] == 0) {
		L_tail_1sub.render(renderer);
		if (data.connected1) L_tail_2sub.render(renderer); else L_tail_2.render(renderer);
	}
	if (!entity || states[0] == 1) {
		if (data.connected0) L_tail_1sub.render(renderer); else L_tail_1.render(renderer);
		L_tail_2sub.render(renderer);
	}

	if (!entity || buttons[3] == 1) {
		if (!data.connected0) L_tail_1.render(renderer);
		if (!data.connected1) L_tail_2.render(renderer);
	}
	//



    var cabControlsVisible=asariCabControlEnd(entity,data)>=0;
    var selectorNow=asariRenderFrameTime(entity);
    var endTarget=[states[10]===0?1:0,states[10]===1?1:0,states[10]===2?1:0];
    var endWeight=asariSelectorWeights(entity,'asariEndSelector',endTarget,selectorNow);
    var reverserAngle=cabControlsVisible?asariReverserAngle(entity,states[10],selectorNow):0;
    if(!entity || pass>=0 && pass<=4){
        asariRenderSelectorPart(mae,endWeight[0]);
        asariRenderSelectorPart(usiro,endWeight[2]);
        if(pass>=0 && pass<=4){
            renderCabPart(reverserFront,false,reverserAngle,'Y',ASARI_REVERSER_PIVOT_X,1.26,ASARI_REVERSER_PIVOT_Z);
            renderCabPart(reverserRear,false,reverserAngle,'Y',-ASARI_REVERSER_PIVOT_X,1.26,-ASARI_REVERSER_PIVOT_Z);
        }
    }

	
	if ((!entity || buttons[0] == 1) &&
		pass == 0) {
		sabo1.render(renderer);
	}
	if ((!entity || buttons[0] == 2) &&
		pass == 0) {
		sabo2.render(renderer);
	}


	//
	asariRenderOneman(entity, pass, data);

	asariRenderFareboxes(entity, pass, data);

	// 1..30 map to the same registered MQO parts.
	var sign = entity ? buttons[4] : 1;
	if ((!entity || pass == 0) && sign >= 1 && sign <= 30) {
		rollsignParts[sign - 1].render(renderer);
	}


	asariRenderPressureNeedles(entity, pass, data);
	var rawSpeed = data.rawSpeed;
	var speed = rawSpeed * 72.0, notch = data.notch;
	var cabPosX=asariLightNotchPosition[0], cabPosY=asariLightNotchPosition[1], cabPosZ=asariLightNotchPosition[2];
	asariRenderLightNotch(entity,pass,data);




	if (!entity || (pass == 0) && (buttons[2] == 0)) {

		if (!entity || (pass == 0) && (buttons[2] == 0)) {
			
			
		}
		if (!entity || (pass == 0) && (buttons[2] == 0)) {
			
			
		}
	}

	//#################################################################################################################################################################################################
	//

	if (!entity || (pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) &&
		states[0] == 0) {
		var angle1 = asariSpeedNeedleAngle(speed);
		asariRenderGaugePart(ebtf_Ms, data.connected0, angle1, 'Z', (cabPosX + 118.66) / 100, (cabPosY + 138.86) /
			100, (cabPosZ + 1012.76) / 100);
	}


	//######################
	//
	if (!entity || (pass == 0 || pass == 1 || pass == 2 || pass == 3 || pass == 4) &&
		states[0] == 1) {
		var angle1 = -asariSpeedNeedleAngle(speed);
		asariRenderGaugePart(ebtf_Ms2, data.connected1, angle1, 'Z', (cabPosX - 118.66) / 100, (cabPosY + 138.86) /
			100, (cabPosZ - 1012.76) / 100);
	}
	//###########################




	if (!entity || (pass == 0 || pass == 2 || pass == 3 || pass == 4) && (buttons[2] == 1)) {
		if (!entity || (pass == 0 || pass == 2 || pass == 3 || pass == 4) && (
				buttons[2] == 1) && states[1] ==
			-8) {
			ebtf_Lb8.render(renderer);
		}
		if (!entity || (pass == 0 || pass == 2 || pass == 3 || pass == 4) && (buttons[2] == 1) && states[0] == 0) {
			
			
		}

		if (!entity || (pass == 0 || pass == 2 || pass == 3 || pass == 4) && (buttons[2] == 1) && states[0] == 1) {
			
			
		}


	}
	if ((!entity || pass == 0 || pass == 2 || pass == 3 || pass == 4) && speed >=
		-3 || speed <= 3) {
		under3km.render(renderer);
	}
	if ((!entity || pass == 0 || pass == 2 || pass == 3 || pass == 4) && speed <
		-4 || speed > 4) {
		over4km.render(renderer);
	}


    var modeTarget=[states[1]>0 && speed>61?1:0,states[1]<=0?1:0,states[1]>0 && speed<60?1:0];
    var modeWeight=asariSelectorWeights(entity,'asariDriveModeSelector',modeTarget,selectorNow);
    var driveSelectorAngle=cabControlsVisible?asariDriveSelectorAngle(entity,modeTarget,selectorNow):0;
    if(!entity || pass>=0 && pass<=4){
        asariRenderSelectorPart(_choku,modeWeight[0]);
        asariRenderSelectorPart(_chu,modeWeight[1]);
        asariRenderSelectorPart(_hen,modeWeight[2]);
    }
    var showDriveModeDark=pass>=0 && pass<=4;
    if(showDriveModeDark){
        renderCabPart(driveSelectorFront,false,driveSelectorAngle,'Y',ASARI_DRIVE_PIVOT_X,1.25,ASARI_DRIVE_PIVOT_Z);
        renderCabPart(driveSelectorRear,false,driveSelectorAngle,'Y',-ASARI_DRIVE_PIVOT_X,1.25,-ASARI_DRIVE_PIVOT_Z);
    }

	
	if (!entity || data.doorMoveL > 1) {
		doorLL_lamp.render(renderer);
	}

	if (!entity || data.doorMoveL <= 1) {
		doorLL_off_lamp.render(renderer);
	}

	if (!entity || data.doorMoveR > 1) {
		doorRL_lamp.render(renderer);
	}

	if (!entity || data.doorMoveR <= 1) {
		doorRL_off_lamp.render(renderer);
	}

	if (!data.sealed && (!entity || data.doorMoveL == 0 && data.doorMoveR == 0)) {
		door_light.render(renderer);
	}


}
//include <as_JRH_40scripts/asari_farebox_lightweight.js>

//include <as_JRH_40scripts/asari_cab_motion_lightweight.js>

//include <as_JRH_40scripts/asari_linear_door_motion.js>

//include <as_JRH_40scripts/asari_passage_cab_lights.js>

//include <as_JRH_40scripts/asari_render_frame_time.js>

//include <as_JRH_40scripts/asari_dn_position.js>

//include <as_JRH_40scripts/asari_notch_lightweight.js>

//include <as_JRH_40scripts/asari_cab_controls.js>

//include <as_JRH_40scripts/asari_button_layout.js>
