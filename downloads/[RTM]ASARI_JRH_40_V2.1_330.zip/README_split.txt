ASARI JRH キハ40 V2.1 330番台
必須: [RTM]ASARI_JRH_40_V2.1_common
原作者: 朝里重工 / @ASARI_JUKO
元データの内容・参照パスは変更せず、配置先のみを分割しています。
利用・配布条件は共通パック内 assets/readme.txt を参照してください。
